package com.bmo.idp.encryption.util

import java.io._
import java.nio.file.Path
import java.security.{PrivateKey, PublicKey}
import java.time.{Duration, Instant}

import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.BackupDataFile


object NZFileEncryptionUtil extends NZLogger{
  @throws[IOException]
  def encryptAndCopyRelatedFolder(inputFileName: String, outputFileName: String, ifolder: String, ofolder: String, securedKey: Array[Byte]): Unit = {
    val inputFile: File = NZFileUtil.getRelatedFile(inputFileName, ifolder)
    val outputFile: File = NZFileUtil.getRelatedFile(outputFileName, ofolder)
    encryptAndCopy(inputFile, outputFile, securedKey)
  }

  @throws[IOException]
  def encryptAndCopy(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createEncryptedCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val os = NZFileUtil.getOutputStream(outputFile)
    val wos = AES256Util.wrapOutputStream(os, cipher)
    try {
      NZFileUtil.copy(is, wos)
    } finally {
      if (is != null) is.close()
      if (wos != null) wos.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def decryptAndCopyRelatedFolder(inputFileName: String, outputFileName: String, ifolder: String, ofolder: String, securedKey: Array[Byte]): Unit = {
    val inputFile = NZFileUtil.getRelatedFile(inputFileName, ifolder)
    val outputFile = NZFileUtil.getRelatedFile(outputFileName, ofolder)
    decryptAndCopy(inputFile, outputFile, securedKey)
  }

  @throws[IOException]
  def decryptAndCopy(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val wis = AES256Util.wrapInputStream(is, cipher)
    val os = NZFileUtil.getOutputStream(outputFile)
    try {
      NZFileUtil.copy(wis, os)
    } finally {
      if (wis != null) wis.close()
      if (os != null) os.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def decryptS3AndCopyFile(s3Bucket:String, inputFile: String, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val is = IDPS3Client.getS3ObjectInputStream(s3Bucket, inputFile)
    val wis = AES256Util.wrapInputStream(is._2, cipher)
    val os = NZFileUtil.getOutputStream(outputFile)
    try {
      NZFileUtil.copy(wis, os)
    } finally {
      if (wis != null) wis.close()
      if (os != null) os.close()
    }
    outputFile.setLastModified(is._1.getLastModified.getTime)
  }

  def decryptS3AndCopyS3(s3Bucket:String, inputFile: String, outputFile: String, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val s3is = IDPS3Client.getS3ObjectInputStream(s3Bucket, inputFile)
    val s3isw = AES256Util.wrapInputStream(s3is._2, cipher)
    IDPS3Client.copyS3ObjectInputStreamMultipart(s3isw, s3Bucket, outputFile, false, s3is._1.getContentLength)
  }

  def isToExcludeEncDec(file:Path):Boolean = {
    (file.getFileName.toString.endsWith(NZFileEncryptConfig.END_BIN)
      || file.getFileName.toString.endsWith(NZFileEncryptConfig.END_DONE)
      || file.getFileName.toString.endsWith(NZFileEncryptConfig.END_FAIL))
  }
  def isToExcludeEncDec(file:BackupDataFile):Boolean = {
    (file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_BIN)
      || file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_DONE)
      || file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_FAIL))
  }

  def printConfigure() = {
    logger.info("bufferSize=%d; END_BIN=%s; encDoneName=%s\n".format(NZFileEncryptConfig.END_BIN, NZFileEncryptConfig.encDoneName))
  }

  def timeInvoke(callback: () => Unit) {
    var start = Instant.now
    callback()
    var finish = Instant.now
    var timeElapsed = Duration.between(start, finish).toMillis
    logger.info(" testEncryption timeElapsed:" + timeElapsed)
  }

  def jsonStrToMap(jsonStr: String): Map[String, Any] = {
    import org.json4s._
    import org.json4s.jackson.JsonMethods._

    implicit val formats = org.json4s.DefaultFormats
    val map = parse(jsonStr).extract[Map[String, Any]]
    map
  }

  def getPrivateKeyFromAWSSecretManager(): PrivateKey =  {
    val secret = IDPSecretsClient.getSecret(NZFileEncryptConfig.privateKeyArn)
    val map = NZFileEncryptionUtil.jsonStrToMap(secret)
    val privateKeyStr:String = map.get("privateKey").get.asInstanceOf[String]
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    privateKey
  }

  def getPrivateKeyFromString(): PrivateKey =  {
    val privateKeyStr:String = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC6ivyL9PCj8Z29QXZDngAaGMe75UcyYR3xnS+OCqkjemyGvviz33DJ6LIQ5t3TquX6WKWYEyjH21PfDlEZv7DPsCpC9IQkfiu5zb/7//niu9wZzMPRkwaEt5zUfxJgJs4I6u4gy6XAmJLrDrk28Sh6qtGW6Cwy81BZnCOcX2kojQxnIGfXUP7EmascUGVvVFt1e+nHQYbxRcxFAD/kEfNO2m3mI2BHdxZoegBBD40Ro8bFJKS5BsomhfrtfEu4YYRV2cTeSJeSE9KWQ0maCxdiEdoZTHIXkW77tJKx8YGzzuNih4BnAgi4l7v+DGw8iwf7sgRoxnkCyWoIeaIBmc7ZAgMBAAECggEAWF64RfsKtrei4MGuq1ihtrsvf6Edqc2dGFU87n65Yp+/4tN8UQXUUipElMIxqvDmUsME63aEFq2d3WjUXazUL4dGdgKMyRbmUvaX8OLyN4mEOsqop1MNvviWuIncJCWt7EaS+YFP6927l9QZROBYq0fZ0zH4okhms5TGv/DpCbZ7ff7ajyoxHfIP6VJ1c+8LrYv3AUYdys0idqupOTseNFm81K0j6WstSri7JK6h5IkLXhj0lCAIYHopU8PmvvHPLRojcOY9gSSNJkvAyLZYfWu9j/B78QdkThV0Y0AnRuAO/4MpCaOcEmmVVXB557gDKi4sUrwaSnna2kzfOFMQSwKBgQD1/VRGZ2qtw5SiP+SyQSWL+VxL/pSUxIlbvvf3Sr1b2KtMGO69cEcAHTP+FUSUCoNkLZtdbMGZTbCt7Di36tFU4qnOvu7u7oQ3S+OtkbxEKiD28hc2O90keIAMWKZ4NnTrwbGH8tH6XLbIiPPqQlsfn5DSOUmJ518VbcZSxmDCIwKBgQDCIlqUJJCe5mJ0lXBOl5AXoC03mevlr/RfPgBFB4oitxlM0OM2lzE4GR1d1tTAZR+zl6UYCor8ilRp9/LV3VliKnQetzjaoi74AJRU8lPzxTRO8pmbBH9BkO6fRQyx/HCIXlZMQatT11DE0+sussJtJ7zkKEDG/sj790Xjkd3E0wKBgQCaHNuGvFXuhYECYatDLmN6nYCAr/+gcL1puGwcBzw5ZbZ0F47DKqug26ruPZ7YbPnCcnxK/M8R38WYQU2LlFcPqm4edCq3kMFO74G2BX8A6a/7ZtK6DKlQpxn6IjQxTlTUO2ahOLTq+NkfLAY8ttPmLQ8LVg7HkihVAZBl3ZlTJwKBgEaZ68sYiSfgrUms100dvZ959zfTWIENvpesmriAB3KcmCzhguBll9bI+28XJARcQm0z5yyZGPbC7/Qh4kR43Xrf6Z8KDzkj5mT3APrrrjBnNaDIhahkuEsGBGIT4IwSPHK7rDLLZx10nsEWON+gzyiXXRC0uuoj2sAXq2kZsUdVAoGAcltvNlULxFqnF8eYGm4l/eebJLOSjMgIJwFN1dgtH03Y+SeU1KuflVJdNtomMwaALWd4AdjJdOu4TItBp/hnLV3oUd96uxVURyt2jnEITLE9XFZ8P3XE6h6j8hI6+sammHBTvRHyf4/zTV8QAXVnrHLAt1RtxCyYKPVJHvPRtsU="
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    privateKey
  }

  def getPublicKeyFromString(): PublicKey =  {
    val publicKeyStr:String = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuor8i/Two/GdvUF2Q54AGhjHu+VHMmEd8Z0vjgqpI3pshr74s99wyeiyEObd06rl+lilmBMox9tT3w5RGb+wz7AqQvSEJH4ruc2/+//54rvcGczD0ZMGhLec1H8SYCbOCOruIMulwJiS6w65NvEoeqrRlugsMvNQWZwjnF9pKI0MZyBn11D+xJmrHFBlb1RbdXvpx0GG8UXMRQA/5BHzTtpt5iNgR3cWaHoAQQ+NEaPGxSSkuQbKJoX67XxLuGGEVdnE3kiXkhPSlkNJmgsXYhHaGUxyF5Fu+7SSsfGBs87jYoeAZwIIuJe7/gxsPIsH+7IEaMZ5AslqCHmiAZnO2QIDAQAB"
    val publicKey:PublicKey = RSAUtil.getPublicKeyFromString(publicKeyStr)
    publicKey
  }

}