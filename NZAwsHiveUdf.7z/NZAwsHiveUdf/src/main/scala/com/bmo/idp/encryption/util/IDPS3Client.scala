package com.bmo.idp.encryption.util

import java.io._
import java.nio.file.Paths

import com.amazonaws.AmazonServiceException
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.internal.SSEResultBase
import com.amazonaws.services.s3.model.{DeleteObjectsRequest, ListObjectsRequest, ObjectListing, _}
import com.amazonaws.services.s3.transfer.{TransferManager, TransferManagerBuilder}
import com.amazonaws.services.s3.{AmazonS3, AmazonS3ClientBuilder}
import com.bmo.idp.encryption.logger.NZLogger

import scala.collection.JavaConversions._
object IDPS3Client extends NZLogger {
  val S3_PATH_SEPARATOR = "/"

  val keyArn = "arn:aws:kms:us-east-2:534454167231:key/6141e9b4-875a-4873-879d-2b90bb37ba53"

  val s3: AmazonS3 = AmazonS3ClientBuilder.standard.withRegion(Regions.US_EAST_2).build

  def uploadFile(bucketName:String, filePath:String, sse:Boolean): Boolean  = {
    var successful : Boolean = true
    val keyName = Paths.get(filePath).getFileName.toString
    try {

      val objectMetadata = new ObjectMetadata

      if (sse) {
        //objectMetadata.setContentLength(objectBytes.length)
        objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION)
        val putRequest: PutObjectRequest = new PutObjectRequest(bucketName, keyName, new FileInputStream(new File(filePath)), objectMetadata)

        // Upload the object and check its encryption status.
        val putResult = s3.putObject(putRequest)
        logger.info("Object \"" + keyName + "\" uploaded with SSE.")
        printEncryptionStatus(putResult)
      } else {
        s3.putObject(bucketName, keyName, new File(filePath))
      }
    } catch {
      case e: AmazonServiceException =>
        successful = false
        logger.info(e.getMessage)
    }
    successful
  }

  def listObjects(bucketName:String): List[S3ObjectSummary] = {
    val result:ListObjectsV2Result = s3.listObjectsV2(bucketName)
    val objects = result.getObjectSummaries
    objects.toList
  }

  def listObjects(bucketName:String, folder:String): List[S3ObjectSummary] = {
    val listObjectRequest: ListObjectsRequest = new ListObjectsRequest().withBucketName(bucketName).withPrefix(folder)
    val result: ObjectListing = s3.listObjects(listObjectRequest)//.getCommonPrefixes)
    val objects = result.getObjectSummaries
    objects.toList
  }

  @throws[AmazonServiceException]
  def deleteObject(bucket_name:String, object_key:String) = {
    s3.deleteObject(bucket_name, object_key)
  }

  @throws[AmazonServiceException]
  def deleteObjectUnderFolder(bucketName:String, folder:String) = {
    val objects = listObjects(bucketName, folder)
    val dor: DeleteObjectsRequest = new DeleteObjectsRequest(bucketName).withKeys(objects.map(_.getKey):_*)
    s3.deleteObjects(dor)
  }



  def download(bucketName:String, keyName:String): Boolean = {
    var result = false
    try {
      val o : S3Object  = s3.getObject(bucketName, keyName)
      val s3is: S3ObjectInputStream = o.getObjectContent
      val fos = new FileOutputStream(new File("./backup/" + keyName))
      val read_buf = new Array[Byte](1024)
      var read_len = s3is.read(read_buf)
      while (read_len > 0)  {
        fos.write(read_buf, 0, read_len)
        read_len = s3is.read(read_buf)
      }
      s3is.close()
      fos.close()
      result = true
    } catch {
      case e: AmazonServiceException =>
        logger.info(e.getErrorMessage)
      case e: FileNotFoundException =>
        logger.info(e.getMessage)
      case e: IOException =>
        logger.info(e.getMessage)
    }
    result
  }

  def printEncryptionStatus(response: SSEResultBase): Unit = {
    var encryptionStatus = response.getSSEAlgorithm
    if (encryptionStatus == null) encryptionStatus = "Not encrypted with SSE"
    logger.info("Object encryption status is: " + encryptionStatus)
  }


  @throws[AmazonServiceException]
  @throws[Exception]
  def getS3ObjectInputStream(bucketName:String, keyName:String): (ObjectMetadata, S3ObjectInputStream) = {
      var result = false
      val o : S3Object  = s3.getObject(bucketName, keyName)
      val s3is: S3ObjectInputStream = o.getObjectContent
      val meta:ObjectMetadata = o.getObjectMetadata
     (meta, s3is)
  }

  @throws[AmazonServiceException]
  @throws[Exception]
  def getS3ObjectBytes(bucketName:String, keyName:String): Array[Byte] = {
    var result = false
    val o : S3Object  = s3.getObject(bucketName, keyName)
    val s3is: S3ObjectInputStream = o.getObjectContent
    NZFileUtil.readAllBytes(s3is)
  }

  @throws[AmazonServiceException]
  @throws[Exception]
  def copyS3ObjectInputStream(s3is:InputStream, bucketName:String, keyName:String, sse:Boolean, size:Long): Unit  = {
    val objectMetadata = new ObjectMetadata
    try {
      if (sse) {
        //objectMetadata.setContentLength(objectBytes.length)
        objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION)
        val putRequest: PutObjectRequest = new PutObjectRequest(bucketName, keyName, s3is, objectMetadata)
        if (size > 0) {
          //objectMetadata.setContentLength(size)
          //putRequest.getRequestClientOptions().setReadLimit(size.toInt)
        }
        putRequest.getRequestClientOptions().setReadLimit(size.toInt)
        val putResult = s3.putObject(putRequest)
        printEncryptionStatus(putResult)
      } else {
        val putRequest: PutObjectRequest = new PutObjectRequest(bucketName, keyName, s3is, objectMetadata)
        if (size > 0) {
          //objectMetadata.setContentLength(size)
          //putRequest.getRequestClientOptions().setReadLimit(size.toInt)
        }

        val putResult = s3.putObject(putRequest)
        printEncryptionStatus(putResult)
      }
    } finally {
      if (s3is != null) s3is.close
    }
  }


  @throws[AmazonServiceException]
  @throws[Exception]
  def copyS3ObjectInputStreamMultipart(s3is:InputStream, bucketName:String, keyName:String, sse:Boolean, size:Long): Unit  = {
    val objectMetadata = new ObjectMetadata
    try {
      if (sse) {
        //objectMetadata.setContentLength(objectBytes.length)
        objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION)
        val putRequest: PutObjectRequest = new PutObjectRequest(bucketName, keyName, s3is, objectMetadata)
        if (size > 0) {
          //objectMetadata.setContentLength(size)
          //putRequest.getRequestClientOptions().setReadLimit(size.toInt)
        }
        val putResult = s3.putObject(putRequest)
        printEncryptionStatus(putResult)
      } else {
        val tm: TransferManager = TransferManagerBuilder.standard().withS3Client(s3).build();
        val upload = tm.upload(bucketName, keyName, s3is, objectMetadata)
        logger.info("Object upload started")
        upload.waitForCompletion()
        logger.info("Object upload complete")
        tm.shutdownNow
      }
    } finally {
      if (s3is != null) s3is.close
    }
  }


  def downloadToFile(s3is:InputStream, keyName:String): Boolean = {
    var result = false
    try {
      val fos = new FileOutputStream(new File("./backup/" + keyName))
      val read_buf = new Array[Byte](1024)
      var read_len = s3is.read(read_buf)
      while (read_len > 3)  {
        fos.write(read_buf, 0, read_len)
        read_len = s3is.read(read_buf)
      }
      s3is.close()
      fos.close()
      result = true
    } catch {
      case e: AmazonServiceException =>
        logger.info(e.getErrorMessage)
      case e: FileNotFoundException =>
        logger.info(e.getMessage)
      case e: IOException =>
        logger.info(e.getMessage)
    }
    result
  }


  def uploadS3ObjectInputStreamTxManager(s3is:InputStream, bucketName:String, keyName:String, sse:Boolean, size:Long): Unit  = {
    val objectMetadata = new ObjectMetadata
    try {
      if (sse) {
        //objectMetadata.setContentLength(objectBytes.length)
        objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION)
      }
      if (size > 0) {
        //objectMetadata.setContentLength(size)
      }
      val putRequest = new PutObjectRequest(bucketName, keyName, s3is, objectMetadata)
      if (size > 0) {
        //putRequest.getRequestClientOptions().setReadLimit(size.toInt)
      }
      val tm: TransferManager = TransferManagerBuilder.standard().withS3Client(s3).build();
      val upload = tm.upload(bucketName, keyName, s3is, objectMetadata)
      //XferMgrProgress.showTransferProgress(xfer)
      logger.info("Object upload started")
      upload.waitForCompletion()
      logger.info("Object upload complete")
      tm.shutdownNow
    } catch  {
      case e: AmazonServiceException =>
        logger.info(e.getErrorMessage)
        System.exit(1)
      case e: Exception =>
        logger.info(e.getMessage)
        System.exit(1)
    } finally {
      if (s3is != null) s3is.close
    }
  }

  def downloadS3ObjectInputStreamTxManager(bucketName:String, keyName:String):File  = {
     val tmpFile: File = File.createTempFile("tmp", "nz")
     try {
      val tm: TransferManager = TransferManagerBuilder.standard().withS3Client(s3).build();
      val upload = tm.download(bucketName, keyName, tmpFile)
      //XferMgrProgress.showTransferProgress(xfer)
      logger.info("Object upload started")
      upload.waitForCompletion()
      logger.info("Object upload complete")
      tm.shutdownNow
    } catch  {
      case e: AmazonServiceException =>
        logger.info(e.getErrorMessage)
        System.exit(1)
      case e: Exception =>
        logger.info(e.getMessage)
        System.exit(1)
    } finally {
      tmpFile.deleteOnExit()
    }
    tmpFile
  }

  private def formatS3Path(s:String):String = {
    s.replaceAll(s"$S3_PATH_SEPARATOR+","/").replaceAll(s"^${S3_PATH_SEPARATOR}","").replaceAll(s"${S3_PATH_SEPARATOR}${"$"}","")
  }

  def makeS3Path(s:String*):String = {
    formatS3Path(s.mkString(S3_PATH_SEPARATOR))
  }

  def parseS3Path(s3Path:String):List[String] = {
    s3Path.split(S3_PATH_SEPARATOR).toList
  }

  def getS3PathParent(s3Path:String):String = {
    formatS3Path(parseS3Path(s3Path).init.mkString(S3_PATH_SEPARATOR))
  }

  def getS3PathFileName(s3Path:String):String = {
    parseS3Path(formatS3Path(s3Path)).last
  }

}
