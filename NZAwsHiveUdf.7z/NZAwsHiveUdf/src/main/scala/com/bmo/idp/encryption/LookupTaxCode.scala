package com.bmo.idp.encryption

import java.io.{File, FileInputStream, IOException, InputStream}
import java.util.{Map, NavigableMap}

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataInputStream, FileSystem, Path}
import org.apache.hadoop.hive.common.`type`.HiveDecimal
import org.apache.hadoop.hive.conf.HiveConf
import org.apache.hadoop.hive.ql.exec.{UDFArgumentException, UDFArgumentLengthException}
import org.apache.hadoop.hive.ql.metadata.HiveException
import org.apache.hadoop.hive.ql.session.SessionState
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF
import org.apache.hadoop.hive.serde2.io.HiveDecimalWritable
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector
import org.apache.hadoop.hive.serde2.objectinspector.primitive.{ByteObjectInspector, IntObjectInspector, PrimitiveObjectInspectorFactory, StringObjectInspector}


/**
 *
 *
 * DROP FUNCTION IF EXISTS lookup_taxcode;
 *
 * CREATE FUNCTION lookup_taxcode AS 'my.package.LookupTaxCode'
 * USING JAR 'hdfs://path/to/udf.jar',
 * FILE 'hdfs://path/to/relevant/partfile';
 *
 * select lookup_taxcode(12345, 100, 20180101, '/hdfs/path/to/partfile') from ...
 */
object LookupTaxCode {
  private val PART_FILE = "partfile"
}

class LookupTaxCode extends GenericUDF {
  private var customerInspector:ByteObjectInspector = null
  private var taxCodeInspector:ByteObjectInspector = null
  private var dateInspector:IntObjectInspector = null
  private var fileInspector: StringObjectInspector = null
  /*
   * this will be initialized in the initMap method: group by customer and
   * lower-range value (assuming there are no gaps)
   */
  private val lookup: Map[Integer, Map[Integer, NavigableMap[Integer, HiveDecimal]]] = null

  @throws[UDFArgumentException]
  def initialize(args: Array[ObjectInspector]) : ObjectInspector = {
    if (args.length < 3) throw new UDFArgumentLengthException("This function needs a minimum of 3 arguments - customer, taxcode-ID, (active) date " + "plus - optionally - source file (pipe-delimited)!")
    this.customerInspector = args(0).asInstanceOf[ByteObjectInspector]
    this.taxCodeInspector = args(1).asInstanceOf[ByteObjectInspector]
    this.dateInspector = args(2).asInstanceOf[IntObjectInspector]
    if (args.length > 3) this.fileInspector = args(3).asInstanceOf[StringObjectInspector]
    PrimitiveObjectInspectorFactory.writableHiveDecimalObjectInspector
  }

  @throws[HiveException]
  def evaluate(args: Array[GenericUDF.DeferredObject]):HiveDecimalWritable = {
    /* initialize lookup, if not yet done */
    if (lookup == null) if (args.length > 3) initHdfsLookup(fileInspector.getPrimitiveJavaObject(args(3).get)) // previously: lookup has to provided as an argument
    else initCacheLookup(getResourcePath) // now: lookup up from path defined in CREATE FUNCTION
    /* perform lookup */
    val customer = customerInspector.get(args(0).get).asInstanceOf[Int]
    val taxCodeId = taxCodeInspector.get(args(1).get).asInstanceOf[Int]
    val dateFrom = dateInspector.get(args(2).get)
    if (lookup.containsKey(customer) && lookup.get(customer).containsKey(taxCodeId)) {
      val rr:NavigableMap[Integer, HiveDecimal] = lookup.get(customer).get(taxCodeId)
      val floorEntry:Map.Entry[Integer, HiveDecimal] = rr.floorEntry(dateFrom)
      new HiveDecimalWritable(
        if (floorEntry == null) HiveDecimal.create(0)
        else floorEntry.getValue)
    }
    else null
  }

  @throws[HiveException]
  private def initCacheLookup(lookupFile: String) = {
    var in: InputStream = null
    try {
      in = new FileInputStream(getLookupFile(lookupFile))
      initMap(in)
    } catch {
      case e: Exception =>
        throw new HiveException(e + ": when attempting to access: " + lookupFile)
    }
  }

  protected def getLookupFile(lookupFile: String):File = {
    /* distributed cache */
    var f = new File(lookupFile) // file available locally
    if (!f.exists) {
      /* local resources (non-MR mode) */
      val resourceDir = new File(SessionState.get.getConf.getVar(HiveConf.ConfVars.DOWNLOADED_RESOURCES_DIR))
      f = new File(resourceDir, lookupFile)
    }
    f
  }

  @throws[HiveException]
  protected def getResourcePath:String = LookupTaxCode.PART_FILE

  @throws[HiveException]
  private def initHdfsLookup(lookupFile: String) = try {
    val conf = new Configuration
    val filePath = new Path(lookupFile)
    val fs = FileSystem.get(filePath.toUri, conf)
    val in: FSDataInputStream = fs.open(filePath)
    initMap(in)
  } catch {
    case e: Exception =>
      throw new HiveException(e + ": when attempting to access: " + lookupFile)
  }

  @throws[IOException]
  protected def initMap(in: InputStream) = {
    /*
     * perform some lookup logic from named hdfs file here...
     */
  }

  def getDisplayString(args: Array[String]):String = "Method call: lookup_taxcode(" + args(0) + ", " + args(1) + ", " + args(2) + ")"
}