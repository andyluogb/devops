package com.bmo.idp.encryption

import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Paths

import com.bmo.idp.encryption.util.NZFileUtil
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.SparkSession

import scala.collection.JavaConverters._


object SparkPartition {

  def main(args:Array[String]): Unit = {

    val warehouseLocation = new File("spark-warehouse").getAbsolutePath

    val dataPath = Paths.get("txt")

    val spark = SparkSession
      .builder()
      .master("local[*]")
      .appName("Spark Hive Example")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .getOrCreate()

    val dataFiles = spark.sparkContext.broadcast(NZFileUtil.listFiles(dataPath).map(f=>f.toAbsolutePath.toString))

    val txt = spark.sparkContext.parallelize(dataFiles.value, 4).flatMap(f=>readToStringList(f)).repartition(4)
    txt.saveAsTextFile("txt1")
    spark.close()
  }

  def readToStringList(file:String):List[String] = {
    //val input:InputStream = NZFileUtil.getInputStream(new File(file))
    //import org.apache.commons.io.IOUtils
    val lines = FileUtils.readLines(new File(file), StandardCharsets.UTF_8)
    val l = lines.asScala.toList
    l
  }
}
