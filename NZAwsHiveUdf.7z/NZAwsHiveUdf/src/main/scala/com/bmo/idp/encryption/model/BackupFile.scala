package com.bmo.idp.encryption.model

case class BackupType(dbName:String, timestampName:String, dbSequenceName:String, backupTypeName:String)
case class BackupDBSequence(dbName:String, timestampName:String, dbSequenceName:String, backupTypes: List[BackupType])
case class BackupFile(dbName:String, timestampName:String, dbSequences: List[BackupDBSequence])

case class BackupDataFile(root_backup:String, dbName:String, timestampName:String, dbSequenceName:String, backupTypeName:String, dataFolder:String, dataFileName:String)