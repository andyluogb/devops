package com.bmo.idp.encryption

import java.security.PrivateKey
import java.util.Base64

import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.util.{AES256Util, IDPSecretsClient, NZFileEncryptionUtil, RSAUtil}
import org.apache.hadoop.hive.ql.exec.{UDFArgumentException, UDFArgumentLengthException}
import org.apache.hadoop.hive.ql.metadata.HiveException
import org.apache.hadoop.hive.ql.session.SessionState
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector
import org.apache.hadoop.hive.serde2.objectinspector.primitive.{PrimitiveObjectInspectorFactory, StringObjectInspector}
import org.apache.hadoop.io.Text
import org.apache.hadoop.hive.ql.exec.MapredContext
import org.apache.hadoop.hive.ql.udf.UDFType


object NZDecryptionHiveUDF {
  val LEFT_KEY_ARN_CONG = "idp.key.private.left.arn"
  val RIGHT_KEY_ARN_CONG = "idp.key.private.right.arn"
  var privateKey:PrivateKey = null
}

/**
 *
 *
 * DROP FUNCTION IF EXISTS nz_decrypt;
 *
 * CREATE FUNCTION nz_decrypt AS 'my.package.NZDecryptionHiveUDF'
 * USING JAR 'hdfs://path/to/udf.jar',
 * FILE 'hdfs://path/to/relevant/partfile';
 *
 * select nz_decrypt('AAASWWD', 'leftKeyArn', 'rightKeyArn') from ...
 */
@UDFType(deterministic = true)
class NZDecryptionHiveUDF extends GenericUDF with NZLogger {
  private var textInspector:StringObjectInspector = null
  private var dataKeyInspector:StringObjectInspector = null
  /*
   * this will be initialized in the initMap method: group by customer and
   * lower-range value (assuming there are no gaps)
   */
  var leftKeyArn: String = null
  var rightKeyArn: String = null

  @throws[UDFArgumentException]
  def initialize(args: Array[ObjectInspector]) : ObjectInspector = {
    if (args.length < 1) throw new UDFArgumentLengthException("This function needs a minimum of 1 arguments - <text to decrypt> " + "plus - optionally - source file (pipe-delimited)!")
    this.textInspector = args(0).asInstanceOf[StringObjectInspector]
    this.dataKeyInspector = args(1).asInstanceOf[StringObjectInspector]
    val outputOI = PrimitiveObjectInspectorFactory.writableStringObjectInspector
    outputOI

    /*
   // This UDF accepts one argument
  assert (((args.length eq 1)))
  // The first argument is a primitive type
  assert (((args(0).getCategory eq Category.PRIMITIVE)))

  inputOI = args(0).asInstanceOf[PrimitiveObjectInspector]
  /* We only support INTEGER type */
  assert (((inputOI.getPrimitiveCategory eq PrimitiveCategory.INT)))

  /* And we'll return a type int, so let's return the corresponding object inspector */
  outputOI = PrimitiveObjectInspectorFactory.writableIntObjectInspector
     */


  }

  @throws[HiveException]
  def evaluate(args: Array[GenericUDF.DeferredObject]):Object = {
    /* initialize lookup, if not yet done */
    if (NZDecryptionHiveUDF.privateKey == null) {
      logger.info(">>>>privateKey is null")
        initConfigLookup()
    }

    if (args.length < 2) return null

    val oin1 = args(0).get
    val oin2 = args(1).get

    var result : Text = null
    if (NZDecryptionHiveUDF.privateKey != null) {
      val text = textInspector.getPrimitiveJavaObject(oin1).asInstanceOf[String]
      val key = textInspector.getPrimitiveJavaObject(oin2).asInstanceOf[String]

      val cleatText = decrypt(text, key)
      result = new Text(cleatText)
    }

    result
  }

/*
  @throws[HiveException]
  def evaluate(args: Array[GenericUDF.DeferredObject]): Any = {
    if (args.length != 1) return null
    // Access the deferred value. Hive passes the arguments as "deferred" objects
    // to avoid some computations if we don't actually need some of the values
    val oin = args(0).get
    if (oin == null) return null
    val value = inputOI.getPrimitiveJavaObject(oin).asInstanceOf[Integer]
    val output = value * 2
    new IntWritable(output)
  }

  def getDisplayString(args: Array[String]) = {
    "Here, write a nice description"
  }
*/

  @throws[HiveException]
  private def initConfigLookup() = {
    if (leftKeyArn==null) {
      leftKeyArn = getConfigFromSessionState(NZDecryptionHiveUDF.LEFT_KEY_ARN_CONG)
    }
    if (rightKeyArn==null) {
      rightKeyArn = getConfigFromSessionState(NZDecryptionHiveUDF.RIGHT_KEY_ARN_CONG)
    }
    initLookup(leftKeyArn, rightKeyArn)
  }


  @throws[HiveException]
  private def initLookup(letKeyArn: String, rightKeyArn: String) = {
    try {
      NZDecryptionHiveUDF.privateKey = getPrivateKeyFromAWSSecretManager(letKeyArn, rightKeyArn)
    } catch {
      case e: Exception =>
        throw new HiveException(e + ": when attempting to access initLookup.")
    }
  }

  def getDisplayString(args: Array[String]):String = {
    s"Method call: nz_decrypt(${args(0)} ${args(1)} ${args(2)} ${args(3)})"
  }

  def decrypt(ciphetTextBase64:String, keyBase64:String):String = {
    val securedKey:Array[Byte] = getDataKey(NZDecryptionHiveUDF.privateKey, keyBase64)
    val plainText:String = AES256Util.decrypt(ciphetTextBase64, securedKey)
    plainText
  }

  def getDataKey(pk:PrivateKey, cipherDataKeyBase64:String):Array[Byte] = {
    val cipherKey = Base64.getDecoder.decode(cipherDataKeyBase64)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  def getPrivateKeyFromAWSSecretManager(privateLeftKeyArn:String, privateRightKeyArn:String): PrivateKey =  {
    //val privateLeftKeyStr:String = getPrivateKeyStringFromAWSSecretManager(privateLeftKeyArn)
    //val privateRightKeyStr:String = getPrivateKeyStringFromAWSSecretManager(privateRightKeyArn)
    //val privateKeyStr:String = privateLeftKeyStr.concat(privateRightKeyStr)
    //val privateKeyStr:String = getPrivateKeyStringFromAWSSecretManager(privateLeftKeyArn)
    val privateKeyStr:String = "-----BEGIN RSA PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC6ivyL9PCj8Z29QXZDngAaGMe75UcyYR3xnS+OCqkjemyGvviz33DJ6LIQ5t3TquX6WKWYEyjH21PfDlEZv7DPsCpC9IQkfiu5zb/7//niu9wZzMPRkwaEt5zUfxJgJs4I6u4gy6XAmJLrDrk28Sh6qtGW6Cwy81BZnCOcX2kojQxnIGfXUP7EmascUGVvVFt1e+nHQYbxRcxFAD/kEfNO2m3mI2BHdxZoegBBD40Ro8bFJKS5BsomhfrtfEu4YYRV2cTeSJeSE9KWQ0maCxdiEdoZTHIXkW77tJKx8YGzzuNih4BnAgi4l7v+DGw8iwf7sgRoxnkCyWoIeaIBmc7ZAgMBAAECggEAWF64RfsKtrei4MGuq1ihtrsvf6Edqc2dGFU87n65Yp+/4tN8UQXUUipElMIxqvDmUsME63aEFq2d3WjUXazUL4dGdgKMyRbmUvaX8OLyN4mEOsqop1MNvviWuIncJCWt7EaS+YFP6927l9QZROBYq0fZ0zH4okhms5TGv/DpCbZ7ff7ajyoxHfIP6VJ1c+8LrYv3AUYdys0idqupOTseNFm81K0j6WstSri7JK6h5IkLXhj0lCAIYHopU8PmvvHPLRojcOY9gSSNJkvAyLZYfWu9j/B78QdkThV0Y0AnRuAO/4MpCaOcEmmVVXB557gDKi4sUrwaSnna2kzfOFMQSwKBgQD1/VRGZ2qtw5SiP+SyQSWL+VxL/pSUxIlbvvf3Sr1b2KtMGO69cEcAHTP+FUSUCoNkLZtdbMGZTbCt7Di36tFU4qnOvu7u7oQ3S+OtkbxEKiD28hc2O90keIAMWKZ4NnTrwbGH8tH6XLbIiPPqQlsfn5DSOUmJ518VbcZSxmDCIwKBgQDCIlqUJJCe5mJ0lXBOl5AXoC03mevlr/RfPgBFB4oitxlM0OM2lzE4GR1d1tTAZR+zl6UYCor8ilRp9/LV3VliKnQetzjaoi74AJRU8lPzxTRO8pmbBH9BkO6fRQyx/HCIXlZMQatT11DE0+sussJtJ7zkKEDG/sj790Xjkd3E0wKBgQCaHNuGvFXuhYECYatDLmN6nYCAr/+gcL1puGwcBzw5ZbZ0F47DKqug26ruPZ7YbPnCcnxK/M8R38WYQU2LlFcPqm4edCq3kMFO74G2BX8A6a/7ZtK6DKlQpxn6IjQxTlTUO2ahOLTq+NkfLAY8ttPmLQ8LVg7HkihVAZBl3ZlTJwKBgEaZ68sYiSfgrUms100dvZ959zfTWIENvpesmriAB3KcmCzhguBll9bI+28XJARcQm0z5yyZGPbC7/Qh4kR43Xrf6Z8KDzkj5mT3APrrrjBnNaDIhahkuEsGBGIT4IwSPHK7rDLLZx10nsEWON+gzyiXXRC0uuoj2sAXq2kZsUdVAoGAcltvNlULxFqnF8eYGm4l/eebJLOSjMgIJwFN1dgtH03Y+SeU1KuflVJdNtomMwaALWd4AdjJdOu4TItBp/hnLV3oUd96uxVURyt2jnEITLE9XFZ8P3XE6h6j8hI6+sammHBTvRHyf4/zTV8QAXVnrHLAt1RtxCyYKPVJHvPRtsU=\n-----END RSA PRIVATE KEY-----"
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    privateKey
  }

  def getPrivateKeyStringFromAWSSecretManager(privateKeyArn:String, keyOfKey:String): String =  {
    val secret = IDPSecretsClient.getSecret(privateKeyArn)
    val map = NZFileEncryptionUtil.jsonStrToMap(secret)
    val privateKeyStr:String = map.get(keyOfKey).get.asInstanceOf[String]
    privateKeyStr
  }

  override def configure(context: MapredContext): Unit = {
    super.configure(context)
    leftKeyArn = context.getJobConf().get(NZDecryptionHiveUDF.LEFT_KEY_ARN_CONG)
    rightKeyArn = context.getJobConf().get(NZDecryptionHiveUDF.RIGHT_KEY_ARN_CONG)
    logger.info(">>>>get configuration from MapredContext.")
    logger.info(s">>>>get configuration leftKeyArn:$leftKeyArn")
    logger.info(s">>>>get configuration rightKeyArn:$rightKeyArn")
  }

  def getConfigFromSessionState(param:String): String = {
    val v = SessionState.get.getConf.get(param)
    logger.info(">>>>get configuration from SessionState.")
    logger.info(s">>>>get configuration param:$param value:$v")
    v
  }

}