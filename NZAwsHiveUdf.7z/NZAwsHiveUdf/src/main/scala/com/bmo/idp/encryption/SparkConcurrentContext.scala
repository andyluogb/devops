package com.bmo.idp.encryption

import java.io.File
import java.util.concurrent._

import com.bmo.idp.encryption.util.InMemoryLogAppender
import org.apache.spark.sql.SparkSession

import scala.collection.JavaConverters._


object SparkConcurrentContext {
  val MAX_THREAD : Int = 3
  val MAX_TASK : Int = 6
  val logAppender = InMemoryLogAppender.createLogAppender(Seq("SparkSession#0", "SparkSession#1", "SparkSession#2"))
  var queue = new ConcurrentLinkedQueue[Seq[Int]]
  val latch = new CountDownLatch(MAX_TASK)

  def main(args:Array[String]): Unit = {

    implicit val sparkPool: Array[SparkSession] = createSparkPool(MAX_THREAD)

    val executor = Executors.newFixedThreadPool(MAX_THREAD).asInstanceOf[ThreadPoolExecutor]
    val processCallableList:List[ProcessCallable] = (0 until MAX_TASK).map(n=>new ProcessCallable(n, sparkPool)).toList
    println(s"Start executor in $MAX_THREAD threads")
    var list:List[Future[Int]] = null
    try {
      list = executor.invokeAll(processCallableList.asJavaCollection).asScala.toList
    } catch {
      case e:Exception => {
        e.printStackTrace()
      }
    }
    println("Completed executor")

    latch.await(3, TimeUnit.MINUTES)
    // Add a minute to prevent against race conditions
    Thread.sleep(1000L)

    println(s"queue size: ${queue.size()}")
    while ( {
      !queue.isEmpty
    }) {
      val node:Seq[Int] = queue.poll
      val str = node.mkString(";")
      println(str)
    }

    //AccumulatedRows.data should have size 3
    //AccumulatedRows.data.foreach(rows => rows should contain allOf(0, 1, 2, 3, 4, 5))
    //logAppender.getMessagesText() should have size 1
    // Since it's difficult to deduce which application was submitted, we check only the beginning of the log message
    println(s"logAppender.getMessagesText(): ${logAppender.getMessagesText().length}")
    val firstMessage = logAppender.getMessagesText()(0)
    println(s"firstMessage: $firstMessage")
    //firstMessage should startWith("Submitted application: SparkSession#")
    val Array(_, submittedSessionId) = firstMessage.split("#")
    val allSessions = Seq("0", "1", "2")
    val missingSessionsFromLog = allSessions.diff(Seq(submittedSessionId))
    //missingSessionsFromLog should have size 2
    println(s"missingSessionsFromLog: ${missingSessionsFromLog.length}")


    var doneNumber = 0
    for (f <- list) {
      //logger.info(s"Main: Task ${f.get()}: ${f.isDone}\n")
      if (f.isDone) {
        doneNumber += 1
      }
    }
    executor.shutdown()

    println(s"Total number of files is ${MAX_TASK}. Only $doneNumber files are completed.")
    if (doneNumber < MAX_TASK) {
      println(s"There are some files not being encrypted successfully.")
    }

    closeSpark(sparkPool)

  }


  class ProcessCallable(n:Int, sparkPool: Array[SparkSession]) extends Callable[Int] {
    @throws[Exception]
    def call():Int  = {
      processTask(n)(sparkPool)
      n
    }
  }

  def processTask(nr:Int)(implicit sessionPool:Array[SparkSession]) = {
    val threadId = Thread.currentThread.getId % MAX_THREAD
    println(s"threadId: ${threadId}")
    val sparkSession:SparkSession = sessionPool(threadId.toInt)
    import sparkSession.implicits._
    val dataset = (0 to 5).map(nr => (nr, s"${nr}")).toDF("id", "label")
    val rowsIds = dataset.collect().map(row => row.getAs[Int]("id")).toSeq
    // Give some time to make the observations
    Thread.sleep(3000)
    println(s"adding ${rowsIds}")
    queue.add(rowsIds)
    latch.countDown()
  }

  def createSparkPool(count:Int) : Array[SparkSession] = {
    var sparkArray = new Array[SparkSession](count)
    val warehouseLocation = new File("spark-warehouse").getAbsolutePath
    val sparkSession: SparkSession = SparkSession
      .builder()
      .master("local[*]")
      .appName(s"SparkSession#0")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .getOrCreate()
    sparkArray(0) = sparkSession
    if (count > 1) {
      for (i <- 1 until count) {
        sparkArray(i) = sparkSession.newSession()
      }
    }
    sparkArray
  }

  def closeSpark(sparkPool: Array[SparkSession]) = {
    sparkPool.foreach(s=> {
      s.close()
    })
  }

}
