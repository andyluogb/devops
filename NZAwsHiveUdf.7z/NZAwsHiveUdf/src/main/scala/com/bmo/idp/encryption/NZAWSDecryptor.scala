package com.bmo.idp.encryption

import java.nio.file.{Files, Path, Paths}
import java.security.PrivateKey

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.{BackupDataFile, BackupFilesConfig}
import com.bmo.idp.encryption.util._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

object NZAWSDecryptor extends NZLogger {

  def main(args: Array[String]){
    //NZConfig.parseArgs("src/main/resources/application.conf")
    NZConfig.parseArgs(args)
    val backupFilesConfig : BackupFilesConfig = NZBackupFileUtil.getBackupFilesConfigs(args)
    NZFileEncryptConfig.INPUT = backupFilesConfig.root_input
    NZFileEncryptConfig.OUTPUT = backupFilesConfig.root_output
    val (a,b) =NZBackupFileUtil.buildBackupDataFileList(backupFilesConfig)

    val backupDataFiles: List[BackupDataFile] = b
    checkOutputDirectoryTreeCreated(backupDataFiles, backupFilesConfig.root_output)
    /*val conf = new SparkConf().setAppName("Max Price").setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.textFile(args(0))
      .map(_.split(","))
      .map(rec => ((rec(0).split("-"))(0).toInt, rec(1).toFloat))
      .reduceByKey((a,b) => Math.max(a,b))
      .saveAsTextFile(args(1))*/

    val spark = SparkSession.builder()
      .master("local[*]")
      .appName("NZAWSDecryptor")
      .getOrCreate()

    val privKey:PrivateKey = NZFileEncryptionUtil.getPrivateKeyFromAWSSecretManager
    val privKeyBroad:Broadcast[PrivateKey] = spark.sparkContext.broadcast(privKey)
    val rootInputFolderBroad:Broadcast[String] = spark.sparkContext.broadcast(backupFilesConfig.root_input)
    val rootOutputFolderBroad:Broadcast[String] = spark.sparkContext.broadcast(backupFilesConfig.root_output)

    val rdd = spark.sparkContext.parallelize(backupDataFiles)
    rdd.foreach(a=>decryptAndCopyDataFiles(a, rootInputFolderBroad, rootOutputFolderBroad, privKeyBroad))
    spark.close()
  }


  /**
   * create folders
   */
  def checkOutputDirectoryTreeCreated(backupDataFiles: List[BackupDataFile], rootOutputFolder:String) = {
    for (backupDataFile <- backupDataFiles) {
      NZBackupFileUtil.checkOutputDirectoryTreeCreated(backupDataFile, rootOutputFolder)
    }
  }

  /**
   * Decryption for data files
   */
  def decryptAndCopyDataFiles(backupDataFile: BackupDataFile, rootInputFolderBroad:Broadcast[String] , rootOutputFolderBroad:Broadcast[String] , privKeyBroad:Broadcast[PrivateKey]) = {
      //NZBackupFileUtil.checkOutputDirectoryTreeCreated(backupDataFile, rootOutputFolderBroad.value)
      if (NZBackupFileUtil.isMDFile(backupDataFile)) {
        NZBackupFileUtil.copyMDFile(backupDataFile, rootInputFolderBroad.value, rootOutputFolderBroad.value)
      } else {
        decryptAndCopyDataFile(backupDataFile, privKeyBroad.value, rootInputFolderBroad.value, rootOutputFolderBroad.value)
      }
  }

  def getDataKey(pk:PrivateKey, backupData:BackupDataFile, rootInput:String):Array[Byte] = {
    val cipherDataKeyPath:Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)
    val cipherSecuredKeyFile = Paths.get(cipherDataKeyPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = NZFileUtil.readFileToBytes(cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  @throws[Exception]
  def decryptAndCopyDataFile(backupData:BackupDataFile, pk:PrivateKey, rootInput:String, rootOutput:String):Unit = {
    val inputDataPath:Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val outputDataPath:Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val inputLogPath:Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)
    val outputLogPath:Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)

    if (!NZFileEncryptionUtil.isToExcludeEncDec(backupData)) {
      try {
        val securedKey = getDataKey(pk, backupData, rootInput)
        val inputFile = Paths.get(inputDataPath.toAbsolutePath.toString, backupData.dataFileName)
        val outputFile = Paths.get(outputDataPath.toAbsolutePath.toString, backupData.dataFileName)
        val encDoneFileInput = Paths.get(inputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.encDoneName)
        if (Files.notExists(encDoneFileInput)) {
          logger.info("The file is not ready to be decrypted: " + inputFile.toAbsolutePath.toString)
        } else {
          NZFileEncryptionUtil.decryptAndCopy(inputFile.toFile, outputFile.toFile, securedKey)
          logger.info("decrypted file: " + outputFile.toAbsolutePath.toString)

          val decDoneFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.decDoneName)
          NZFileUtil.deleteAndCreateFile(decDoneFileOutput)

          val decFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.decFailName)
          NZFileUtil.deleteFile(decFailFileOutput)
        }
      } catch {
        case e: Exception =>
          logger.error(s"Something wrong when encrypting file $backupData", e)
          val decFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.decFailName)
          NZFileUtil.deleteAndCreateFile(decFailFileOutput)
      }
    }
  }



}
