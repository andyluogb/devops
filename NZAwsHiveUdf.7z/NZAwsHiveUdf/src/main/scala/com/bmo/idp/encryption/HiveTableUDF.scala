package com.bmo.idp.encryption

import java.io.File
import java.nio.file.{Path, Paths}
import java.security.{PrivateKey, PublicKey}
import java.util.Base64

import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.util._
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.{StringType, StructType}
import org.apache.spark.sql.{SaveMode, SparkSession}

object HiveTableUDF {


  case class Record(key: Int, value: String)
  case class Test(cs0:String,cs1:String,cs2:String,cs3:String,
                  cs4:String,cs5:String,cs6:String)

  def main(args:Array[String]): Unit = {

    val warehouseLocation = new File("spark-warehouse").getAbsolutePath

    val spark = SparkSession
      .builder()
      .master("local[*]")
      .appName("Spark Hive Example")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()

    val splitToInt:String  => Int = _.split("-")(0).toInt
    val decrypt_fn:(String,String) => String = (a:String,b:String) => decrypt(a,b)
    val encrypt_fn:(String,String) => String = (a:String,b:String) => encrypt(a,b)

    val splitToIntUDF = udf(splitToInt)
    val encryptUDF = spark.udf.register("encryptUDF", encrypt_fn)
    val decryptUDF = spark.udf.register("decryptUDF", decrypt_fn)

    val scalaSchema = ScalaReflection.schemaFor[Test].dataType.asInstanceOf[StructType]

    val schema = new StructType()
      .add("cs1",StringType, true)
      .add("cs2",StringType, true)
      .add("cs3",StringType, true)
      .add("cs4",StringType, true)
      .add("cs5",StringType, true)
      .add("cs6",StringType, true)
      .add("cs7",StringType, true)

    val df = spark.read
      .schema(scalaSchema)
      .option("header", "false").csv(args(0))

    df.printSchema()

    /*    val df2 = df.withColumn("age",col("age").cast(StringType))
          .withColumn("isGraduated",col("isGraduated").cast(BooleanType))
          .withColumn("jobStartDate",col("jobStartDate").cast(DateType))
        df2.printSchema()
    */

    import spark.implicits._

    val df1 = df.withColumn("ccs0", splitToIntUDF($"cs0"))
      .withColumn("ccs1", $"cs1".cast("Float"))

    df1.createOrReplaceTempView("df_table")

    val df2 = spark.sql("select ccs0 as year, max(ccs1) as sum from df_table group by ccs0 order by ccs0")
    df2.show()

    df2
      //.coalesce(1)
      .write.mode(SaveMode.Overwrite)
      .format("orc")
      .saveAsTable("page_view")

    spark.stop()

  }

  def getDataKey(pk:PrivateKey, sourceFilePath:String):Array[Byte] = {
    val inputFile = Paths.get(sourceFilePath)
    val cipherDataKeyPath:Path = Paths.get(sourceFilePath).getParent
    val cipherSecuredKeyFile = Paths.get(cipherDataKeyPath.toAbsolutePath.toString, inputFile.getFileName.toString + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = NZFileUtil.readFileToBytes(cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  def getDataKeyS3(pk:PrivateKey, sourceFilePath:String, s3Bucket:String):Array[Byte] = {
    val cipherDataKeyFolder:String = IDPS3Client.getS3PathParent(sourceFilePath)
    val fileName = IDPS3Client.getS3PathFileName(sourceFilePath)
    val cipherSecuredKeyFile = IDPS3Client.makeS3Path(cipherDataKeyFolder, fileName + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = IDPS3Client.getS3ObjectBytes(s3Bucket, cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  def createDataKey(pk:PublicKey):(Array[Byte], Array[Byte]) = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey:Array[Byte] = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    (securedKey, cipherSecuredKey)
  }

  def createDataKeyString(pk:PublicKey):(String, String) = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey:Array[Byte] = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    (Base64.getEncoder.encodeToString(securedKey), Base64.getEncoder.encodeToString(cipherSecuredKey))
  }

  def encrypt(plainText:String, keyBase64:String):String = {
    val ciphetTextBase64 = AES256Util.encrypt(plainText, keyBase64)
    ciphetTextBase64
  }

  def encrypt(plainText:String, keyBase64:Array[Byte]):String = {
    val ciphetTextBase64 = AES256Util.encrypt(plainText, keyBase64)
    ciphetTextBase64
  }

  def decrypt(ciphetTextBase64:String, keyBase64:String):String = {
    val plainText = AES256Util.decrypt(ciphetTextBase64, keyBase64)
    plainText
  }

  def decrypt(ciphetTextBase64:String, key:Array[Byte]):String = {
    val plainText = AES256Util.encrypt(ciphetTextBase64, key)
    plainText
  }

  def getPrivateKeyFromAWSSecretManager(privateLeftKeyArn:String, privateRightKeyArn:String, keyOfKey:String): PrivateKey =  {
    val privateLeftKeyStr:String = getPrivateKeyStringFromAWSSecretManager(privateLeftKeyArn, keyOfKey)
    val privateRightKeyStr:String = getPrivateKeyStringFromAWSSecretManager(privateRightKeyArn, keyOfKey)
    val privateKeyStr:String = privateLeftKeyStr.concat(privateRightKeyStr)
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    privateKey
  }

  def getPrivateKeyStringFromAWSSecretManager(privateKeyArn:String, keyOfKey:String): String =  {
    val secret = IDPSecretsClient.getSecret(privateKeyArn)
    val map = NZFileEncryptionUtil.jsonStrToMap(secret)
    val privateKeyStr:String = map.get(keyOfKey).get.asInstanceOf[String]
    privateKeyStr
  }

}
