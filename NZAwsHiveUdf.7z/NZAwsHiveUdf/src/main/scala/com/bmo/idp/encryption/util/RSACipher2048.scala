package com.bmo.idp.encryption.util

import java.security._
import java.security.spec.{PKCS8EncodedKeySpec, X509EncodedKeySpec}

import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.Cipher
import org.apache.commons.codec.binary.Base64

object RSACipher2048 extends NZLogger {
  val CRYPTO_METHOD = "RSA"
  val CYPHER = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING"
  val CRYPTO_BITS = 2048
  val CHARSET = "UTF-8"
  /*final static int CRYPTO_BITS = 4096; This will encrypt in 4093bits, note however that is slower.*/

  def encrypt(clearText: String, publickey:String): String = {
    var encryptedBase64 = ""
    try {
      val keyFac = KeyFactory.getInstance(CRYPTO_METHOD)
      val keySpec = new X509EncodedKeySpec(Base64.decodeBase64(publickey.trim.getBytes))
      val key = keyFac.generatePublic(keySpec)
      val cipher = Cipher.getInstance(CYPHER)
      cipher.init(Cipher.ENCRYPT_MODE, key)
      val encryptedBytes = cipher.doFinal(clearText.getBytes(CHARSET))
      encryptedBase64 = new String(Base64.encodeBase64(encryptedBytes))
    } catch {
      case e: Exception =>
        logger.error("Error message", e)
    }
    encryptedBase64.replaceAll("(\\r|\\n)", "")
  }

  def decrypt(encryptedBase64: String, privateKey:String): String = {
    var decryptedString = ""
    try {
      val keyFac = KeyFactory.getInstance(CRYPTO_METHOD)
      val keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.trim.getBytes))
      val key = keyFac.generatePrivate(keySpec)
      val cipher = Cipher.getInstance(CYPHER)
      cipher.init(Cipher.DECRYPT_MODE, key)
      val encryptedBytes = Base64.decodeBase64(encryptedBase64)
      val decryptedBytes = cipher.doFinal(encryptedBytes)
      decryptedString = new String(decryptedBytes)
    } catch {
      case e: Exception =>
        logger.error("Error message", e)
    }
    decryptedString
  }


  def getKeyPair: KeyPair  = {
    var kp : KeyPair  = null
    try {
      val kpg = KeyPairGenerator.getInstance(CRYPTO_METHOD)
      kpg.initialize(CRYPTO_BITS)
      kp = kpg.generateKeyPair
    } catch {
      case e: Exception =>
        logger.error("Error message", e)
    }
    kp
  }

  def test={
      val kp: KeyPair = getKeyPair
      val publicKey: PublicKey = kp.getPublic
      val publicKeyBytes: Array[Byte] = publicKey.getEncoded
      val PUB_KEY = new String(Base64.encodeBase64(publicKeyBytes))
      //Save the public key so it is not generated each and every time
      val privateKey: PrivateKey = kp.getPrivate
      val privateKeyBytes: Array[Byte] = privateKey.getEncoded
      val PRIVATE_KEY = new String(Base64.encodeBase64(privateKeyBytes))
      //Also Save the private key so it is not generated each and every time
    val clearText = "qqqqwwwwqqqqwwww"
    val cipherText = encrypt(clearText, PUB_KEY)
    val decryptText = decrypt(cipherText, PRIVATE_KEY)
    logger.info(s"\nclearText:$clearText\ncipherText:$cipherText\ndecryptText:$decryptText")
  }
}
