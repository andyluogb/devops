package com.bmo.idp.encryption.util

import java.nio.ByteBuffer

import com.amazonaws.services.kms.model.{DecryptRequest, EncryptRequest, GenerateDataKeyRequest}
import com.amazonaws.services.kms.{AWSKMS, AWSKMSClientBuilder}
import com.amazonaws.util.BinaryUtils
import com.bmo.idp.encryption.logger.NZLogger

object IDPKMSClient1 extends NZLogger {
  val keyArn = "arn:aws:kms:us-east-2:534454167231:key/6141e9b4-875a-4873-879d-2b90bb37ba53" // //symmetric


  implicit val kmsClient: AWSKMS = AWSKMSClientBuilder.standard.build

  def generateDataKey(): (String, String)  = {
    import com.amazonaws.services.kms.model.GenerateDataKeyResult
    val request = new GenerateDataKeyRequest().withKeyId(keyArn)
    .withKeySpec("AES_256")
    val response: GenerateDataKeyResult  = kmsClient.generateDataKey(request)

    (BinaryUtils.toBase64(response.getPlaintext.array()), BinaryUtils.toBase64(response.getCiphertextBlob.array()))

  }


  def encrypt(plainDataKey:String): String  = {

    val plainDataKeyBytes:Array[Byte] = BinaryUtils.fromBase64(plainDataKey)

    val plaintextBlob = ByteBuffer.wrap(plainDataKeyBytes)

    val req = new EncryptRequest().withKeyId(keyArn).withPlaintext(plaintextBlob)
    val ciphertextBlob = kmsClient.encrypt(req).getCiphertextBlob

    val cipherBytes = BinaryUtils.copyAllBytesFrom(ciphertextBlob)
    val ciphertext = BinaryUtils.toBase64(cipherBytes)
    ciphertext
  }

  def decrypt(cipherDataKey:String): String = {
   //val plaintext = ByteBuffer.wrap(plainTextStr.getBytes("UTF-8"))
    val cipherBytes:Array[Byte] = BinaryUtils.fromBase64(cipherDataKey)
    val cipherBlob:ByteBuffer = ByteBuffer.wrap(cipherBytes)

    val req = new DecryptRequest().withKeyId(keyArn).withCiphertextBlob(cipherBlob)
    val plainBlob: ByteBuffer = kmsClient.decrypt(req).getPlaintext
    val plainDataKey = BinaryUtils.copyAllBytesFrom(plainBlob)

    BinaryUtils.toBase64(plainDataKey)

  }


}
