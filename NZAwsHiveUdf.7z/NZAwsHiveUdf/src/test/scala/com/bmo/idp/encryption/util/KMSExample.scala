package com.bmo.idp.encryption.util

import java.nio.charset.StandardCharsets
import java.security.Security

import com.bmo.idp.encryption.logger.NZLogger

object KMSExample extends NZLogger {

  def main(args:Array[String]): Unit = {
      logger.info("=====Sample KMS")
    val currentDirectory = new java.io.File(".").getCanonicalPath
    logger.info("=====Scurrent:" + currentDirectory)
    Security.setProperty("crypto.policy", "unlimited")
    //testSymmClient
    testSymmClient1
    //testAsymmClient
    //testIDPEncryptionUtil
    //testRsaUtil
    //test2RsaUtil
    //testAES256Util
    //testSecretManager
  }

  def testAES256Util = {

    Security.setProperty("crypto.policy", "unlimited")

    val secretkey = SecretKeyGenerator.genSecuredKey256
    val secretkeyStr = SecretKeyGenerator.secretKeyToString(secretkey)
    logger.info("secretkeyStr: " + secretkeyStr)

    val originalString = "1234567890123456" + "1234567890123456" + "1234567890123456"
    //val secretKey = "howtodoinjava.com"

/*    val encryptedString = AES256Util.encrypt(originalString, secretkeyStr)
    val decryptedString = AES256Util.decrypt(encryptedString, secretkeyStr)
    logger.info("======demo1 no IV")
    logger.info(originalString)
    logger.info(encryptedString)
    logger.info(decryptedString)*/

    val iv16 = SecretKeyGenerator.genIV16
    val plaintext: Array[Byte] = originalString.getBytes(StandardCharsets.UTF_8)
    val encryptedString16 = AES256Util.encrypt(plaintext, secretkey, iv16)
    val decryptedString16 = AES256Util.decrypt(encryptedString16, secretkey, iv16)

    logger.info("======demo2 with IV")
    logger.info(originalString)
    logger.info("originalString length:"  + originalString.length)
    logger.info("encryptedString16 length:"  + encryptedString16.length)
    logger.info("decryptedString16 length:"  + decryptedString16.length)

  }

  def testRsaUtil = {
     //RSAUtil.testRsa
    var message = "0123456789123456"
    RSAUtil.testRsaLength(message)
    message = "0123456789123456" * 15
    RSAUtil.testRsaLength(message)

  }

  def test2RsaUtil = {
    //val publicKeyStr = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlveHohOLqyH0A90ylBCT\nMep7HGo4/3Rwy8DW6XkOYkU2GAELiB6zczdB3mQpm3jKpa84CUyOepQCNBcScUto\nIQlLaJTam8XhkP4sn3mUvjU6LTnHC2PqGj+q+oE6NtFrfXrSpbXe/hZY9MKooD8T\nsXvmwBO3RezHcZdiDykbXlFiN5psqkZsWeaWXM4Ax3z7XQw+auJIImXqM1SQERAk\nLHP5Bo+Cer79NBsw5KlhZp8H9cjt/E7FZGBoSSfOJNsnxYXOZewSFXkZUmAw+ice\nc/jv1Ff6YEijFfRjW+0/IYWJS+dgdlkFCTuTsZkoI1pzTRvnydbkfq1wSFO25aJ1\nxQIDAQAB\n-----END PUBLIC KEY-----"
    val publicKeyStr = IDPKMSClient2.getPublicKey()

    val pk = RSAUtil.getPublicKeyFromString(publicKeyStr)
    val res = RSAUtil.rsaSha256Encrypt(pk, "123456".getBytes(StandardCharsets.UTF_8))

    val decry = IDPKMSClient2.decrypt(new String(res, StandardCharsets.UTF_8))

    logger.info("======")
    logger.info(res)
    logger.info("======")
    logger.info(decry)
    logger.info("======")

  }

  def testIDPEncryptionUtil = {
    val str1 = IDPEncryptionUtil.encrypt("1234567")
    val str2 = IDPEncryptionUtil.decrypt(str1)

    logger.info("=====str1:" + str1)
    logger.info("=====str2:" + str2)

  }

  def testSymmClient ={
    val dataKey:String =SecretKeyGenerator.generateSecureRandomBase64String

    val cipherText:String = IDPKMSClient1.encrypt(dataKey)
    val dataKey1:String = IDPKMSClient1.decrypt(cipherText)

    logger.info("=====dataKey:" + dataKey)
    logger.info("=====cipherText:" + cipherText)
    logger.info("=====decryptedDataKey:" + dataKey1)
  }

  def testSymmClient1 ={
    val (clearKey, cipherKey) = IDPKMSClient1.generateDataKey
    val cipherText:String = IDPKMSClient1.encrypt(clearKey)
    val clearText:String = IDPKMSClient1.decrypt(cipherKey)
    val clearTextCipherText:String = IDPKMSClient1.decrypt(cipherText)

    logger.info(" =====clearKey:" + clearKey)
    logger.info("=====clearText:" + clearText)
    logger.info("=====cipherKey:" + cipherKey)
    logger.info("=====cipherText:" + cipherText)
    logger.info("=====clearTextCipherText:" + clearTextCipherText)

  }

  def testAsymmClient ={

    val dataKey:String =SecretKeyGenerator.generateSecureRandomBase64String

    val publicKey = IDPKMSClient2.getPublicKey()

    val cipherText:String = IDPKMSClient2.encrypt(dataKey)
    val dataKey1:String = IDPKMSClient2.decrypt(cipherText)

    logger.info("=====dataKey:" + dataKey)
    logger.info("=====cipherText:" + cipherText)
    logger.info("=====decryptedDataKey:" + dataKey1)

    logger.info("=====publicKey:" + publicKey)
  }

  def testSecretManager(): Unit =  {
    val privateKeyArn = "arn:aws:secretsmanager:us-east-2:534454167231:secret:lgbSecrets-yn9aab"
    val secret = IDPSecretsClient.getSecret(privateKeyArn)
    logger.info("=====secret:" + secret)
    val map = NZFileEncryptionUtil.jsonStrToMap(secret)
    val publicKey = map.get("publicKey").get
    val privateKey = map.get("privateKey").get


    val pk = RSAUtil.getPublicKeyFromString(publicKey.asInstanceOf[String])
    val res = RSAUtil.rsaSha256Encrypt(pk, "123456".getBytes(StandardCharsets.UTF_8))
    val priv = RSAUtil.getPrivKeyFromStr(privateKey.asInstanceOf[String])
    val res1 = new String(RSAUtil.rsaSha256Decrypt(priv, res), StandardCharsets.UTF_8)

    logger.info("=====publicKey:" + publicKey)
    logger.info("=====privateKey:" + privateKey)

    logger.info("=====res1:" + res1)
  }




}
