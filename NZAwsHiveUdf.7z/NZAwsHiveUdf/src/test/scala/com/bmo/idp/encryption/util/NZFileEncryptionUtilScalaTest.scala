package com.bmo.idp.encryption.util

import org.scalatest._

import scala.collection.mutable

class NZFileEncryptionUtilScalaTest  extends FunSuite  with BeforeAndAfter {
  before {
    println("starting testing")
  }

  test("A Stack should pop values in last-in-first-out order")  {
    val stack = new mutable.Stack[Int]
    stack.push(1)
    stack.push(2)
    assert(stack.pop() === 2)
    assert(stack.pop() === 1)
  }


  test("throw NoSuchElementException if an empty stack is popped")  {
    test1
  }

  test("throw NoSuchElementExceptio2 if an empty stack is popped")  {
    test2
  }

  after {
    println("end of testing")
  }


  def test1()= {
    val stack = new mutable.Stack[Int]
    stack.push(1)
    stack.push(2)
    assert(stack.pop() === 2)
    assert(stack.pop() === 1)
  }
  def test2()= {
    val emptyStack = new mutable.Stack[String]
    intercept[NoSuchElementException]{
      emptyStack.pop()
    }
  }

  def testRSAUtil={
    RSAUtil.testRsa
    RSAUtil.testRsaLength("1234556")
  }

  def testRSACipher2048 = {
    val l = RSACipher2048
    l.test
  }
}
