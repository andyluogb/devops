package com.bmo.idp.encryption.util

import java.io.{BufferedReader, BufferedWriter, FileWriter, InputStream, InputStreamReader}
import java.nio.file.Paths

import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.logger.NZLogger
import org.apache.commons.lang.time.StopWatch

import scala.collection.immutable.Stream.StreamBuilder

object NZFileEncryptionUtilTest  extends NZLogger {
  def main(args: Array[String]) = {
    //testCreateTextFile
    //testRSAUtil
    //testEncryption
    val watch: StopWatch = new StopWatch

    /*watch.start
    decryptInputStreamAndCopy("s3", "1MFile")
    watch.stop
    System.out.println("Time Elapsed: " + watch.getTime) // Prints: Time Elapsed: 2501
    watch.reset()
    watch.start
    decryptInputStreamAndCopy("s3", "10MFile")
    watch.stop
    System.out.println("Time Elapsed: " + watch.getTime) // Prints: Time Elapsed: 2501*/
    watch.start
    //decryptS3InputStreamAndCopy("gblsoft", "10MFile")
    //downloadS3InputStreamAndCopy("gblsoft", "10MFile")
    downloadS3InputStreamAndCopy("gblsoft", "1MFile")
    watch.stop
    System.out.println("Time Elapsed: " + watch.getTime) // Prints: Time Elapsed: 2501

  }

  def testRSAUtil={
    RSAUtil.testRsa
    RSAUtil.testRsaLength("1234556")
  }

  def testRSACipher2048 = {
    val l = RSACipher2048
    l.test
  }

  def testCreateTextFile() = {
    val str : Stream[String] = testStreamBuilder
    val filePath = Paths.get("s3", "10MFile.txt")
    val file = filePath.toFile
    val bw = new BufferedWriter(new FileWriter(file))
    str.foreach(s=>bw.write(s+System.lineSeparator()))
    bw.close()
  }

  def createTextFile(root:String, fileName:String, str : Stream[String] ) = {
    val filePath = Paths.get(root, fileName)
    val file = filePath.toFile
    val bw = new BufferedWriter(new FileWriter(file))
    str.foreach(s=>bw.write(s+System.lineSeparator()))
    bw.close()
  }


  def testStreamBuilder (): Stream[String] = {
    val sb = new StreamBuilder[String]
    for (i<-0 until 10000000) {
      sb+=i.toString
    }
    sb.result()
  }

  def testEncryption() = {
    val source = Paths.get("s3", "100kFile.txt")
    val target = Paths.get("s3", "100kFile_enc.txt")
    val cipherFile = Paths.get("s3", "100kFile.txt"+"."+NZFileEncryptConfig.cipherKeyFileName)

    val dataKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val publicKey = NZFileEncryptionUtil.getPublicKeyFromString()
    val cipherDataKey = RSAUtil.rsaSha256Encrypt(publicKey, dataKey)
    NZFileEncryptionUtil.encryptAndCopy(source.toFile, target.toFile, dataKey)
    NZFileUtil.writeBytesToFile(cipherDataKey, cipherFile.toFile)
  }

  def getInputStreamToStringStream(is: InputStream):Stream[String] = {
    val rd: BufferedReader = new BufferedReader(new InputStreamReader(is, "UTF-8"))
    val sb = new StreamBuilder[String]
    try {
      var line = rd.readLine
      while (line != null) {
        sb+=line
        line = rd.readLine
      }
    } finally {
      rd.close
    }
    sb.result()
  }

  def decryptInputStreamAndCopy(root:String, fileName:String)= {
    val source = Paths.get(root, fileName+"_enc.txt")
    val dataKeyFile = Paths.get(root, fileName+".txt"+"."+NZFileEncryptConfig.cipherKeyFileName)
    val cipherDataKey = NZFileUtil.readFileToBytes(dataKeyFile)
    val privateKey = NZFileEncryptionUtil.getPrivateKeyFromString()
    val dataKey = RSAUtil.rsaSha256Decrypt(privateKey, cipherDataKey)
    val is = NZFileUtil.getInputStream(source.toFile)
    val decryptCipher = AES256Util.createDecryptedCipher(dataKey)
    val wis = AES256Util.wrapInputStream(is, decryptCipher)
    val stream = getInputStreamToStringStream(wis)
    createTextFile(root, fileName+"_dec.txt", stream)
  }

  def decryptS3InputStreamAndCopy(bucketName:String, fileName:String)= {
    val (meta, s3is) = IDPS3Client.getS3ObjectInputStream(bucketName, "nz/"+fileName+"_enc.txt")
    val (meta1, cipherDataKey) = IDPS3Client.getS3ObjectInputStream(bucketName, "nz/"+fileName+".txt"+"."+NZFileEncryptConfig.cipherKeyFileName)
    val dataKeyBytes = NZFileUtil.toByteArray(cipherDataKey)
    val privateKey = NZFileEncryptionUtil.getPrivateKeyFromString()
    val dataKey = RSAUtil.rsaSha256Decrypt(privateKey, dataKeyBytes)

    val decryptCipher = AES256Util.createDecryptedCipher(dataKey)
    val wis = AES256Util.wrapInputStream(s3is, decryptCipher)
    val stream = getInputStreamToStringStream(wis)
    createTextFile("s3", fileName+"_dec_s3.txt", stream)
  }

  def downloadDecryptS3InputStreamAndCopy(bucketName:String, fileName:String)= {
    val (meta, s3is) = IDPS3Client.getS3ObjectInputStream(bucketName, "nz/"+fileName+"_enc.txt")
    val (meta1, cipherDataKey) = IDPS3Client.getS3ObjectInputStream(bucketName, "nz/"+fileName+".txt"+"."+NZFileEncryptConfig.cipherKeyFileName)
    val dataKeyBytes = NZFileUtil.toByteArray(cipherDataKey)
    val privateKey = NZFileEncryptionUtil.getPrivateKeyFromString()
    val dataKey = RSAUtil.rsaSha256Decrypt(privateKey, dataKeyBytes)

    val decryptCipher = AES256Util.createDecryptedCipher(dataKey)
    val wis = AES256Util.wrapInputStream(s3is, decryptCipher)
    //val stream = getInputStreamToStringStream(wis)
    //createTextFile("s3", fileName+"_dec_s3.txt", stream)
    val outPath = Paths.get("s3", fileName+"_dec_s3_d.txt")
    val os = NZFileUtil.getOutputStream(outPath.toFile)
    NZFileUtil.copy(wis, os)
    wis.close()
    os.close()
  }

  def downloadS3InputStreamAndCopy(bucketName:String, fileName:String)= {
    val (meta, s3is) = IDPS3Client.getS3ObjectInputStream(bucketName, "nz/"+fileName+".txt")
    val outPath = Paths.get("s3", fileName+"_s3_d.txt")
    val os = NZFileUtil.getOutputStream(outPath.toFile)
    NZFileUtil.copy(s3is, os)
    s3is.close()
    os.close()
  }
}
