package com.bmo.idp.encryption

import org.apache.spark.sql.SparkSession

object Hive2Demo {
  //Class.forName("org.apache.hive.jdbc.HiveDriver").newInstance()

  import org.apache.spark.sql.jdbc.JdbcDialect

  private case object HiveDialect extends JdbcDialect {
    override def canHandle(url : String): Boolean = url.startsWith("jdbc:hive2")
    override def quoteIdentifier(colName: String): String = {
      colName.split('.').map(part => s"'$part'").mkString(".")
    }
  }
  def main(args:Array[String]): Unit = {
    //val conf = new SparkConf().setAppName("SparkHive2Demo").setMaster("local[*]")
    //val sc = new SparkContext(conf)

    //JdbcDialects.registerDialect(HiveDialect)

    val spark = SparkSession
      .builder()
      .appName("Spak Hive2 Demo")
      .master("local[*]")
      .getOrCreate()

    val jdbcDF = spark.read
      .format("jdbc")
      .option("url", "jdbc:hive2://127.0.0.1:10000/default")
      .option("dbtable", "page_view")
      .option("user", "hive")
      .option("password", "hive")
      .option("driver", "org.apache.hive.jdbc.HiveDriver")
      .load()

    println("able to connect---------------")

    jdbcDF.show(10)
    jdbcDF.printSchema()
    //jdbcDF.createOrReplaceGlobalTempView("pageView")

    //val sqlDF = spark.sql("select * from page_view")
    println("Start println-----")
    jdbcDF.collect().foreach(println)
    println("end println-----")
    jdbcDF.show(false)

    spark.close()

  }

}
