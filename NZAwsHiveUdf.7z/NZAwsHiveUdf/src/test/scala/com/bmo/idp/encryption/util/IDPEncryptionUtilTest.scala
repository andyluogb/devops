package com.bmo.idp.encryption.util

import java.security.PublicKey
import java.util.Base64

import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.Cipher
import javax.crypto.spec.{IvParameterSpec, SecretKeySpec}

object IDPEncryptionUtilTest extends NZLogger {
  private val Algorithm = "AES/CBC/PKCS5Padding"
  private val Key = new SecretKeySpec(Base64.getDecoder.decode("DxVnlUlQSu3E5acRu7HPwg=="), "AES")
  private val IvSpec = new IvParameterSpec(new Array[Byte](16))

  val AdminKey = "Dx$V!nl%Ul^QS&u3*E5@acR-u7HPwg=="

  def main(args: Array[String]) = {
    //testCreateKeyAndEncrypt
    //testBase64length
    //testRsa2048Length
    //testCipherSize
    //testSaltedLength
    testAes256Util
  }


  def encrypt(text: String): String = {
    val cipher = Cipher.getInstance(Algorithm)
    cipher.init(Cipher.ENCRYPT_MODE, Key, IvSpec)

    new String(Base64.getEncoder.encode(cipher.doFinal(text.getBytes("utf-8"))), "utf-8")
  }

  def decrypt(text: String): String = {
    val cipher = Cipher.getInstance(Algorithm)
    cipher.init(Cipher.DECRYPT_MODE, Key, IvSpec)

    new String(cipher.doFinal(Base64.getDecoder.decode(text.getBytes("utf-8"))), "utf-8")
  }

  def testCreateKeyAndEncrypt = {
    val publicKey:String = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuor8i/Two/GdvUF2Q54AGhjHu+VHMmEd8Z0vjgqpI3pshr74s99wyeiyEObd06rl+lilmBMox9tT3w5RGb+wz7AqQvSEJH4ruc2/+//54rvcGczD0ZMGhLec1H8SYCbOCOruIMulwJiS6w65NvEoeqrRlugsMvNQWZwjnF9pKI0MZyBn11D+xJmrHFBlb1RbdXvpx0GG8UXMRQA/5BHzTtpt5iNgR3cWaHoAQQ+NEaPGxSSkuQbKJoX67XxLuGGEVdnE3kiXkhPSlkNJmgsXYhHaGUxyF5Fu+7SSsfGBs87jYoeAZwIIuJe7/gxsPIsH+7IEaMZ5AslqCHmiAZnO2QIDAQAB\n-----END PUBLIC KEY-----"
    val pk:PublicKey = RSAUtil.getPublicKeyFromString(publicKey)
    val (a,b) = createDataKey(pk)
    logger.info(s"dataKey:$a")
    logger.info(s"cipherKey:$b")
    val c = AES256Util.encrypt("ABCD", a)
    logger.info(s"cipherText:$c")
    val d = AES256Util.decrypt(c, a)
    logger.info(s"clearText:$d")
  }

  def createDataKey(pk:PublicKey):(String, String) = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    (Base64.getEncoder.encodeToString(securedKey),  Base64.getEncoder.encodeToString(cipherSecuredKey))
  }

  def testBase64length = {
    var str = ""
    for (i <- 1 to 100) {
      str += "1"
      val base64 = Base64.getEncoder.encode(str.getBytes("utf-8"))
      logger.info(s"${str.length} ==> ${base64.length}")
    }
  }

    def testRsa2048Length = {
      val publicKey:String = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuor8i/Two/GdvUF2Q54AGhjHu+VHMmEd8Z0vjgqpI3pshr74s99wyeiyEObd06rl+lilmBMox9tT3w5RGb+wz7AqQvSEJH4ruc2/+//54rvcGczD0ZMGhLec1H8SYCbOCOruIMulwJiS6w65NvEoeqrRlugsMvNQWZwjnF9pKI0MZyBn11D+xJmrHFBlb1RbdXvpx0GG8UXMRQA/5BHzTtpt5iNgR3cWaHoAQQ+NEaPGxSSkuQbKJoX67XxLuGGEVdnE3kiXkhPSlkNJmgsXYhHaGUxyF5Fu+7SSsfGBs87jYoeAZwIIuJe7/gxsPIsH+7IEaMZ5AslqCHmiAZnO2QIDAQAB"
      val pk:PublicKey = RSAUtil.getPublicKeyFromString(publicKey)
      var str = ""
      for (i <- 1 to 100) {
        str += "1"
        val bytes = str.getBytes("utf-8")
        val enc = RSACipher2048.encrypt(str, publicKey)
        logger.info(s"${str.length} ==> ${enc.length}")
      }
    }

  def testCipherSize(): Unit = {
    val IV =  AES256Util.IV
    IV.foreach(u=>print(u + " "))
    logger.info(IV.length)
    val iv = SecretKeyGenerator.generateSecureRandomBytes
    iv.foreach(u=>print(u + " "))
    logger.info(iv.length)
    val key="1234567890" + "1234567890" + "1234567890" + "1234567890"
    val spec = AES256Util.createSaltedPBESecretKeySpec(key, AES256Util.SALT.getBytes)
    val cipher = AES256Util.createEncryptSaltedCipher(key, AES256Util.SALT.getBytes)
    logger.info(cipher)
  }

  def testSaltedLength = {
    val salt = SecretKeyGenerator.generateSecureRandomBytes
    val saltBase64 = Base64.getEncoder.encodeToString(salt)
    logger.info(salt.length)
    salt.foreach(u=>print(u + " "))
    println
    logger.info(saltBase64.length)
    logger.info(saltBase64)
    val decSalt = Base64.getDecoder.decode(saltBase64)
    logger.info(decSalt.length)
    decSalt.foreach(u=>print(u + " "))
    println
  }

  def testAes256Util = {
    val clearText = "abcd"
    val password = "asdfsdafsadf"
    val key = SecretKeyGenerator.genSecuredKey256ByteArray

    val encryptedSalted = AES256Util.encryptSalted(clearText, password)
    val decryptedSalted = AES256Util.decryptSalted(encryptedSalted, password)

    logger.info(s"clearText:${clearText}")
    logger.info(s"encryptedSalted:${encryptedSalted}")
    logger.info(s"decryptedSalted:${decryptedSalted}")

    val encryptedNotSalted:String = AES256Util.encrypt(clearText, key)
    val decryptedNotSalted = AES256Util.decrypt(encryptedNotSalted, key)

    logger.info(s"clearText:${clearText}")
    logger.info(s"encryptedNotSalted:${encryptedNotSalted}")
    logger.info(s"decryptedNotSalted:${decryptedNotSalted}")

  }
}
