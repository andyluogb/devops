package com.bmo.idp.encryption

import java.io.File

import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.{StringType, StructType}
import org.apache.spark.sql.{SaveMode, SparkSession}

object HiveTable {


  case class Record(key: Int, value: String)
  case class Test(cs0:String,cs1:String,cs2:String,cs3:String,
                  cs4:String,cs5:String,cs6:String)

  def main(args:Array[String]): Unit = {

    val warehouseLocation = new File("spark-warehouse").getAbsolutePath

    val spark = SparkSession
      .builder()
      .master("local[*]")
      .appName("Spark Hive Example")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()

    val splitToInt:String  => Int = _.split("-")(0).toInt

    import org.apache.spark.sql.functions.udf
    val splitToIntUDF = udf(splitToInt)

    val scalaSchema = ScalaReflection.schemaFor[Test].dataType.asInstanceOf[StructType]

    val schema = new StructType()
      .add("cs1",StringType, true)
      .add("cs2",StringType, true)
      .add("cs3",StringType, true)
      .add("cs4",StringType, true)
      .add("cs5",StringType, true)
      .add("cs6",StringType, true)
      .add("cs7",StringType, true)

    val df = spark.read
      .schema(scalaSchema)
      .option("header", "false").csv(args(0))

    df.printSchema()

    /*    val df2 = df.withColumn("age",col("age").cast(StringType))
          .withColumn("isGraduated",col("isGraduated").cast(BooleanType))
          .withColumn("jobStartDate",col("jobStartDate").cast(DateType))
        df2.printSchema()
    */

    import spark.implicits._

    val df1 = df.withColumn("ccs0", splitToIntUDF($"cs0"))
      .withColumn("ccs1", $"cs1".cast("Float"))

    df1.createOrReplaceTempView("df_table")

    val df2 = spark.sql("select ccs0 as year, max(ccs1) as sum from df_table group by ccs0 order by ccs0")
    df2.show()

    df2
      //.coalesce(1)
      .write.mode(SaveMode.Overwrite)
      .format("orc")
      .saveAsTable("page_view")

    spark.stop()

  }

}
