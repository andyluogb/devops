package com.example.schemabuilder;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;

//@Configuration
public class DataSources {
    //@ConfigurationProperties(prefix = "spring.datasource.mydb")
    //@Bean
    public DataSource mydb() {
        System.out.println("DB Connected");
        return DataSourceBuilder.create().build();
    }
}
