package com.example.schemabuilder.event;


import org.springframework.context.ApplicationListener;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Component;

import com.example.schemabuilder.model.StockPrice;

import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;

@Component
public class StockPriceEventListener implements ApplicationListener<StockPriceEvent> {

    private final SubscribableChannel subscribableChannel = MessageChannels.publishSubscribe().get();

    public Flux<StockPrice> getStockPrice() {
        return Flux.create(sink -> {
            MessageHandler handler = message -> sink.next(StockPriceEvent.class.cast(message.getPayload()).getEvent());
            sink.onCancel(() -> {
            	System.out.println("cancel getStockPrice event");
            	subscribableChannel.unsubscribe(handler);
            });
            subscribableChannel.subscribe(handler);
        }, FluxSink.OverflowStrategy.LATEST);
    }

    @Override
    public void onApplicationEvent(StockPriceEvent event) {
        subscribableChannel.send(new GenericMessage<>(event));
    }
}
