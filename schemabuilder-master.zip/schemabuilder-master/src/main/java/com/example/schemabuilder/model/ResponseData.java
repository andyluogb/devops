package com.example.schemabuilder.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ResponseData {
	
	private Map<String, List<Map<String, Object>>> dataMap =  new HashMap<String, List<Map<String, Object>>>();

	
	public ResponseData() {
	}

	public void putData(String key, List<Map<String, Object>> value) {
		dataMap.put(key, value);
	}

	public Map<String, List<Map<String, Object>>> getDataMap() {
		return dataMap;
	}

	public void setDataMap(Map<String, List<Map<String, Object>>> dataMap) {
		this.dataMap = dataMap;
	}

}
