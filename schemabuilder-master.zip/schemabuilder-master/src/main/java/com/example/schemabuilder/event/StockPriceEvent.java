package com.example.schemabuilder.event;

import org.springframework.context.ApplicationEvent;

import com.example.schemabuilder.model.StockPrice;

public class StockPriceEvent extends ApplicationEvent {

    private final StockPrice event;

    public StockPriceEvent(Object source, StockPrice event) {
        super(source);
        this.event = event;
    }

    public StockPrice getEvent() {
        return event;
    }
    
}
