package com.example.schemabuilder.graphql;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.google.common.collect.ImmutableMap;

@Component
public class MockMemData {
    private List<Map<String, Object>> books = Arrays.asList(
            Map.of("id", "book-1",
                    "name", "Harry Potter ",
                    "pageCount", "223",
                    "rrr1", "rrr1", 
                    "authorId", "author-1",
                    "rrr2", "rrr2",
                    "rrr3", "rrr3",
                    "rrr4", "rrr4",
                    "rrr5", "rrr5"
                    ),
            Map.of("id", "book-2",
                    "name", "Moby Dick",
                    "pageCount", "635",
                    "authorId", "author-2"),
            Map.of("id", "book-3",
                    "name", "Interview with the vampire",
                    "pageCount", "371",
                    "authorId", "author-3")
    );

    private List<Map<String, Object>> authors = Arrays.asList(
            Map.of("id", "author-1",
                    "firstName", "Joanne",
                    "res1", "res1",
                    "res2", "res2",  
                    "lastName", "Rowling"),
            Map.of("id", "author-2",
                    "firstName", "Herman",
                    "res1", "res1",
                    "lastName", "Melville"),
            Map.of("id", "author-3",
                    "firstName", "Anne",
                    "lastName", "Rice")
    );

    private List<Map<String, Object>> customers = Arrays.asList(
            ImmutableMap.of("name", "John Smith",
                    "address", "123 Main St.",
                    "contact", "1-111-111-11",
                    "email", "john@test.com"),
            ImmutableMap.of("name", "Linda Woods",
                    "address", "89 Woods Ave.",
                    "contact", "2-222-222-22",
                    "email", "linda@test.com"),
            ImmutableMap.of("name", "Betty Berry",
                    "address", " 123 Bay St.",
                    "contact", "3-333-333-33",
                    "email", "betty@test.com")
    );   
    
    private  Map<String, List<Map<String, Object>>> mockData = new HashMap<String, List<Map<String, Object>>>();
    
    public MockMemData() {
    	mockData.put("customer", customers);
    	mockData.put("book", books);
    	mockData.put("author", authors);
    }
    
    public List<Map<String, Object>> getMockData(String tableName ) {
    	return mockData.get(tableName);
    }

}
