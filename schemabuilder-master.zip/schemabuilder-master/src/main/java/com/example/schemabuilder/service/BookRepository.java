package com.example.schemabuilder.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository extends BaseRepository {
	public List<Map<String, Object>> findAll(List<String> columnNames) throws Exception {
		return super.findAll(columnNames, "book");
	}	
	public List<Map<String, Object>> findAll(List<String> columnNames, int start, int limit) throws Exception {
		return super.findAll(columnNames, "book", start, limit);
	}	
}
