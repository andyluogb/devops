package com.example.schemabuilder.controller;

import java.util.Arrays;

public class QueryStringParser {
	
	//public static void main(String[] args) {
	//	System.out.println(parse("select a,b,c from t where a > 0 and b < 10"));
	//	System.out.println(parse("select a,b,c from t "));
	//}
	
	public static String parse(String query) {
		String theQuery = query.toLowerCase();
		
		int p0 = theQuery.indexOf("select");
		int p1 = theQuery.indexOf("from");
		int p2 = theQuery.indexOf("where");
		p2 = (p2<0)?theQuery.length():p2;
		
		String columns = theQuery.substring(p0+6, p1);
		String table = theQuery.substring(p1+4, p2);
		String where = theQuery.substring(p2, theQuery.length());
		
		return String.format("%s {%s}", table.toLowerCase(), columns.replace(",", " ").toUpperCase());
	}
	

}
