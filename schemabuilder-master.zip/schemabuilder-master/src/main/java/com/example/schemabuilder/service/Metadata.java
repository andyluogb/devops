package com.example.schemabuilder.service;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.GraphQLError;
import graphql.Scalars;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLNonNull;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLScalarType;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.SchemaPrinter;

@Component
public class Metadata {

    public DatabaseMetaData databaseMetaData;

    public ArrayList<String> tables = null;
    public SchemaPrinter schemaPrinter = new SchemaPrinter();
    
    public Map<String, Set<String>> schemaNames = new HashMap<String, Set<String>>();

    
    @PostConstruct
    public void init() throws Exception {
        //Connection connection = DriverManager.getConnection("jdbc:teiid:customer@mm://localhost:31000", "sa", "sa");
    	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/world", "aluo", "aluo");
        databaseMetaData = connection.getMetaData();
    }


    public void DisplayMetaData() throws Exception {
        createSchema(null, "city", "city");
        //getTableMetaData();
    }

    public void getTableMetaData() throws Exception {    	

        String table[] = {"TABLE"};

        ResultSet resultSet = databaseMetaData.getTables(null,null,null,table);
        tables = new ArrayList();

        while(resultSet.next()) {
            tables.add(resultSet.getString("TABLE_NAME"));
        }

        for(String actualTable : tables) {

            createSchema(null, actualTable, actualTable);

        }
    }
    
    public boolean isFieldNameInSchema(String fieldName, String schemaName) {
    	Set<String> set = schemaNames.get(schemaName.toLowerCase());
    	return StringUtils.isBlank(fieldName) || (set!=null && !set.isEmpty() && Arrays.stream(fieldName.split(",")).filter(f->!StringUtils.isBlank(f)).map(String::trim).allMatch(set::contains));
    }

    public String createSchema(String dbName, String tableName, String schemaName) throws Exception {
    	ResultSet resultSet = databaseMetaData.getColumns(dbName, null, tableName, null);

        GraphQLObjectType.Builder graphQLObjectType = GraphQLObjectType.newObject().name(schemaName);
        
        Set<String> filedNames = new HashSet<String>();
        
        while (resultSet.next()) {
        	String field = resultSet.getString("COLUMN_NAME");
        	filedNames.add(field);
            graphQLObjectType                        
                        .field(GraphQLFieldDefinition.newFieldDefinition()
                                .name(field)
                                //.type(GraphQLNonNull.nonNull(ReturnType(resultSet.getString("TYPE_NAME")))));
                                .type(ReturnType(resultSet.getString("TYPE_NAME"))));
        }
        schemaNames.put(schemaName.toLowerCase(), filedNames);

        String printSchema = schemaPrinter.print(graphQLObjectType.build());
        //System.out.println(printSchema);
        return printSchema;
    }
    
    
    public List<String> getColumns(String tableName) throws Exception {
    	ResultSet resultSet = databaseMetaData.getColumns(null, null, (String) tableName, null);
        List<String> columns = new ArrayList<String>();
        while (resultSet.next()) {
        	columns.add(resultSet.getString("COLUMN_NAME"));
        }
        return columns;
    }

    //TODO : Add other types
    public GraphQLScalarType ReturnType(String type) {
        if(type.equals("long"))
            return Scalars.GraphQLLong;
        else if (type.equals("string"))
            return Scalars.GraphQLString;
        else if (type.equals("int"))
        	return Scalars.GraphQLInt;
        return Scalars.GraphQLString;
    }
    
    public String createSchemaFromMap() throws Exception {   	
    	
    	GraphQLObjectType.Builder graphQLObjectType = GraphQLObjectType.newObject();
    	
    	HashMap schema = new HashMap<String, String>();
        schema.put("name", "string");
        schema.put("address", "string");
        schema.put("contact", "int");
        schema.put("email", "string");
        
        graphQLObjectType.name("Customer");
        schema.keySet().forEach(e-> {
                graphQLObjectType.field(GraphQLFieldDefinition.newFieldDefinition()
                                .name(e.toString())
                                .type(GraphQLNonNull.nonNull(ReturnType(schema.get(e).toString()))));
        });
        
            String printSchema = schemaPrinter.print(graphQLObjectType.build());
            System.out.println(printSchema);

            
            GraphQLSchema schemaGQL = GraphQLSchema.newSchema()
                    .query(graphQLObjectType)
                    .build();
            
            GraphQL graphQL = GraphQL.newGraphQL(schemaGQL)
                    .build();

            ExecutionInput executionInput = ExecutionInput.newExecutionInput().query("query { Customer { name } }")
                    .build();

            ExecutionResult executionResult = graphQL.execute(executionInput);

            Object data = executionResult.getData();
            List<GraphQLError> errors = executionResult.getErrors();  
            
            System.out.println("data:" + data);
            System.out.println("errors:" + errors);
            return printSchema;            
    }

    
    
}
