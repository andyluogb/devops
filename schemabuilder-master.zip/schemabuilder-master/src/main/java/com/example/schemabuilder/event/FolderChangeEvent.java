package com.example.schemabuilder.event;

import java.nio.file.Path;
import java.nio.file.WatchEvent;
import java.time.LocalTime;
import java.util.StringJoiner;

import org.springframework.context.ApplicationEvent;
import org.springframework.http.codec.ServerSentEvent;

public class FolderChangeEvent extends ApplicationEvent {

    private final Event event;

    public FolderChangeEvent(Object source, WatchEvent<Path> pathEvent, Path path) {
        super(source);
        this.event = new Event(pathEvent, path);
    }

    public Event getEvent() {
        return event;
    }
    
    public ServerSentEvent buildSseEvent (int sequence) {
    	return ServerSentEvent.<String> builder()
        .id(String.valueOf(sequence))
          .event("periodic-event")
          .data("SSE - " + LocalTime.now().toString())
          .build();
    }

    public static class Event {

        private final String action;
        private final String path;

        public Event(WatchEvent<Path> event, Path path) {
            this.action = event.kind().toString();
            this.path = path.toString();
        }

        public String getAction() {
            return action;
        }

        public String getPath() {
            return path;
        }

        @Override
        public String toString() {
            return new StringJoiner(", ", Event.class.getSimpleName() + "[", "]")
                    .add("action='" + action + "'")
                    .add("path='" + path + "'")
                    .toString();
        }
    }
}
