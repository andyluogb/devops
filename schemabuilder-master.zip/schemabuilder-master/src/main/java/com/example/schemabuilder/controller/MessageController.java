package com.example.schemabuilder.controller;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.schemabuilder.message.MessageProcessor;

import reactor.core.Disposable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class MessageController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageController.class);

    @Autowired
    private MessageProcessor processor;
    
    private Set<Disposable> subPool = new HashSet<Disposable>();

    @PostMapping("/send")
    public String send(@RequestBody String message) {
        LOGGER.info("Received '{}'", message);
        processor.process(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + " " + message);
        return "Done";
    }

    @GetMapping(path = "/receive", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> receive() {
        // Some FluxSink documentation and code samples:
        // - https://projectreactor.io/docs/core/release/reference/#producing.create
        // - https://www.baeldung.com/reactor-core
        // - https://www.e4developer.com/2018/04/14/webflux-and-servicing-client-requests-how-does-it-work/
    	
    	System.out.println("SSe request for /receive");

        return Flux.create(sink -> {
            processor.register(sink::next);
        });
    }

    @GetMapping(path = "/timestamps", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> timestamps() {
    	Flux<String> flux= Flux.interval(Duration.ofSeconds(1))
                .map(sequence -> LocalTime.now().toString());
    	Disposable dispose = flux.subscribe(System.out::println);
    	subPool.add(dispose);
    	return flux;
    }
    
    @GetMapping(path = "/dispose", produces = MediaType.TEXT_PLAIN_VALUE)
    public Mono<String> disposeEvents() {
    	subPool.forEach(e->e.dispose());
    	return Mono.just("Disposed");
    }
}
