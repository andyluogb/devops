package com.example.schemabuilder.graphql;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.schemabuilder.event.StockPriceEventListener;
import com.example.schemabuilder.message.StockPriceService;
import com.example.schemabuilder.model.ResponseData;
import com.example.schemabuilder.model.StockDetail;
import com.example.schemabuilder.model.StockPrice;
import com.example.schemabuilder.service.BaseRepository;
import com.example.schemabuilder.service.Metadata;
import com.example.schemabuilder.stockupdate.StockTickerPublisher;

import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.SelectedField;
import reactor.core.publisher.Flux;


@Component
public class GraphQLDataFetchers {
	
	@Autowired
	private BaseRepository baseRepository;
	//@Autowired
	//private AuthorRepository authorRepository;
	//@Autowired
	//private CustomerRepository customerRepository;
	
	@Autowired
    private StockPriceService stockTicketService;
	@Autowired
	private StockPriceEventListener stockPriceEventListener;
	
	@Autowired
    private Metadata metaData;
	@Autowired
	private MockMemData mockMemData;
	
    private final static StockTickerPublisher STOCK_TICKER_PUBLISHER = new StockTickerPublisher();

    
	private List<Map<String, Object>> getAllData(String tableName, DataFetchingFieldSelectionSet selectionSet, String cache, int first, int limit) {
		return getAllData(tableName, selectionSet, cache, first, limit, null);
	}	
	private List<Map<String, Object>> getAllData(String tableName, DataFetchingFieldSelectionSet selectionSet, String cache, int first, int limit, String where) {		
		List<Map<String, Object>> dbList = new ArrayList<Map<String, Object>>();
		if (cache!=null && cache.equals("IGNITE")) {
			List<String> columnNames = getColumnNames(selectionSet);
		    try {
				dbList = baseRepository.findAll(columnNames, tableName, first, limit, where);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {	
		    dbList = mockMemData.getMockData(tableName).stream().collect(Collectors.toList());
		}
		return dbList;
	}
	
    private List<String> getColumnNames(DataFetchingFieldSelectionSet selectionSet) {
    	List<String> columnNames = new ArrayList<String>();
    	selectionSet.getFields().forEach(f->columnNames.add(f.getName()));
    	return columnNames;
    }
    
    
    public DataFetcher getResponseDataFetcher() {
        return dataFetchingEnvironment -> {        	
        	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        	selectionSet.getFields().forEach(f->System.out.printf("filed Name:%s ; qualify name: %s %n",f.getName(), f.getQualifiedName()));
            return createResponseData(dataFetchingEnvironment).getDataMap();
        };
    }    
    private ResponseData createResponseData(DataFetchingEnvironment dataFetchingEnvironment){
    	String cache = dataFetchingEnvironment.getArgument("cacheName");
    	int first = dataFetchingEnvironment.getArgument("first");
    	int limit = dataFetchingEnvironment.getArgument("limit");
    	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
    	
    	ResponseData responseData = new ResponseData();
    	
    	for (SelectedField f : selectionSet.getFields()) {
    		
    		if (f.getQualifiedName().equals(f.getName())) {
    		    List<Map<String, Object>> dbList = getAllData(f.getName(), f.getSelectionSet(), cache, first, limit);
    		    setResponseDataField(responseData, f.getName(), dbList);
    		}
    	}
    	
    	return responseData;
    }
    
    public DataFetcher getResponseDataByFieldsFetcher() {
        return dataFetchingEnvironment -> {        	
        	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        	//selectionSet.getFields().forEach(f->System.out.printf("filed Name:%s ; qualify name: %s %n",f.getName(), f.getQualifiedName()));
            return createResponseDataByFields(dataFetchingEnvironment).getDataMap();
        };
    }    
    private ResponseData createResponseDataByFields(DataFetchingEnvironment dataFetchingEnvironment){
    	String cache = dataFetchingEnvironment.getArgument("cacheName");
    	String where = dataFetchingEnvironment.getArgument("where");
    	String fields = dataFetchingEnvironment.getArgument("fields");
    	
    	int first = dataFetchingEnvironment.getArgument("first");
    	int limit = dataFetchingEnvironment.getArgument("limit");
    	DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
    	
    	ResponseData responseData = new ResponseData();
    	
    	for (SelectedField f : selectionSet.getFields()) {
    		String tableName = f.getName();
    		if (f.getQualifiedName().equals(tableName) && metaData.isFieldNameInSchema(fields, tableName)) {
    	  	  List<Map<String, Object>> dbList = getAllData(tableName, f.getSelectionSet(), cache, first, limit, where);
    		  setResponseDataField(responseData, f.getName(), dbList);
    		}
    	}
    	
    	return responseData;
    }
    
    private void setResponseDataField(ResponseData data, String field, List<Map<String, Object>> value) {
    	data.putData(field, value);
		/*try {
		   Field dataField = data.getClass().getDeclaredField(field);
	        dataField.setAccessible(true);
	        dataField.set(data, value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    }

    
    
    public DataFetcher<Publisher<StockPrice>> getStockPriceFetcher() {
        return dataFetchingEnvironment -> {
            String symbol = dataFetchingEnvironment.getArgument("symbol");
            //return stockPrice(symbol);
            return stockPriceFromEvent(symbol);
        };
    }    
    private Publisher<StockPrice> stockPrice(String symbol) {
        Random random = new Random();
        return Flux
        		.range(1, 10).delayElements(Duration.ofSeconds(1))
        		//.interval(Duration.ofSeconds(1))
                .map(num -> new StockPrice(symbol, random.nextDouble(), LocalDateTime.now()));
    }    
    private Publisher<StockPrice> stockPriceFromEvent(String symbol) {
    	stockTicketService.start(symbol);
        return stockPriceEventListener.getStockPrice().filter(f->f.getSymbol().equals(symbol));
    }
    
    
    public DataFetcher getStockDetailFetcher() {
        return dataFetchingEnvironment -> {
            String symbol = dataFetchingEnvironment.getArgument("symbol");
            return new StockDetail(symbol, "name", 2000l);
        };
    }

    
    public DataFetcher stockQuotesSubscriptionFetcher() {
        return environment -> {
            List<String> arg = environment.getArgument("stockCodes");
            List<String> stockCodesFilter = arg == null ? Collections.emptyList() : arg;
            if (stockCodesFilter.isEmpty()) {
                return STOCK_TICKER_PUBLISHER.getPublisher();
            } else {
                return STOCK_TICKER_PUBLISHER.getPublisher(stockCodesFilter);
            }
        };
    }    
}
