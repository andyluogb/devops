package com.example.schemabuilder.controller;


import javax.annotation.PostConstruct;

import org.springframework.context.ApplicationListener;
import org.springframework.http.MediaType;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.schemabuilder.event.StockPriceEvent;
import com.example.schemabuilder.message.StockPriceService;
import com.example.schemabuilder.model.StockPrice;

import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;

//@RestController
//@RequestMapping("/sse/flux")
public class StockPriceController implements ApplicationListener<StockPriceEvent> {

    private final StockPriceService stockTicketService;

    public StockPriceController(StockPriceService stockTicketService) {
        this.stockTicketService = stockTicketService;
    }

    private final SubscribableChannel subscribableChannel = MessageChannels.publishSubscribe().get();

    //@PostConstruct
    void init() {
    	stockTicketService.start("GOOGLE");
    }

    @GetMapping(path = "/stockprice", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<StockPrice> getStockPrice() {
        return Flux.create(sink -> {
            MessageHandler handler = message -> sink.next(StockPriceEvent.class.cast(message.getPayload()).getEvent());
            sink.onCancel(() -> {
            	System.out.println("Cancel stockprice watch.....");
                subscribableChannel.unsubscribe(handler);
            });
            subscribableChannel.subscribe(handler);
        }, FluxSink.OverflowStrategy.LATEST);
    }

    @Override
    public void onApplicationEvent(StockPriceEvent event) {
        subscribableChannel.send(new GenericMessage<>(event));
    }
}
