package com.example.schemabuilder.message;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.scheduling.support.TaskUtils;
import org.springframework.stereotype.Service;

import com.example.schemabuilder.event.StockPriceEvent;
import com.example.schemabuilder.model.StockPrice;

@Service
public class StockPriceService {

    private static final Logger logger = LoggerFactory.getLogger(FolderWatchService.class);

    private final ApplicationEventPublisher eventPublisher;

    private final static Random rand = new Random();
    
    private ConcurrentHashMap<String, Object> map = new ConcurrentHashMap<String, Object>();
    

    public StockPriceService(ApplicationEventPublisher eventPublisher) {
    	    this.eventPublisher = eventPublisher;
    }


    private static int rollDice(int min, int max) {
        return rand.nextInt((max - min) + 1) + min;
    }


    @Bean
    public ApplicationEventMulticaster applicationEventMulticaster() {
        SimpleApplicationEventMulticaster eventMulticaster = new SimpleApplicationEventMulticaster();
        eventMulticaster.setTaskExecutor(new SimpleAsyncTaskExecutor());
        eventMulticaster.setErrorHandler(TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER);
        return eventMulticaster;
    }

    public void start(String symbol) {
    	if (map.containsKey(symbol)) return;
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        map.put(symbol, executorService);
        executorService.scheduleAtFixedRate(
        		() -> {
                    try {
                        StockPrice stockPrice = new StockPrice(symbol, rand.nextDouble(), LocalDateTime.now());
                        System.out.println("produce stock price:" + stockPrice.getSymbol() + " - " + stockPrice.getPrice());
                        eventPublisher.publishEvent(new StockPriceEvent(this, stockPrice));
                    } catch (Exception e) {
                    	System.out.println("StockTickerService failed:"+ e.getMessage());
                    }
                }, 0, 2, TimeUnit.SECONDS);
        
        /*ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
        singleThreadExecutor.execute(() -> {
            try {
                StockPrice stockPrice = new StockPrice(symbol, rand.nextDouble(), LocalDateTime.now());
                logger.info("produce stock price:" + stockPrice);
                eventPublisher.publishEvent(new StockPriceEvent(this, stockPrice));
            } catch (Exception e) {
                logger.error("StockTickerService failed", e);
            }
        });*/
    }
    
    
}
