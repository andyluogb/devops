package com.example.schemabuilder.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Publisher;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.example.schemabuilder.graphql.GraphQLProvider;

import graphql.ExecutionInput;
import graphql.ExecutionResult;

@RestController
public class RestartRestController {
	@Autowired
	private GraphQLProvider gprovider;
	
	
	@GetMapping("/restart")
	public String restart() {
		String message = "restarting GraphQL";
		try {
			gprovider.init();
			message += "GraphQL restarted successfully.\n" + gprovider.sdl;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			message += "error:" + e.getMessage();
		}
	    return message;
	}

	
	@RequestMapping(value = "/graphql1", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object executeOperation(@RequestBody Map body) {
        String query = (String) body.get("query");
        //Map<String, Object> variables = (Map<String, Object>) body.get("variables");
        //if (variables == null) {
        //    variables = new LinkedHashMap<>();
        //}
        //ExecutionResult executionResult = gprovider.graphQL().execute(query, (Object) null, variables);
        
        ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
        ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
        
        
        Map<String, Object> result = new LinkedHashMap<>();
        if (executionResult.getErrors().size() > 0) {
            result.put("errors", executionResult.getErrors());
        }
        result.put("data", executionResult.getData());
        return result;
    }	
	
	@RequestMapping(value = "/subscription", method = RequestMethod.POST, produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @ResponseBody
    public Object executeSubsciption(@RequestBody Map body) {
        String query = (String) body.get("query");
		//String query = "subscription { stockPrice(symbol:\"GOOG\") { price symbol timestamp } }";
        //Map<String, Object> variables = (Map<String, Object>) body.get("variables");
        //if (variables == null) {
        //    variables = new LinkedHashMap<>();
        //}
        //ExecutionResult executionResult = gprovider.graphQL().execute(query, (Object) null, variables);
        
        ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
        ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
        Publisher<ExecutionResult> stockPriceStream = executionResult.getData();
        
        //Map<String, Object> result = new LinkedHashMap<>();
        //if (executionResult.getErrors().size() > 0) {
        //    result.put("errors", executionResult.getErrors());
        //}
        //result.put("data", executionResult.getData());
        return stockPriceStream;
    }
	
	@RequestMapping(value = "/subscription", method = RequestMethod.GET, produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Object executeSubsciption(@RequestParam Optional<String> sub, @RequestParam Optional<String> symbol, @RequestParam Optional<String> columns) {
        //String query = (String) body.get("query");
		
		SseEmitter sseEmitter = new SseEmitter(-1L);
		
		String symbolVar = symbol.orElse("GOOG");
		if (StringUtils.isBlank(symbolVar)) {
			symbolVar = "GOOG";
		}
		String columnsVar = columns.orElse("price symbol timestamp");
		if (StringUtils.isBlank(columnsVar)) {
			columnsVar = "price symbol timestamp";
		}
		String query = sub.orElse("subscription { stockPrice(symbol:\""+symbolVar+"\") { " + columnsVar +  "} }");
		System.out.println("query:" + query);
			
        //Map<String, Object> variables = (Map<String, Object>) body.get("variables");
        //if (variables == null) {
        //    variables = new LinkedHashMap<>();
        //}
        //ExecutionResult executionResult = gprovider.graphQL().execute(query, (Object) null, variables);
        
        ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
        ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
        Publisher<ExecutionResult> stockPriceStream = executionResult.getData();
        
        //Map<String, Object> result = new LinkedHashMap<>();
        //if (executionResult.getErrors().size() > 0) {
        //    result.put("errors", executionResult.getErrors());
        //}
        //result.put("data", executionResult.getData());
        
        try {
			sseEmitter.send(stockPriceStream);
		} catch (IOException e) {
			 sseEmitter.complete();
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return stockPriceStream;
    }

	@RequestMapping(value = "/subscriptions", method = RequestMethod.GET, produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Object executeSubsciption(HttpServletRequest request) throws UnsupportedEncodingException {
		String query = URLDecoder.decode(request.getQueryString(), "UTF-8");
		System.out.println("query:" + query);
        ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
        ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
        Publisher<ExecutionResult> stockPriceStream = executionResult.getData();
        return stockPriceStream;
    }

	
	@RequestMapping(value = "/subscription/json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Object executeSubsciptionJson(@RequestParam Optional<String> sub, @RequestParam Optional<String> symbol, @RequestParam Optional<String> columns) {
        //String query = (String) body.get("query");
		
		String symbolVar = symbol.orElse("GOOG");
		if (StringUtils.isBlank(symbolVar)) {
			symbolVar = "GOOG";
		}
		String columnsVar = columns.orElse("price symbol timestamp");
		if (StringUtils.isBlank(columnsVar)) {
			columnsVar = "price symbol timestamp";
		}
		String query = sub.orElse("subscription { stockPrice(symbol:\""+symbolVar+"\") { " + columnsVar +  "} }");
		System.out.println("query:" + query);
		
        //Map<String, Object> variables = (Map<String, Object>) body.get("variables");
        //if (variables == null) {
        //    variables = new LinkedHashMap<>();
        //}
        //ExecutionResult executionResult = gprovider.graphQL().execute(query, (Object) null, variables);
        
        ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
        ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
        Publisher<ExecutionResult> stockPriceStream = executionResult.getData();
        
        //Map<String, Object> result = new LinkedHashMap<>();
        //if (executionResult.getErrors().size() > 0) {
        //    result.put("errors", executionResult.getErrors());
        //}
        //result.put("data", executionResult.getData());
        List<ExecutionResult> elements = new ArrayList<ExecutionResult>();
        Subscriber subsc = new Subscriber<ExecutionResult>() {
		    @Override
		    public void onSubscribe(Subscription s) {
		      s.request(Long.MAX_VALUE);
		    }
		 
		    @Override
		    public void onNext(ExecutionResult integer) {
		      elements.add(integer);
		    }
		 
		    @Override
		    public void onError(Throwable t) {}
		 
		    @Override
		    public void onComplete() {}
		};  
        stockPriceStream.subscribe(subsc);
        
        try {
			Thread.sleep(1000*2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        return elements;
    }
	
	@RequestMapping(value = "/subscription/stockquote", method = RequestMethod.GET, produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Object stockQuote() {
		String query = "subscription { "
				+ "  stockQuotes { "
				+ "        dateTime "
				+ "        stockCode "
				+ "        stockPrice "
				+ "        stockPriceChange "
				+ "    } "
				+ "}";
		System.out.println("query:" + query);
        ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
        ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
        Publisher<ExecutionResult> stockPriceStream = executionResult.getData();
        return stockPriceStream;
    }
	
}
