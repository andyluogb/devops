###NZFileEncyption utility 

This utility is to encrypt the NZ back files. Each data file will be encrypted using AES 256 bits data key, cipher algorithm uses "AES/CBC/PKCS5Padding" non-slated.
The 256 bits data key is encrypted using the public key created by BMO key team. The data key cipher is stored along with the encrypted data file and to transfer to AWS S3 bucket using AWS ftp service.
In the decryption side happens in EMR spark jobs, firstly to lookup the private key stored in the AWS Secret Manager Key Store. There are two parts stored in two stores, the left key part and right key part.
The full private key is merged from these two parts. The cipher data key will be decrypted by private key. Then spark job uses the decrypted data key to decrypted the data file and pass to the processor for further processing.

Schema files under "md" folder will not be encrypted. MD files are just copied over. Only the data files under "data" folder are encrypted and copied over.

####This encryption utility provides three ways to encrypt data files in batch and in single file.
* Single file encryption
```
  java -cp NZFileEncryption-1.0.jar com.bmo.idp.encryption.NZSingleFileEncryptor <application config path> <source file path> <target file path>
  e.g. java -cp NZFileEncryption-1.0.jar com.bmo.idp.encryption.NZSingleFileEncryptor src/main/resources/application.conf input\2020-03-24-16-11-34\table1\table.csv output\2020-03-24-16-11-34\table1\table111.csv
```
The target file folder should be created before running this command.

* Full timestamp folder for specific DB encryption
```
 java -cp NZFileEncryption-1.0.jar com.bmo.idp.encryption.NZFileBatchEncryptor <application.conf path> <NZ backup DB name> <NZ backup DB timestamp>
 e.g. java -cp NZFileEncryption-1.0.jar com.bmo.idp.encryption.NZFileBatchEncryptor src/main/resources/application.conf DB1 2020-03-24-16-11-34
```
The root input folder and root output folder are configured in the application configuration file as the INPUT and OUTPUT parameters. The output root folder should be created.

* Decryption for files defined in the  encryption_file.json file
```
 java -cp NZFileEncryption-1.0.jar com.bmo.idp.encryption.NZFileEncryptor <application.conf path> <encryption json file path>
 e.g. java -cp NZFileEncryption-1.0.jar com.bmo.idp.encryption.NZFileEncryptor src/main/resources/application.conf  src/main/resources/encrypt_files.json
```
The Encryptor support encryption in single thread or multiple threads. It is controlled by the parameter in the application configuration file using the "threads" parameter. If the threads > 1, this encryptor is running in the multiple threading mode.

The root input folder and root output folder are configured in the application configuration file as the INPUT and OUTPUT parameters. The public key is stored under PUBLIC_KEY_FOLDER parameter, the key name is defined as publicKeyFileName parameter

####The application configuration file
```
config {
    mode = local
    threads = 1
    encryption {
        INPUT = "nz_backup"
        OUTPUT = "nz_backup_enc"
        PUB_KEY_FOLDER = "key"
        publicKeyFileName ="nz_file_public.pem"
    }
}
```

####The encryption json file 
Ths json defines which files to be encrypted. The names support wildcard (*) matching. If the name is absent or empty, then will take all the files under this folder.
Below is he sample json file:
```
{
  "root_input": "nz_backup",
  "root_output": "nz_backup_enc_1",
  "backupFiles":[
    {
      "dbName": ["DB1"],
      "timestamp": ["2020-03-24*"],
      "sequence": ["1", "2"],
      "backupType": [],
      "dataFolder": ["data"],
      "dataFileName": ["*","table1_001*","table2_001.csv"]
    },
    {
      "dbName": ["DB1"],
      "timestamp": ["2020-03-24*"],
      "sequence": ["1", "2"],
      "backupType": ["FULL", "CUMM"],
      "dataFolder": ["md"],
      "dataFileName": ["*"]
    },
    {
      "dbName": ["DB2"],
      "timestamp": ["2020-03-24-16-11-35"],
      "dataFolder": ["data"]
    },
    {
      "dbName": ["DB2"],
      "timestamp": ["2020-03-24-16-11-35"],
      "dataFolder": ["md"]
    }
  ]
}
```

####AWS CLI get value from secret manager key store 
```
aws secretsmanager get-secret-value --secret-id <secret arn>
```