package com.bmo.idp.encryption

import java.util.concurrent.TimeUnit

class MyRunnable(val countUntil: Long) extends Runnable {
  override def run(): Unit = {
    var sum = 0
    var i = 1
    while ( {
      i < countUntil
    }) {
      sum += i

      {
        i += 1; i - 1
      }
    }
    System.out.println(sum)
  }
}

object ThreadTester {

  import java.util.concurrent.Executors

  private val NTHREDS = 10

  def main(args: Array[String]): Unit = {
    val executor = Executors.newFixedThreadPool(NTHREDS)
    var i = 0
    while ( {
      i < 500
    }) {
      val worker = new MyRunnable(10000000L + i)
      executor.execute(worker)

      {
        i += 1; i - 1
      }
    }
    // This will make the executor accept no new threads
    // and finish all existing threads in the queue
    executor.shutdown()
    // Wait until all threads are finish
    executor.awaitTermination(20, TimeUnit.SECONDS)
    System.out.println("Finished all threads")
  }
}