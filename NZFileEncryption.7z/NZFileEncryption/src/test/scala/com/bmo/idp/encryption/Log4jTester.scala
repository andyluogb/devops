package com.bmo.idp.encryption

import org.apache.log4j.Logger

object Log4jTester {
  val logger: Logger = Logger.getLogger(Log4jTester.getClass)

  def main(args: Array[String]): Unit = {
    //com.log4js3.logging.log4j.S3LogAppender s3LogAppender = new  com.log4js3.logging.log4j.S3LogAppender();
    runMe("testttestttest")
  }

  private def runMe(parameter: String): Unit = {
    if (logger.isDebugEnabled) logger.debug("This is debug : " + parameter)
    if (logger.isInfoEnabled) logger.info("This is info : " + parameter)
    logger.warn("This is warn : " + parameter)
    logger.error("This is error : " + parameter)
    logger.fatal("This is fatal : " + parameter)
  }
}