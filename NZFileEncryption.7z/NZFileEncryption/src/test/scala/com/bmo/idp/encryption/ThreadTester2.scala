package com.bmo.idp.encryption

import java.util.HashSet
import java.util.ArrayList
import java.util.Random
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.{Callable, Future, ThreadPoolExecutor, TimeUnit}

import collection.JavaConversions._
import org.apache.commons.lang3.time.StopWatch

class Counter {
  private val value = new AtomicInteger

  def getValue: Int = value.get

  def increment: Int = value.incrementAndGet

  // Alternative implementation as increment but just make the
  // implementation explicit
  def incrementLongVersion: Int = {
    var oldValue = value.get
    while ( {
      !value.compareAndSet(oldValue, oldValue + 1)
    }) oldValue = value.get
    oldValue + 1
  }
}

class FactorialCalculator(val num:Integer) extends Callable[Integer] {
  @throws[Exception]
  def call():Integer= {
    var result = 1
    if ((num == 0) || (num == 1)) {
      result = 1
    } else {
      for ( i<- 2 to num) {
        result *= i
        TimeUnit.MILLISECONDS.sleep(20)
        //printf("%s: %d\n",Thread.currentThread().getName(),result)
      }
    }
    result
  }
}

object ThreadTester2 {

  import java.util.concurrent.{Callable, ExecutionException, Executors}

  private val NTHREDS = 50

  def main(args: Array[String]): Unit = {
    val watch = new StopWatch()
    watch.start()
    testFactor
    watch.stop()
    println("Time Elapsed: " + watch.getTime)
  }


  def testFactor(): Unit = {
    val counter = new Counter
    val list = new ArrayList[Future[Integer]]()
    val executor = Executors.newFixedThreadPool(NTHREDS).asInstanceOf[ThreadPoolExecutor]
    val random = new Random
    for (i<- 0 until 100) {
      val worker = new FactorialCalculator(i/2)
      val submit = executor.submit(worker)
      list.add(submit)
    }
    // This will make the executor accept no new threads
    // and finish all existing threads in the queue
    //executor.shutdown()
    // Wait until all threads are finish
    while (executor.getCompletedTaskCount < list.size) {
      printf("Main: Number of Completed Tasks:%d\n", executor.getCompletedTaskCount());
      for (i<- 0 until list.size()) {
        val result = list.get(i)
        printf("Main: Task %d: %s\n", i, result.isDone)
      }
      try TimeUnit.MILLISECONDS.sleep(50)
      catch {
        case e: InterruptedException =>
          e.printStackTrace()
      }
    }

    for (i<- 0 until list.size()) {
      val result = list.get(i)
      printf("Main: Task %d: %s\n", i, result.isDone)
    }

    val set = new ArrayList[Integer]()
    for (future <- list) {
      try set.add(future.get)
      catch {
        case e: InterruptedException =>
          e.printStackTrace()
        case e: ExecutionException =>
          e.printStackTrace()
      }
    }

    set.toList.foreach(println)

    if (list.size > set.size) throw new RuntimeException("Double-entries!!!")

    executor.shutdown()

  }

  def testCount(): Unit = {
    val counter = new Counter
    val list = new ArrayList[Future[Integer]]()
    val executor = Executors.newFixedThreadPool(NTHREDS)
    for (i<- 0 until 500) {
      val worker = new Callable[Integer]() {
        @throws[Exception]
        override def call: Integer = {
          val number = counter.increment
          System.out.println(number)
          number
        }
      }
      val submit = executor.submit(worker)
      list.add(submit)
    }
    // This will make the executor accept no new threads
    // and finish all existing threads in the queue
    executor.shutdown()
    // Wait until all threads are finish
    while ( {
      !executor.isTerminated
    }) {
    }
    val set = new HashSet[Integer]()
    for (future <- list) {
      try set.add(future.get)
      catch {
        case e: InterruptedException =>
          e.printStackTrace()
        case e: ExecutionException =>
          e.printStackTrace()
      }
    }
    if (list.size > set.size) throw new RuntimeException("Double-entries!!!")
  }




}