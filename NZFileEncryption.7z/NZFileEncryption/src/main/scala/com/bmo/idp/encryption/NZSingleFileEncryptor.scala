package com.bmo.idp.encryption

import java.nio.file.{Path, Paths}
import java.security.PublicKey

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.util.{NZFileEncryptionUtil, NZFileUtil, RSAUtil, SecretKeyGenerator}


object NZSingleFileEncryptor extends NZLogger {
  var fileEncryptor = NZFileEncryptionUtil
  var fileUtil = NZFileUtil


  def main(args: Array[String]) = {
    NZConfig.parseArgs(args)
    val (sourceFilePath, targetFilePath) = NZConfig.getSingleFileArgs(args)
    encryptAndCopyDataFiles(sourceFilePath, targetFilePath)
  }

  /**
   * Decryption for data files
   */
  def encryptAndCopyDataFiles(sourceFilePath:String, targetFilePath:String) = {
    val publicKeyPath = Paths.get(NZFileEncryptConfig.PUB_KEY_FOLDER, NZFileEncryptConfig.publicKeyFileName)
    val publicKey = fileUtil.readFileAsString(publicKeyPath)
    val pk:PublicKey = RSAUtil.getPublicKeyFromString(publicKey)
    encryptAndCopyDataFile(sourceFilePath, targetFilePath, pk)
  }

  /**
   * encrypt data file
   */
  @throws[Exception]
  def encryptAndCopyDataFile(sourceFilePath:String, targetFilePath:String, pk:PublicKey):Unit = {
    val inputFile: Path = Paths.get(sourceFilePath)
    val outputFile: Path = Paths.get(targetFilePath)
      try {
        val securedKey = createDataKey(pk, outputFile)
        fileEncryptor.encryptAndCopy(inputFile.toFile, outputFile.toFile, securedKey)
        logger.info("encrypted file: " + outputFile.toAbsolutePath.toString)
        val encDoneFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.encDoneName)
        fileUtil.deleteAndCreateFile(encDoneFileOutput)
        val encFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString  + "." + NZFileEncryptConfig.encFailName)
        fileUtil.deleteFile(encFailFileOutput)
      } catch {
        case e: Exception =>
          logger.error(s"Something wrong when encrypting file ${inputFile.toAbsolutePath.toString}", e)
          val encFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString  + "." + NZFileEncryptConfig.encFailName)
          fileUtil.deleteAndCreateFile(encFailFileOutput)
      }
  }

  def createDataKey(pk:PublicKey, outputFilePath: Path):Array[Byte] = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    val outputKeyPath:Path = outputFilePath.getParent
    val cipherSecuredKeyFile = Paths.get(outputKeyPath.toAbsolutePath.toString,  outputFilePath.getFileName.toString + "." + NZFileEncryptConfig.cipherKeyFileName)
    fileUtil.writeBytesToFile(cipherSecuredKey, cipherSecuredKeyFile.toFile)
    securedKey
  }

}
