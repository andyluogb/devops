package com.bmo.idp.encryption

import java.nio.file.{Path, Paths}
import java.security.PrivateKey

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.util.{NZFileEncryptionUtil, NZFileUtil, RSAUtil}


object NZSingleFileDecryptor extends NZLogger {
  val fileEncryptor = NZFileEncryptionUtil
  val fileUtil = NZFileUtil


  def main(args: Array[String]) = {
    NZConfig.parseArgs(args)
    val (sourceFilePath, targetFilePath) = NZConfig.getSingleFileArgs(args)
    decryptAndCopyDataFiles(sourceFilePath, targetFilePath)
  }

  /**
   * Decryption for data files
   */
  def decryptAndCopyDataFiles(sourceFilePath:String, targetFilePath:String) = {
    val keyPath = Paths.get(NZFileEncryptConfig.PUB_KEY_FOLDER, NZFileEncryptConfig.privateKeyFileName)
    val privateKeyStr:String = fileUtil.readFileAsString(keyPath)
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    decryptAndCopyDataFile(privateKey, sourceFilePath, targetFilePath)
  }

  def getDataKey(pk:PrivateKey, sourceFilePath:String):Array[Byte] = {
    val inputFile = Paths.get(sourceFilePath)
    val cipherDataKeyPath:Path = Paths.get(sourceFilePath).getParent
    val cipherSecuredKeyFile = Paths.get(cipherDataKeyPath.toAbsolutePath.toString, inputFile.getFileName.toString + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = fileUtil.readFileToBytes(cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  @throws[Exception]
  def decryptAndCopyDataFile(pk:PrivateKey, sourceFilePath:String, targetFilePath:String):Unit = {
    val inputFile = Paths.get(sourceFilePath)
    val outputFile = Paths.get(targetFilePath)
      try {
        val securedKey = getDataKey(pk, sourceFilePath)
        fileEncryptor.decryptAndCopy(inputFile.toFile, outputFile.toFile, securedKey)
        logger.info("decrypted file: " + outputFile.toAbsolutePath.toString)
        val decDoneFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decDoneName)
        fileUtil.deleteAndCreateFile(decDoneFileOutput)
        val decFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
        fileUtil.deleteFile(decFailFileOutput)
      } catch {
        case e: Exception =>
          logger.error(s"Something wrong when encrypting file ${}", e)
          val decFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
          fileUtil.deleteAndCreateFile(decFailFileOutput)
      }
  }

}
