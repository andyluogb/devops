package com.bmo.idp.encryption

import java.nio.file.{Path, Paths}
import java.security.PublicKey

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.{BackupFile, BackupType}
import com.bmo.idp.encryption.util._


object NZFileBatchEncryptor extends NZLogger {
  var fileEncryptor = NZFileEncryptionUtil
  var fileUtil = NZFileUtil

  def main(args: Array[String]) = {
    NZConfig.parseArgs(args)
    val (dbName, dbTimestampName) = NZConfig.getBackupFilesArgs(args)
    val start = System.currentTimeMillis
    encryptAndCopyFolder(dbName, dbTimestampName, NZFileEncryptConfig.INPUT, NZFileEncryptConfig.OUTPUT)
    val finish = System.currentTimeMillis
    val timeElapsed = finish - start
    logger.info("took miliseconds:" + timeElapsed)
  }

  /**
   * Decryption from root input folder to root output folder
   */
  def encryptAndCopyFolder(dbName:String, dbTimestampName:String, rootInput:String, rootOutput:String) = {
    val backupFiles:BackupFile = NZBackupFileUtil.buildBackupFiles(rootInput, dbName, dbTimestampName)
    val publicKeyPath = Paths.get(NZFileEncryptConfig.PUB_KEY_FOLDER, NZFileEncryptConfig.publicKeyFileName)
    val publicKey = fileUtil.readFileAsString(publicKeyPath)
    val pk:PublicKey = RSAUtil.getPublicKeyFromString(publicKey)
    val backupTypes:List[BackupType] = backupFiles.dbSequences.flatMap(f=>f.backupTypes)
    for (backupType <- backupTypes) {
      try {
        encryptAndCopyFilesUnderBackupTypeFolder(backupType, pk, rootInput, rootOutput)
      } catch {
        case e: Exception =>
         logger.error(s"Something wrong when handling backupType in $backupType", e)
      }
    }
  }

  /**
   * encrypt Files under backup type folder
   */
  @throws[Exception]
  def encryptAndCopyFilesUnderBackupTypeFolder(backupType:BackupType, pk:PublicKey, rootInput:String, rootOutput:String) = {
    //create folders
    NZBackupFileUtil.createBackupTypeFolderOnOutput(backupType, rootOutput, true)
    //copy md file, write log for md done, no encryption
    copyMDFiles(backupType, rootInput, rootOutput)
    //create key
    val securedKey: Array[Byte] = createDataKey(pk, backupType, rootOutput)
    //encrypt and copy data files
    encryptAndCopyDataFilesUnderBackupTypeFolder(backupType, securedKey, rootInput, rootOutput)
  }

  @throws[Exception]
  def encryptAndCopyDataFilesUnderBackupTypeFolder(backupType:BackupType, securedKey: Array[Byte], rootInput:String, rootOutput:String):Unit = {
    val inputDataPath:Path = Paths.get(rootInput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val outputDataPath:Path = Paths.get(rootOutput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val inputLogPath:Path = Paths.get(rootInput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)
    val outputLogPath:Path = Paths.get(rootOutput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)

    val inputFiles = fileUtil.listFiles(inputDataPath)
    for (file <- inputFiles) {
      try {
        if (!fileEncryptor.isToExcludeEncDec(file)) {
          val outputFile = Paths.get(outputDataPath.toAbsolutePath.toString, file.getFileName.toString)
          fileEncryptor.encryptAndCopy(file.toFile, outputFile.toFile, securedKey)
          logger.info("encrypted file: " + outputFile.toAbsolutePath.toString)

          val encDoneFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, file.getFileName.toString + "." + NZFileEncryptConfig.encDoneName)
          fileUtil.deleteAndCreateFile(encDoneFileOutput)

          val encFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, file.getFileName.toString + "." + NZFileEncryptConfig.encFailName)
          fileUtil.deleteFile(encFailFileOutput)
        }
      } catch {
        case e:Exception => {
          logger.error(s"Something wrong when encrypting file ${file.toAbsolutePath.toString}", e)
          val encFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, file.getFileName.toString + "." + NZFileEncryptConfig.encFailName)
          fileUtil.deleteAndCreateFile(encFailFileOutput)
        }
      }
    }
  }

  def createDataKey(pk:PublicKey, backupType:BackupType, rootOutput:String):Array[Byte] = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    val outputKeyPath:Path = Paths.get(rootOutput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.DATA_KEY_FOLDER)
    val cipherSecuredKeyFile = Paths.get(outputKeyPath.toAbsolutePath.toString, NZFileEncryptConfig.cipherKeyFileName)
    fileUtil.writeBytesToFile(cipherSecuredKey, cipherSecuredKeyFile.toFile)
    securedKey
  }

  def copyMDFiles(backupType:BackupType, inputRoot:String, outputRoot:String): Any = {
    val inputMDPath:Path = Paths.get(inputRoot, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.MD_FOLDER)
    val outputMDPath:Path = Paths.get(outputRoot, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.MD_FOLDER)

    //copy schema files under md, no encryption needed
    try {
      val inputFiles = NZFileUtil.listFiles(inputMDPath)
      for (file <- inputFiles) {
        val outputFile = Paths.get(outputMDPath.toAbsolutePath.toString, file.getFileName.toString)
        NZFileUtil.copyReplacePath(file, outputFile)
        logger.info("MD files copied to:" + outputFile.toAbsolutePath.toString)
      }

      //create md.done under output log folder
      val outputEncDonePath: Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
        NZFileEncryptConfig.MD_FOLDER + NZFileEncryptConfig.END_DONE)
      NZFileUtil.deleteAndCreateFile(outputEncDonePath)
      val outputEncFailPath: Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
        NZFileEncryptConfig.MD_FOLDER + NZFileEncryptConfig.END_FAIL)
      NZFileUtil.deleteFile(outputEncFailPath)
    } catch {
      case e:Exception => {
        logger.error(s"Something wrong when coping MD files ${inputMDPath.toAbsolutePath.toString}", e)
        val outputEncDonePath: Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
          NZFileEncryptConfig.MD_FOLDER + NZFileEncryptConfig.END_FAIL)
        NZFileUtil.deleteAndCreateFile(outputEncDonePath)
      }
    }
  }
}
