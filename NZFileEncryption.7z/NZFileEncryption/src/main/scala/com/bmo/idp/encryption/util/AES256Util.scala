package com.bmo.idp.encryption.util

import java.io.{IOException, InputStream, OutputStream}
import java.security.GeneralSecurityException
import java.util.Base64

import com.amazonaws.services.s3.model.S3ObjectInputStream
import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto._
import javax.crypto.spec.{IvParameterSpec, PBEKeySpec, SecretKeySpec}

object AES256Util extends NZLogger {

  val SALT :String = "NZfiiiiiiiiiiiiiiiiiiiiiiiiies"
  val ITERATION_COUNT = 65536
  val KEY_LENGTH = 256
  val ALGORITHM_AES  = "AES"
  val SecretKey_ALGORITHM_PBE = "PBKDF2WithHmacSHA256"
  val Cipher_ALGORITHM_CBC = "AES/CBC/PKCS5Padding"
  val IV = Array[Byte](0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
  val CHAR_SET_UTF_8 = "UTF-8"

  val CIPHER_PROVIDER = "SunJCE" //new BouncyCastleProvider() //"SunJCE"


  /////////////////salted///////////

  @throws[Exception]
  def encryptSalted(strToEncrypt: String, secretKey:String): String = {
    val cipher = createEncryptSaltedCipher(secretKey)
    Base64.getEncoder.encodeToString(cipher.doFinal(strToEncrypt.getBytes(CHAR_SET_UTF_8)))
  }
  @throws[Exception]
  def decryptSalted(strToDecrypt: String, secretKey:String): String = {
    val cipher = createDecryptSaltedCipher(secretKey)
    new String(cipher.doFinal(Base64.getDecoder.decode(strToDecrypt)))

  }
  @throws[Exception]
  def createEncryptSaltedCipher(secretKey:String): Cipher = {
    createSaltedCipher(secretKey, Cipher.ENCRYPT_MODE)
  }
  @throws[Exception]
  def createDecryptSaltedCipher(secretKey:String): Cipher = {
    createSaltedCipher(secretKey, Cipher.DECRYPT_MODE)
  }
  @throws[Exception]
  def createSaltedCipher(secretKey:String, mode:Int): Cipher = {
    val ivspec = getIVSpec
    val secretKeySpec = createSaltedPBESecretKeySpec(secretKey)
    val cipher = getCBCCipherInstance
    cipher.init(mode, secretKeySpec, ivspec)
    cipher
  }
  private def getCBCCipherInstance(): Cipher = {
    Cipher.getInstance(Cipher_ALGORITHM_CBC, CIPHER_PROVIDER)
  }
  private def getIVSpec(): IvParameterSpec = {
    new IvParameterSpec(IV)
  }
  @throws[Exception]
  def createSaltedPBESecretKeySpec(secretKey:String): SecretKeySpec = {
    val factory = SecretKeyFactory.getInstance(SecretKey_ALGORITHM_PBE)
    val spec = new PBEKeySpec(secretKey.toCharArray, SALT.getBytes, ITERATION_COUNT, KEY_LENGTH)
    val tmp = factory.generateSecret(spec)
    val secretKeySpec = new SecretKeySpec(tmp.getEncoded, ALGORITHM_AES)
    secretKeySpec
  }


  /////////////////not salted///////////
  @throws[Exception]
  def encrypt(plaintext: String, keyBase64: String): String = { //Get Cipher Instance
    val cipherText = encrypt(plaintext.getBytes(CHAR_SET_UTF_8), Base64.getDecoder.decode(keyBase64), IV)
    Base64.getEncoder.encodeToString(cipherText)
  }
  def encrypt(plaintext: String, key: Array[Byte]): String = { //Get Cipher Instance
    val cipherText = encrypt(plaintext.getBytes(CHAR_SET_UTF_8), key, IV)
    Base64.getEncoder.encodeToString(cipherText)
  }
  @throws[Exception]
  def encrypt(plaintext: Array[Byte], key: SecretKey): Array[Byte] = { //Get Cipher Instance
    val cipherText = encrypt(plaintext, key, IV)
    cipherText
  }
  @throws[Exception]
  def encrypt(plaintext: Array[Byte], key: SecretKey, iv: Array[Byte]): Array[Byte] = { //Get Cipher Instance
    val cipherText = encrypt(plaintext, key.getEncoded, iv)
    cipherText
  }
  @throws[Exception]
  def encrypt(plaintext: Array[Byte], key: Array[Byte]): Array[Byte] = { //Get Cipher Instance
    val cipherText = encrypt(plaintext, key, IV)
    cipherText
  }
  @throws[Exception]
  def encrypt(plaintext: Array[Byte], key: Array[Byte], iv: Array[Byte]): Array[Byte] = { //Get Cipher Instance
    val cipher = createEncryptedCipher(key, iv)
    val cipherText = cipher.doFinal(plaintext)
    cipherText
  }
  @throws[Exception]
  def createEncryptedCipher(key: Array[Byte]): Cipher = { //Get Cipher Instance
    val cipher = createEncryptedCipher(key, IV)
    cipher
  }
  @throws[Exception]
  def createEncryptedCipher(key: Array[Byte], iv : Array[Byte]): Cipher = { //Get Cipher Instance
    val cipher = createNonSaltedCipher(key, iv, Cipher.ENCRYPT_MODE)
    cipher
  }

  @throws[Exception]
  def decrypt(cipherTextBase64: String, keyBase64:String): String = { //Get Cipher Instance
    val plaintext:Array[Byte] = decrypt(Base64.getDecoder.decode(cipherTextBase64), Base64.getDecoder.decode(keyBase64), IV)
    new String(plaintext, CHAR_SET_UTF_8)
  }
  @throws[Exception]
  def decrypt(cipherTextBase64: String, key:Array[Byte]): String = { //Get Cipher Instance
    val plaintext = decrypt(Base64.getDecoder.decode(cipherTextBase64), key, IV)
    new String(plaintext, CHAR_SET_UTF_8)
  }
  @throws[Exception]
  def decrypt(cipherText: Array[Byte], key: SecretKey): Array[Byte] = { //Get Cipher Instance
    val plaintext = decrypt(cipherText, key, IV)
    plaintext
  }
  @throws[Exception]
  def decrypt(cipherText: Array[Byte], key: SecretKey, iv: Array[Byte]): Array[Byte] = { //Get Cipher Instance
    val plaintext = decrypt(cipherText, key.getEncoded, iv)
    plaintext
  }
  @throws[Exception]
  def decrypt(cipherText: Array[Byte], key: Array[Byte]): Array[Byte] = { //Get Cipher Instance
    val cipher = createDecryptedCipher(key)
    val plaintext = cipher.doFinal(cipherText)
    plaintext
  }
  @throws[Exception]
  def decrypt(cipherText: Array[Byte], key: Array[Byte], iv: Array[Byte]): Array[Byte] = { //Get Cipher Instance
    val cipher = createDecryptedCipher(key, iv)
    val plaintext = cipher.doFinal(cipherText)
    plaintext
  }
  @throws[Exception]
  def createDecryptedCipher(key: Array[Byte]): Cipher = { //Get Cipher Instance
    val cipher = createDecryptedCipher(key, IV)
    cipher
  }
  @throws[Exception]
  def createDecryptedCipher(key: Array[Byte], iv : Array[Byte]): Cipher = { //Get Cipher Instance
    val cipher = createNonSaltedCipher(key, iv, Cipher.DECRYPT_MODE)
    cipher
  }

  @throws[Exception]
  private def createNonSaltedCipher(key: Array[Byte], iv : Array[Byte], mode:Int): Cipher = { //Get Cipher Instance
    val cipher = getCBCCipherInstance()
    //Create SecretKeySpec
    val keySpec = new SecretKeySpec(key, ALGORITHM_AES)
    //Create IvParameterSpec
    val ivSpec = new IvParameterSpec(iv)
    //Initialize Cipher for ENCRYPT_MODE
    cipher.init(mode, keySpec, ivSpec)
    cipher
  }

  @throws[GeneralSecurityException]
  @throws[IOException]
  def wrapInputStream(is: InputStream, decryptCipher:Cipher): CipherInputStream = {
    new CipherInputStream(is, decryptCipher)
  }
  @throws[GeneralSecurityException]
  @throws[IOException]
  def wrapInputStream(is: S3ObjectInputStream, decryptCipher:Cipher): CipherInputStream = {
    new CipherInputStream(is, decryptCipher)
  }

  @throws[GeneralSecurityException]
  @throws[IOException]
  def wrapOutputStream(os: OutputStream, encryptCipher:Cipher): CipherOutputStream = {
    new CipherOutputStream(os, encryptCipher)
  }



}
