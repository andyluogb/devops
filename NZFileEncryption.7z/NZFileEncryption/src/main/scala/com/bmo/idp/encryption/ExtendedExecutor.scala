package com.bmo.idp.encryption

import java.util.concurrent.{BlockingQueue, ThreadPoolExecutor, TimeUnit}

class ExtendedExecutor(val num:Int, corePoolSize: Int, maximumPoolSize: Int, keepAliveTime: Long, unit: TimeUnit, val queue: BlockingQueue[Runnable])
extends ThreadPoolExecutor(corePoolSize, maximumPoolSize,keepAliveTime, unit, queue) {
  override protected def afterExecute(r: Runnable, t: Throwable): Unit = {
    super.afterExecute(r, t)
    if (t != null) System.out.println("Got an error: " + t)
    else System.out.println("Everything's fine--situation normal!")
  }
}
