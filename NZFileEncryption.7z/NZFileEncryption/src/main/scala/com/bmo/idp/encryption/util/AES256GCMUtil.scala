package com.bmo.idp.encryption.util

import java.io.{InputStream, OutputStream}
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.util.Base64

import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.{Cipher, CipherInputStream, CipherOutputStream, SecretKey}
import org.bouncycastle.jce.provider.BouncyCastleProvider

object AES256GCMUtil extends NZLogger {
  // AES-GCM parameters
  //val AES_KEY_SIZE = 128 // 256 bits
  val GCM_NONCE_LENGTH = 12 // in bytes; 96 bit
  val GCM_TAG_LENGTH = 16 //in bytes; 128 bits
  val GCM_CIPHER_ALGORITHM = "AES/GCM/NoPadding"
  val GCM_CIPHER_PROVIDER = new BouncyCastleProvider() //"SunJCE"

  val NONCE:Array[Byte] =  Array[Byte](-57, -108, -102, -33, -64, -34, -79, -6, 102, 100, -57, 58)

  //var aad:Array[Byte] = "Whatever I like".getBytes

  def main(args: Array[String]): Unit = {
    val input = "Hello AES-GCM World!"
    // Initialise random and generate key
    val key = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherText = encrypt(input, key)
    try {
      val plainText = decrypt(cipherText, key)
      logger.info(s"input:$input")
      logger.info(s"cipherText:$cipherText")
      logger.info(s"plainText:$plainText")

       if (input==plainText) {
         logger.info("Test Passed: match!")
       }else {
         logger.info("Test Failed: result mismatch!")
       }
    } catch {
      case ex: Exception =>
          logger.error("Test Failed: unexpected ex ", ex)
    }
  }

  def encrypt(data:Array[Byte], key:Array[Byte]):Array[Byte] = {
    val secretKey = SecretKeyGenerator.bytesToSecretKey(key)
    val enCipher = getEncryptCipher(secretKey)
    enCipher.doFinal(data)
  }

  def decrypt(encryptedData:Array[Byte], key:Array[Byte]):Array[Byte] = {
    val secretKey = SecretKeyGenerator.bytesToSecretKey(key)
    val deCipher = getDecryptCipher(secretKey)
    deCipher.doFinal(encryptedData)
  }

  def encrypt(clearText:String, key:Array[Byte]):String = {
    val secretKey = SecretKeyGenerator.bytesToSecretKey(key)
    val enCipher = getEncryptCipher(secretKey)
    val encryptedBytes = enCipher.doFinal(clearText.getBytes(StandardCharsets.UTF_8))
    Base64.getEncoder.encodeToString(encryptedBytes)
  }

  def decrypt(encryptedStringBase64:String, key:Array[Byte]):String = {
    val secretKey = SecretKeyGenerator.bytesToSecretKey(key)
    val deCipher = getDecryptCipher(secretKey)
    val decryptedBytes = deCipher.doFinal(Base64.getDecoder.decode(encryptedStringBase64))
    new String(decryptedBytes, StandardCharsets.UTF_8)
  }

  def wrapInputStream(is: InputStream, cipher:Cipher): CipherInputStream = {
    new CipherInputStream(is, cipher)
  }

  def wrapOutputStream(os: OutputStream, cipher:Cipher): CipherOutputStream = {
    new CipherOutputStream(os, cipher)
  }

  def getEncryptCipher(key:Array[Byte]) : Cipher = {
    getEncryptCipher(SecretKeyGenerator.bytesToSecretKey(key))
  }

  def getEncryptCipher(key:SecretKey) : Cipher = {
    // Encrypt
    val cipher = Cipher.getInstance(GCM_CIPHER_ALGORITHM, GCM_CIPHER_PROVIDER)
    val spec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, NONCE)
    cipher.init(Cipher.ENCRYPT_MODE, key, spec)
    //cipher.updateAAD(aad)
    cipher
  }
  def getDecryptCipher(key:Array[Byte]) : Cipher = {
    // Decrypt
    getDecryptCipher(SecretKeyGenerator.bytesToSecretKey(key))
  }
  def getDecryptCipher(key:SecretKey) : Cipher = {
    // Decrypt
    val cipher = Cipher.getInstance(GCM_CIPHER_ALGORITHM, GCM_CIPHER_PROVIDER)
    val spec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, NONCE)
    cipher.init(Cipher.DECRYPT_MODE, key, spec)
    //cipher.updateAAD(aad)
    cipher
  }

  def getNonce():Array[Byte] = {
    val nonce = new Array[Byte](GCM_NONCE_LENGTH)
    val random = SecureRandom.getInstanceStrong
    random.nextBytes(nonce)

    logger.info("nonce " + nonce.toList)
    //nonce.foreach(println)
    nonce
  }

}
