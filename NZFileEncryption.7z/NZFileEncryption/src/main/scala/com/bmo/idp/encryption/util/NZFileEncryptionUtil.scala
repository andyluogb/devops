package com.bmo.idp.encryption.util

import java.io._
import java.nio.file.Path
import java.time.{Duration, Instant}

import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.BackupDataFile


object NZFileEncryptionUtil extends NZLogger{
  @throws[IOException]
  def encryptAndCopyRelatedFolder(inputFileName: String, outputFileName: String, ifolder: String, ofolder: String, securedKey: Array[Byte]): Unit = {
    val inputFile: File = NZFileUtil.getRelatedFile(inputFileName, ifolder)
    val outputFile: File = NZFileUtil.getRelatedFile(outputFileName, ofolder)
    encryptAndCopy(inputFile, outputFile, securedKey)
  }

  @throws[IOException]
  def encryptAndCopy(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createEncryptedCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val os = NZFileUtil.getOutputStream(outputFile)
    val wos = AES256Util.wrapOutputStream(os, cipher)
    try {
      NZFileUtil.copy(is, wos)
    } finally {
      if (is != null) is.close()
      if (wos != null) wos.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def decryptAndCopyRelatedFolder(inputFileName: String, outputFileName: String, ifolder: String, ofolder: String, securedKey: Array[Byte]): Unit = {
    val inputFile = NZFileUtil.getRelatedFile(inputFileName, ifolder)
    val outputFile = NZFileUtil.getRelatedFile(outputFileName, ofolder)
    decryptAndCopy(inputFile, outputFile, securedKey)
  }

  @throws[IOException]
  def decryptAndCopy(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val wis = AES256Util.wrapInputStream(is, cipher)
    val os = NZFileUtil.getOutputStream(outputFile)
    try {
      NZFileUtil.copy(wis, os)
    } finally {
      if (wis != null) wis.close()
      if (os != null) os.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def decryptAndCopyGCM256(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256GCMUtil.getDecryptCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val wis = AES256GCMUtil.wrapInputStream(is, cipher)
    val os = NZFileUtil.getOutputStream(outputFile)
    try {
      NZFileUtil.copy(wis, os)
    } finally {
      if (wis != null) wis.close()
      if (os != null) os.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def encryptAndCopyGCM256(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256GCMUtil.getEncryptCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val os = NZFileUtil.getOutputStream(outputFile)
    val wos = AES256GCMUtil.wrapOutputStream(os, cipher)
    try {
      NZFileUtil.copy(is, wos)
    } finally {
      if (is != null) is.close()
      if (wos != null) wos.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  def isToExcludeEncDec(file:Path):Boolean = {
    (file.getFileName.toString.endsWith(NZFileEncryptConfig.END_BIN)
      || file.getFileName.toString.endsWith(NZFileEncryptConfig.END_DONE)
      || file.getFileName.toString.endsWith(NZFileEncryptConfig.END_FAIL))
  }
  def isToExcludeEncDec(file:BackupDataFile):Boolean = {
    (file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_BIN)
      || file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_DONE)
      || file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_FAIL))
  }

  def getAvailableProcessors = {
      Runtime.getRuntime().availableProcessors()
  }

  def timeInvoke(callback: () => Unit) {
    var start = Instant.now
    callback()
    var finish = Instant.now
    var timeElapsed = Duration.between(start, finish).toMillis
    logger.info(" testEncryption timeElapsed:" + timeElapsed)
  }



}