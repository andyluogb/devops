package com.bmo.idp.encryption

import java.nio.file.{Path, Paths}
import java.security.PublicKey
import java.util.concurrent.{Callable, Executors, Future, ThreadPoolExecutor}

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.{BackupDataFile, BackupFilesConfig}
import com.bmo.idp.encryption.util._


object NZFileEncryptor extends NZLogger {
  var fileEncryptor = NZFileEncryptionUtil
  var fileUtil = NZFileUtil


  def main(args: Array[String]) = {
    //NZConfig.parseArgs("src/main/resources/application.conf")
    NZConfig.parseArgs(args)
    val backupFilesConfig : BackupFilesConfig = NZBackupFileUtil.getBackupFilesConfigs(args)
    NZFileEncryptConfig.INPUT = backupFilesConfig.root_input
    NZFileEncryptConfig.OUTPUT = backupFilesConfig.root_output

    val (a,b) =NZBackupFileUtil.buildBackupDataFileList(backupFilesConfig)
    checkOutputDirectoryTreeCreated(b, backupFilesConfig.root_output)
    encryptAndCopyDataFiles(b, backupFilesConfig.root_input, backupFilesConfig.root_output)
  }


  /**
   * checkOutputDirectoryTreeCreated
   */
  def checkOutputDirectoryTreeCreated(backupDataFiles: List[BackupDataFile], rootOutput:String) = {
    for (backupData:BackupDataFile <- backupDataFiles) {
      NZBackupFileUtil.checkOutputDirectoryTreeCreated(backupData, rootOutput)
    }
  }

  /**
   * Decryption for data files
   */
  def encryptAndCopyDataFiles(backupDataFiles: List[BackupDataFile], rootInput:String, rootOutput:String) = {
    val publicKeyPath = Paths.get(NZFileEncryptConfig.PUB_KEY_FOLDER, NZFileEncryptConfig.publicKeyFileName)
    val publicKey = fileUtil.readFileAsString(publicKeyPath)
    val pk:PublicKey = RSAUtil.getPublicKeyFromString(publicKey)
    if (NZConfig.threads <=1 ) {
      for (backupData: BackupDataFile <- backupDataFiles) {
        encryptAndCopyDataFileTask(backupData, rootInput, rootOutput, pk)
      }
    } else {
      encryptAndCopyDataFilesMultiThreading(backupDataFiles, rootInput, rootOutput, pk)
    }
  }

  //below can be multi-threading
  def encryptAndCopyDataFileTask(backupData:BackupDataFile, rootInput:String, rootOutput:String, pk:PublicKey) = {
      if (NZBackupFileUtil.isMDFile(backupData)) {
        NZBackupFileUtil.copyMDFile(backupData, rootInput, rootOutput)
      } else {
        encryptAndCopyDataFile(backupData, pk, rootInput, rootOutput)
      }
  }

  class EncryptAndCopyDataFileCallable(backupData:BackupDataFile, rootInput:String, rootOutput:String, pk:PublicKey) extends Callable[BackupDataFile] {
    @throws[Exception]
    def call():BackupDataFile = {
      var result = backupData
      encryptAndCopyDataFileTask(backupData, rootInput, rootOutput, pk)
      result
    }
  }

  def encryptAndCopyDataFilesMultiThreading(backupDataFiles: List[BackupDataFile], rootInput:String, rootOutput:String, pk:PublicKey) = {
    import collection.JavaConverters._

    val max_threads = List(NZConfig.MAX_THREAD_POOL, NZConfig.threads, backupDataFiles.size, NZFileEncryptionUtil.getAvailableProcessors).min
    val executor = Executors.newFixedThreadPool(max_threads).asInstanceOf[ThreadPoolExecutor]
    val encryptAndCopyDataFileCallables:List[EncryptAndCopyDataFileCallable] = backupDataFiles.map(dataFile=>new EncryptAndCopyDataFileCallable(dataFile, rootInput, rootOutput, pk))
    var list:List[Future[BackupDataFile]] = null

    logger.info(s"Start executor in $max_threads threads")
    try {
      list = executor.invokeAll(encryptAndCopyDataFileCallables.asJavaCollection).asScala.toList
    } catch {
      case e:Exception => {
        logger.error("error in encryptAndCopyDataFilesMultiThreading", e)
      }
    }
    logger.info("Completed executor")


    /*
    var list = List[Future[BackupDataFile]]()

    for (dataFile <- backupDataFiles) {
      val worker = new EncryptAndCopyDataFileCallable(dataFile, rootInput, rootOutput, pk)
      val submit: Future[BackupDataFile] = executor.submit(worker)
      list ::= submit
    }

    while (executor.getCompletedTaskCount < backupDataFiles.size) {
      //logger.debug(s"Main: Number of Completed Tasks:${executor.getCompletedTaskCount()}\n")
      var i = 0
      for (f <- list) {
        //logger.debug(s"Main: Task $i: ${f.isDone}\n")
        i += 1
      }
      try {
        TimeUnit.MILLISECONDS.sleep(50)
      } catch {
        case e: InterruptedException =>
          logger.error("Something wrong when doing encryption")
      }
    }
   */
    var doneNumber = 0
    for (f <- list) {
      //logger.info(s"Main: Task ${f.get()}: ${f.isDone}\n")
      if (f.isDone) {
        doneNumber += 1
      }
    }
    executor.shutdown()

    logger.info(s"Total number of files is ${backupDataFiles.size}. Only $doneNumber files are completed.")
    if (doneNumber < backupDataFiles.size) {
      logger.error(s"There are some files not being encrypted successfully.")
    }
  }

  /**
   * encrypt data file
   */
  @throws[Exception]
  def encryptAndCopyDataFile(backupData:BackupDataFile, pk:PublicKey, rootInput:String, rootOutput:String):Unit = {
    val inputDataPath: Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)
    val outputDataPath: Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)
    //val inputLogPath: Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
    //  backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)
    val outputLogPath: Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)
    if (!fileEncryptor.isToExcludeEncDec(backupData)) {
      try {
        val securedKey = createDataKey(pk, backupData, rootOutput)
        val inputFile = Paths.get(inputDataPath.toAbsolutePath.toString, backupData.dataFileName)
        val outputFile = Paths.get(outputDataPath.toAbsolutePath.toString, backupData.dataFileName)
        fileEncryptor.encryptAndCopy(inputFile.toFile, outputFile.toFile, securedKey)
        logger.info("encrypted file: " + outputFile.toAbsolutePath.toString)
        val encDoneFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.encDoneName)
        fileUtil.deleteAndCreateFile(encDoneFileOutput)
        val encFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.encFailName)
        fileUtil.deleteFile(encFailFileOutput)
      } catch {
        case e: Exception =>
          logger.error(s"Something wrong when encrypting file $backupData", e)
          val encFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.encFailName)
          fileUtil.deleteAndCreateFile(encFailFileOutput)
      }
    }
  }

  def createDataKey(pk:PublicKey, backupData:BackupDataFile, rootOutput:String):Array[Byte] = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    val outputKeyPath:Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)
    val cipherSecuredKeyFile = Paths.get(outputKeyPath.toAbsolutePath.toString,  backupData.dataFileName + "." + NZFileEncryptConfig.cipherKeyFileName)
    fileUtil.writeBytesToFile(cipherSecuredKey, cipherSecuredKeyFile.toFile)
    securedKey
  }

}
