package com.bmo.idp.encryption

import java.nio.file.{Files, Path, Paths}
import java.security.PrivateKey

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.{BackupFile, BackupType}
import com.bmo.idp.encryption.util.{NZBackupFileUtil, NZFileEncryptionUtil, NZFileUtil, RSAUtil}


object NZFileBatchDecryptorGCM extends NZLogger {
  val fileEncryptor = NZFileEncryptionUtil
  val fileUtil = NZFileUtil


  def main(args: Array[String]) = {
    //NZConfig.parseArgs("src/main/resources/application.conf")
    NZConfig.parseArgs(args)
    //fileEncryptor = new NZFileEncryptionUtil
    val (dbName, dbTimestampName) = NZConfig.getBackupFilesArgs(args)
    val start = System.currentTimeMillis
    decryptAndCopyFolder(dbName, dbTimestampName, NZFileEncryptConfig.INPUT_DEC, NZFileEncryptConfig.OUTPUT_DEC)
    val finish = System.currentTimeMillis
    val timeElapsed = finish - start
    logger.info("took miliseconds:" + timeElapsed)

  }


  /**
   * Decryption from root encrypted folder to root decrypted folder

   */
  def decryptAndCopyFolder(dbName:String, dbTimestampName:String, rootInput:String, rootOutput:String) = {
    val backupFiles:BackupFile = NZBackupFileUtil.buildBackupFiles(rootInput, dbName, dbTimestampName)
    val keyPath = Paths.get(NZFileEncryptConfig.PUB_KEY_FOLDER, NZFileEncryptConfig.privateKeyFileName)
    val privateKeyStr:String = fileUtil.readFileAsString(keyPath)
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    val backupTypes:List[BackupType] = backupFiles.dbSequences.flatMap(f=>f.backupTypes)
    for (backupType <- backupTypes) {
      try {
        decryptAndCopyFilesUnderBackupTypeFolder(backupType, privateKey, rootInput, rootOutput)
      } catch {
        case e: Exception =>
          logger.error(s"Something wrong when handling backupType in $backupType", e)
      }
    }
  }

  /**
   * decrypt Files under Backup Type Folder
   */
  @throws[Exception]
  def decryptAndCopyFilesUnderBackupTypeFolder(backupType:BackupType, pk:PrivateKey, rootInput:String, rootOutput:String) = {
    //create folders
    NZBackupFileUtil.createBackupTypeFolderOnOutput(backupType, rootOutput, false)
    //copy md file, write log for md done, no encryption
    copyMDFiles(backupType, rootInput, rootOutput)
    //create key
    val securedKey: Array[Byte] = getDataKey(pk, backupType, rootInput)
    //encrypt and copy data files
    decryptAndCopyDataFilesUnderBackupTypeFolder(backupType, securedKey, rootInput, rootOutput)
  }

  @throws[Exception]
  def decryptAndCopyDataFilesUnderBackupTypeFolder(backupType:BackupType, securedKey: Array[Byte], rootInput:String, rootOutput:String):Unit = {
    val inputDataPath:Path = Paths.get(rootInput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val outputDataPath:Path = Paths.get(rootOutput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val inputLogPath:Path = Paths.get(rootInput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)
    val outputLogPath:Path = Paths.get(rootOutput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)

    val inputFiles = fileUtil.listFiles(inputDataPath)
    for (file <- inputFiles) {
      try {
        if (!fileEncryptor.isToExcludeEncDec(file)) {
          val encDoneFileInput = Paths.get(inputLogPath.toAbsolutePath.toString,
            file.getFileName.toString + "." + NZFileEncryptConfig.encDoneName)
          if (Files.notExists(encDoneFileInput)) {
            logger.info("The file is not ready to be decrypted: " + file.toAbsolutePath.toString)
          } else {
            val outputFile = Paths.get(outputDataPath.toAbsolutePath.toString, file.getFileName.toString)
            fileEncryptor.decryptAndCopyGCM256(file.toFile, outputFile.toFile, securedKey)
            logger.info("decrypted file: " + outputFile.toAbsolutePath.toString)

            val decDoneFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, file.getFileName.toString + "." + NZFileEncryptConfig.decDoneName)
            fileUtil.deleteAndCreateFile(decDoneFileOutput)

            val decFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, file.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
            fileUtil.deleteFile(decFailFileOutput)
          }
        }
      } catch {
        case e:Exception => {
          logger.error(s"Something wrong when decrypting file ${file.toAbsolutePath.toString}", e)
          val decFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, file.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
          fileUtil.deleteAndCreateFile(decFailFileOutput)
        }
      }
    }
  }

  def getDataKey(pk:PrivateKey, backupType:BackupType, rootInput:String):Array[Byte] = {
    val cipherDataKeyPath:Path = Paths.get(rootInput, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.DATA_KEY_FOLDER)
    val cipherSecuredKeyFile = Paths.get(cipherDataKeyPath.toAbsolutePath.toString, NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = fileUtil.readFileToBytes(cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  def copyMDFiles(backupType:BackupType, inputRoot:String, outputRoot:String): Any = {
    val inputMDPath:Path = Paths.get(inputRoot, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.MD_FOLDER)
    val outputMDPath:Path = Paths.get(outputRoot, backupType.dbName, backupType.timestampName,
      backupType.dbSequenceName, backupType.backupTypeName, NZFileEncryptConfig.MD_FOLDER)

    val encDonePath: Path = Paths.get(inputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
      NZFileEncryptConfig.MD_FOLDER  + NZFileEncryptConfig.END_DONE)

    if (Files.notExists(encDonePath)) {
      logger.info("MD files are not ready to be copied.")
      return
    }

    //copy schema files under md, no encryption needed
    try {
      val inputFiles = NZFileUtil.listFiles(inputMDPath)
      for (file <- inputFiles) {
        val outputFile = Paths.get(outputMDPath.toAbsolutePath.toString, file.getFileName.toString)
        NZFileUtil.copyReplacePath(file, outputFile)
        logger.info("MD file copied to " + outputFile.toAbsolutePath.toString)
      }
      //create md.done under output log folder
      val outputLogPath:Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
        NZFileEncryptConfig.MD_FOLDER+NZFileEncryptConfig.END_DONE)
      NZFileUtil.deleteAndCreateFile(outputLogPath)
      val outputFailPath: Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
        NZFileEncryptConfig.MD_FOLDER+NZFileEncryptConfig.END_FAIL)
      NZFileUtil.deleteFile(outputFailPath)
    } catch {
      case e:Exception => {
        logger.error(s"Something wrong when coping MD files ${inputMDPath.toAbsolutePath.toString}", e)
        val outputLogPath:Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
          NZFileEncryptConfig.MD_FOLDER+NZFileEncryptConfig.END_FAIL)
        NZFileUtil.deleteAndCreateFile(outputLogPath)
      }
    }


  }

}
