package com.bmo.idp.encryption

import java.nio.file.{Files, Path, Paths}
import java.security.PrivateKey
import java.util.concurrent.{Callable, Executors, Future, ThreadPoolExecutor}

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.{BackupDataFile, BackupFilesConfig}
import com.bmo.idp.encryption.util.{NZBackupFileUtil, NZFileEncryptionUtil, NZFileUtil, RSAUtil}


object NZFileDecryptor extends NZLogger {
  val fileEncryptor = NZFileEncryptionUtil
  val fileUtil = NZFileUtil


  def main(args: Array[String]) = {
    //NZConfig.parseArgs("src/main/resources/application.conf")
    NZConfig.parseArgs(args)
    val backupFilesConfig : BackupFilesConfig = NZBackupFileUtil.getBackupFilesConfigs(args)
    NZFileEncryptConfig.INPUT = backupFilesConfig.root_input
    NZFileEncryptConfig.OUTPUT = backupFilesConfig.root_output
    val (a,b) =NZBackupFileUtil.buildBackupDataFileList(backupFilesConfig)
    checkOutputDirectoryTreeCreated(b, backupFilesConfig.root_output)
    decryptAndCopyDataFiles(b, backupFilesConfig.root_input, backupFilesConfig.root_output)
  }


  /**
   * checkOutputDirectoryTreeCreated
   */
  def checkOutputDirectoryTreeCreated(backupDataFiles: List[BackupDataFile], rootOutput:String) = {
    for (backupData:BackupDataFile <- backupDataFiles) {
      NZBackupFileUtil.checkOutputDirectoryTreeCreated(backupData, rootOutput)
    }
  }

  /**
   * Decryption for data files
   */
  def decryptAndCopyDataFiles(backupDataFiles: List[BackupDataFile], rootInput:String, rootOutput:String) = {
    val keyPath = Paths.get(NZFileEncryptConfig.PUB_KEY_FOLDER, NZFileEncryptConfig.privateKeyFileName)
    val privateKeyStr:String = fileUtil.readFileAsString(keyPath)
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    if (NZConfig.threads <=1 ) {
      for (backupData: BackupDataFile <- backupDataFiles) {
        decryptAndCopyDataFileTask(backupData, rootInput, rootOutput, privateKey)
      }
    } else {
      decryptAndCopyDataFilesMultiThreading(backupDataFiles, rootInput, rootOutput, privateKey)
    }
  }

  //below to be multiple-threading
  def decryptAndCopyDataFileTask(backupData:BackupDataFile, rootInput:String, rootOutput:String, privateKey:PrivateKey) = {
    if (NZBackupFileUtil.isMDFile(backupData)) {
      NZBackupFileUtil.copyMDFile(backupData, rootInput, rootOutput)
    } else {
      decryptAndCopyDataFile(backupData, privateKey, rootInput, rootOutput)
    }
  }

  class DecryptAndCopyDataFileCallable(backupData:BackupDataFile, rootInput:String, rootOutput:String, pk:PrivateKey) extends Callable[BackupDataFile] {
    @throws[Exception]
    def call():BackupDataFile = {
      var result = backupData
      decryptAndCopyDataFileTask(backupData, rootInput, rootOutput, pk)
      result
    }
  }

  def decryptAndCopyDataFilesMultiThreading(backupDataFiles: List[BackupDataFile], rootInput:String, rootOutput:String, pk:PrivateKey) = {
    import collection.JavaConverters._

    val max_threads = List(NZConfig.MAX_THREAD_POOL, NZConfig.threads, backupDataFiles.size, NZFileEncryptionUtil.getAvailableProcessors).min
    val executor = Executors.newFixedThreadPool(max_threads).asInstanceOf[ThreadPoolExecutor]
    val decryptAndCopyDataFileCallables:List[DecryptAndCopyDataFileCallable] = backupDataFiles.map(dataFile=>new DecryptAndCopyDataFileCallable(dataFile, rootInput, rootOutput, pk))
    var list:List[Future[BackupDataFile]] = null

    logger.info(s"Start executor in $max_threads threads")
    try {
      list = executor.invokeAll(decryptAndCopyDataFileCallables.asJavaCollection).asScala.toList
    } catch {
      case e:Exception => {
        logger.error("error in decryptAndCopyDataFilesMultiThreading", e)
      }
    }
    logger.info("Completed executor")

    var doneNumber = 0
    for (f <- list) {
      //logger.info(s"Main: Task ${f.get()}: ${f.isDone}\n")
      if (f.isDone) {
        doneNumber += 1
      }
    }
    executor.shutdown()

    logger.info(s"Total number of files is ${backupDataFiles.size}. Only $doneNumber files are completed.")
    if (doneNumber < backupDataFiles.size) {
      logger.error(s"There are some files not being decrypted successfully.")
    }
  }




  def getDataKey(pk:PrivateKey, backupData:BackupDataFile, rootInput:String):Array[Byte] = {
    val cipherDataKeyPath:Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)
    val cipherSecuredKeyFile = Paths.get(cipherDataKeyPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = fileUtil.readFileToBytes(cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  @throws[Exception]
  def decryptAndCopyDataFile(backupData:BackupDataFile, pk:PrivateKey, rootInput:String, rootOutput:String):Unit = {
    val inputDataPath:Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val outputDataPath:Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.DATA_FOLDER)
    val inputLogPath:Path = Paths.get(rootInput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)
    val outputLogPath:Path = Paths.get(rootOutput, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, NZFileEncryptConfig.LOG_FOLDER)

    if (!fileEncryptor.isToExcludeEncDec(backupData)) {
      try {
        val securedKey = getDataKey(pk, backupData, rootInput)
        val inputFile = Paths.get(inputDataPath.toAbsolutePath.toString, backupData.dataFileName)
        val outputFile = Paths.get(outputDataPath.toAbsolutePath.toString, backupData.dataFileName)
        val encDoneFileInput = Paths.get(inputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.encDoneName)
        if (Files.notExists(encDoneFileInput)) {
          logger.info("The file is not ready to be decrypted: " + inputFile.toAbsolutePath.toString)
        } else {
          fileEncryptor.decryptAndCopy(inputFile.toFile, outputFile.toFile, securedKey)
          logger.info("decrypted file: " + outputFile.toAbsolutePath.toString)

          val decDoneFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.decDoneName)
          fileUtil.deleteAndCreateFile(decDoneFileOutput)

          val decFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.decFailName)
          fileUtil.deleteFile(decFailFileOutput)
        }
      } catch {
        case e: Exception =>
          logger.error(s"Something wrong when encrypting file $backupData", e)
          val decFailFileOutput = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName + "." + NZFileEncryptConfig.decFailName)
          fileUtil.deleteAndCreateFile(decFailFileOutput)
      }
    }
  }

}
