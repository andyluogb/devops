package com.bmo.idp.encryption.util

import java.security.SecureRandom
import java.util.Base64

import com.amazonaws.util.BinaryUtils
import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.spec.SecretKeySpec
import javax.crypto.{KeyGenerator, SecretKey}

object SecretKeyGenerator extends NZLogger {

  //SecureRandom.get
  //rnd.setSeed(SecureRandom.generateSeed(100))
  def generateSecureRandomBytes: String = {
    var rnd: SecureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
    val rawKey: Array[Byte] = Array.ofDim[Byte](16) // 128 bits
    rnd.setSeed(rnd.generateSeed(16))
    //logger.info(s"rawKey:%d",rawKey.length)
    rnd.nextBytes(rawKey)
    BinaryUtils.toBase64(rawKey)
  }


  def genSecuredKey128ByteArray: Array[Byte] = {
    var rnd: SecureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
    val rawKey: Array[Byte] = Array.ofDim[Byte](16) // 128 bits
    rnd.setSeed(rnd.generateSeed(16))
    //logger.info(s"rawKey:%d",rawKey.length)
    rnd.nextBytes(rawKey)
    rawKey
  }

  def genSecuredKey256ByteArray: Array[Byte] = {
    var rnd: SecureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
    val rawKey: Array[Byte] = Array.ofDim[Byte](32) // 256 bits
    rnd.setSeed(rnd.generateSeed(32))
    //logger.info(s"rawKey:%d",rawKey.length)
    rnd.nextBytes(rawKey)
    rawKey
  }


  def genEncryptionKey128: SecretKey = {
    val rnd: SecureRandom = new SecureRandom
    val rawKey = new Array[Byte](16) // 128 bits
    rnd.nextBytes(rawKey)
    new SecretKeySpec(rawKey, "AES")
  }

  def genSecuredKey256:SecretKey =  {
    val keyGenerator = KeyGenerator.getInstance("AES")
    val secureRandom = new SecureRandom()
    val keyBitSize = 256
    keyGenerator.init(keyBitSize, secureRandom)
    val secretKey = keyGenerator.generateKey
    secretKey
  }

  def genIV16:Array[Byte] =  {
    val IV: Array[Byte] = new Array[Byte](16)
    val random = new SecureRandom
    random.nextBytes(IV)
    IV
  }

  def secretKeyToString(secretKey: SecretKey):String = {
    val encodedKey = Base64.getEncoder.encodeToString(secretKey.getEncoded)
    encodedKey
  }

  def stringToSecretKey(secretKey: String):SecretKey = {
    // decode the base64 encoded string// decode the base64 encoded string
    val decodedKey = Base64.getDecoder.decode(secretKey)
    // rebuild key using SecretKeySpec
    val originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES")
    originalKey
  }

  def secretKeyToBytes(secretKey: SecretKey):Array[Byte] = {
    secretKey.getEncoded
  }

  def bytesToSecretKey(secretKey: Array[Byte]):SecretKey = {
    val originalKey = new SecretKeySpec(secretKey, 0, secretKey.length, "AES")
    originalKey
  }

}
