package com.bmo.idp.encryption.util

import java.io.{RandomAccessFile, _}
import java.nio.channels.FileChannel
import java.nio.file.{Files, Path, Paths, StandardCopyOption}

import com.bmo.idp.encryption.logger.NZLogger
import org.apache.commons.io.IOUtils
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

import scala.collection.mutable.ListBuffer
import scala.io.Source

object NZFileUtil extends NZLogger{
  val bufferSize:Int = 65536

  def getCurrentPath = {
    val currentDirectory = new java.io.File(".").getCanonicalPath
    currentDirectory
  }

  def getPathByRelatedFileName(fileName:String):Path = {
    val filePath: Path = Paths.get(getCurrentPath, fileName)
    filePath
  }

  def getRelatedFile(fileName: String, folder: String): File = {
    val filePath: Path = Paths.get(getCurrentPath, folder, fileName)
    val inFile = filePath.toFile
    inFile
  }

  def getInputStream(src: File): InputStream = {
    val is = new FileInputStream(src)
    is
  }

  def getOutputStream(src: File): OutputStream = {
    val os = new FileOutputStream(src)
    os
  }

  @throws[IOException]
  def writeBytesToRelatedFileUnderFolder(byteArray: Array[Byte], filename: String, folder: String) = {
    val oFile = getRelatedFile(filename, folder)
    writeBytesToFile(byteArray, oFile)
  }

  @throws[IOException]
  def writeBytesToFile(byteArray: Array[Byte], file: File) = {
    val bos = new BufferedOutputStream(new FileOutputStream(file))
    bos.write(byteArray)
    bos.close() // You may end up with 0 bytes file if not calling close.
  }

  @throws[IOException]
  def readRelatedFileToBytes(filename: String, folder: String): Array[Byte] = {
    val filePath: Path = Paths.get(getCurrentPath, folder, filename)
    readFileToBytes(filePath)
  }

  @throws[IOException]
  def readFileToBytes(filePath: Path): Array[Byte] = {
    val byteArray = Files.readAllBytes(filePath)
    byteArray
  }

  def readRelatedFileRelativeAsString(filename: String, folder: String): String = {
    val filePath: Path = Paths.get(getCurrentPath, folder, filename)
    val fileContents = Source.fromFile(filePath.toAbsolutePath.toString).getLines.mkString
    fileContents
  }

  def readFileAsString(filename: String): String = {
    val filePath: Path = Paths.get(filename)
    val fileContents = Source.fromFile(filePath.toAbsolutePath.toString).getLines.mkString
    fileContents
  }
  def readFileAsString(filePath: Path): String = {
    val fileContents = Source.fromFile(filePath.toAbsolutePath.toString).getLines.mkString
    fileContents
  }

  @throws[IOException]
  def copyReplacePath(source:Path, target:Path): Unit = {
    Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES)
  }

  @throws[IOException]
  def createFile(source:File): Unit = {
    source.createNewFile()
  }
  @throws[IOException]
  def createFilePath(source:Path): Unit = {
    Files.createFile(source)
  }

  @throws[IOException]
  def createDirectory(source:Path): Unit = {
    if (Files.notExists(source)) {
      Files.createDirectory(source)
    }
  }

  @throws[IOException]
  def copyReplaceFile(source:File, target:File): Unit = {
    copyReplacePath(source.toPath, target.toPath)
  }

  @throws[IOException]
  def copyFileByChannel(source:Path, target:Path): Unit = {
    val sourceF = new RandomAccessFile(source.toAbsolutePath.toString, "r")
    val destF = new RandomAccessFile(target.toAbsolutePath.toString, "rw")
    val sfc:FileChannel = sourceF.getChannel
    val dfc:FileChannel = destF.getChannel
    try {
      dfc.transferFrom(sfc, 0, sfc.size)
    }finally {
      if (sfc != null) sfc.close()
      if (dfc != null) dfc.close()
    }
  }

  @throws[IOException]
  def copy(is: InputStream, os: OutputStream): Unit = {
    val buffer = new Array[Byte](bufferSize)
    var nRead = is.read(buffer)
    while (nRead != -1) {
      os.write(buffer, 0, nRead)
      nRead = is.read(buffer)
    }
    os.flush()
  }


  @throws[IOException]
  def copyRelatedFile(inputFile: String, outputFile: String, ifolder: String, ofolder: String): Unit = {
    val is = getInputStream(getRelatedFile(inputFile, ifolder))
    val os = getOutputStream(getRelatedFile(outputFile, ofolder))
    try {
      copy(is, os)
    } finally {
      if (is != null) is.close()
      if (os != null) os.close()
    }
  }

  def listFiles(path: Path): List[Path] = {
    var fileList = new ListBuffer[Path]()
    if (Files.isDirectory(path)) {
      val files = Files.list(path)
      for (a <- files.toArray if !Files.isDirectory(a.asInstanceOf[Path])) {
        val b = a.asInstanceOf[Path]
        fileList += b
      }
    }
    fileList.toList
  }

  def listFolders(folder: String): List[Path] = {
    listFolders(new File(folder).toPath)
  }
  def listFolders(folder: Path): List[Path] = {
    var folders = new ListBuffer[Path]()
    val files = Files.list(folder)
    for (a <- files.toArray if Files.isDirectory(a.asInstanceOf[Path])) {
      val b = a.asInstanceOf[Path]
      folders += b
    }
    folders.toList
  }
  def listFoldersUnderFolders(folders: List[Path]): List[Path] = {
    val f = folders.map(p=>listFolders(p)).flatten.toList
    f
  }
  def listFilesUnderFolders(folders: List[Path]): List[Path] = {
    val f = folders.map(p=>listFiles(p)).flatten.toList
    f
  }

  def getCurrentDateTimeStr(): String = {
    val dt = new DateTime
    val fmt = DateTimeFormat.forPattern("yyyy-MM-dd-HH-mm-ss")
    val str = fmt.print(dt)
    logger.info("current data time:" + str)
    str
  }

  def getListOfFiles(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }

  def getListOfFolders(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isDirectory).toList
    } else {
      List[File]()
    }
  }

  def recursiveListAllFile(base: String): List[File] = {
    val basedFile = new File(base)
    val files = new ListBuffer[File]
    recursiveListAllFiles(basedFile, files)
    files.toList
  }
  def recursiveListAllFiles(base: File, files:ListBuffer[File]): ListBuffer[File] = {
    val fileList: List[File] = base.listFiles.toList
    for (file <- fileList) {
      if (file.isFile) {
        files += file
      }
      else {
        if (file.isDirectory) {
          files += file
          recursiveListAllFiles(file, files)
        }
      }
    }
    files
  }

  def printFileName(files: List[File]): Unit = {
    files.foreach(a => logger.info(a.getName))
  }

  def printPathName(files: List[Path]): Unit = {
    files.foreach(a => logger.info(a.getFileName))
  }

  def deleteAndCreateFile(file:Path) = {
    Files.deleteIfExists(file)
    Files.createFile(file)
  }

  def deleteAndCreateFile(file:File) = {
    if (file.exists()) file.delete()
    file.createNewFile()
  }

  def deleteFile(path:Path): Unit = {
    Files.deleteIfExists(path)
  }

  def deleteFilesUnderFolder(folder:Path):Boolean = {
    if (Files.exists(folder)) {
      listFiles(folder).foreach(file=>Files.delete(file))
    }
    true
  }

  def deleteFolder(folder:Path):Boolean = {
    if (Files.exists(folder)) {
      listFiles(folder).foreach(file=>Files.delete(file))
      listFolders(folder).foreach(subFolder=>deleteFolderRecursive(subFolder))
    }
    true
  }

  def deleteFolderRecursive(folder:Path):Boolean = {
    if (Files.exists(folder)) {
      listFiles(folder).foreach(file=>Files.delete(file))
      listFolders(folder).foreach(subFolder=>deleteFolderRecursive(subFolder))
      Files.delete(folder)
    }
    true
  }

  @throws[IOException]
  def toByteArray(in: InputStream ): Array[Byte] = {
    try {
      val bytes = IOUtils.toByteArray(in)
      bytes
    } finally {
      in.close()
    }
  }


  @throws[IOException]
  def readAllBytes(in: InputStream ): Array[Byte] = {
    val baos = new ByteArrayOutputStream
    val buf = new Array[Byte](1024)
    var read = 0
    while ( {
      read != -1
    }) {
      baos.write(buf, 0, read)
      read = in.read(buf)
    }
    baos.toByteArray
  }
}