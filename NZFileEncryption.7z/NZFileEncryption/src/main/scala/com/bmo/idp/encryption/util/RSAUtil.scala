package com.bmo.idp.encryption.util

import java.io.IOException
import java.nio.charset.StandardCharsets
import java.security.spec.{PKCS8EncodedKeySpec, X509EncodedKeySpec}
import java.security.{KeyFactory, PrivateKey, _}
import java.util.Base64

import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.Cipher
import org.apache.commons.codec.binary.{Base64 => ABase64}

object RSAUtil extends NZLogger {
  val CYPHER_ECB_PKCS1: String = "RSA/ECB/PKCS1PADDING"
  val CYPHER_ECB_SHA256: String ="RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING"
  val SECURE_ALGORITHM:String = "SHA1PRNG"
  val ALGORITHM_RSA:String = "RSA"
  val KEY_SIZE=2048


  def getPrivKeyFromStr(privateKeyStr:String): PrivateKey = {
    // Remove the "BEGIN" and "END" lines, as well as any whitespace
    var pkcs8Pem = privateKeyStr
    pkcs8Pem = pkcs8Pem.replace("-----BEGIN PRIVATE KEY-----", "")
    pkcs8Pem = pkcs8Pem.replace("-----END PRIVATE KEY-----", "")
    pkcs8Pem = pkcs8Pem.replace("-----BEGIN RSA PRIVATE KEY-----", "")
    pkcs8Pem = pkcs8Pem.replace("-----END RSA PRIVATE KEY-----", "")
    pkcs8Pem = pkcs8Pem.replaceAll("\\s+", "")
    // Base64 decode the result
    val pkcs8EncodedBytes = Base64.getDecoder.decode(pkcs8Pem)
    // extract the private key
    val keySpec = new PKCS8EncodedKeySpec(pkcs8EncodedBytes)
    val kf = KeyFactory.getInstance(ALGORITHM_RSA)
    val privKey = kf.generatePrivate(keySpec)
    privKey
  }

  @throws[IOException]
  @throws[GeneralSecurityException]
  def getPublicKeyFromString(key: String): PublicKey = {
    var publicKeyPEM = key
    publicKeyPEM = publicKeyPEM.replace("-----BEGIN PUBLIC KEY-----", "")
    publicKeyPEM = publicKeyPEM.replace("-----END PUBLIC KEY-----", "")
    publicKeyPEM = publicKeyPEM.replace("-----BEGIN RSA PUBLIC KEY-----\n", "")
    publicKeyPEM = publicKeyPEM.replace("-----END RSA PUBLIC KEY-----", "")
    publicKeyPEM = publicKeyPEM.replaceAll("\\s+", "")
    val encoded = ABase64.decodeBase64(publicKeyPEM)
    val kf = KeyFactory.getInstance(ALGORITHM_RSA)
    val pubKey = kf.generatePublic(new X509EncodedKeySpec(encoded))
    pubKey
  }

  def rsaDecrypt(cipherText: String, privateKey: PrivateKey): String = {
    val cipher = Cipher.getInstance(CYPHER_ECB_PKCS1)
    cipher.init(Cipher.DECRYPT_MODE, privateKey)
    val cipherBytes = ABase64.decodeBase64(cipherText) //Base64.getDecoder.decode(cipherText)
    val clearBytes = cipher.doFinal(cipherBytes)
    new String(clearBytes, StandardCharsets.UTF_8)
  }

  def rsaEncrypt(clearText: String, publicKey: PublicKey) = {
    val cipher = Cipher.getInstance(CYPHER_ECB_PKCS1)
    cipher.init(Cipher.ENCRYPT_MODE, publicKey)
    val res = cipher.doFinal(clearText.getBytes(StandardCharsets.UTF_8))
    ABase64.encodeBase64String(res)
  }

  def rsaSha256Encrypt(publicKey: PublicKey, clearText: Array[Byte]) : Array[Byte] = {
    val cipher = Cipher.getInstance(CYPHER_ECB_SHA256)
    cipher.init(Cipher.ENCRYPT_MODE, publicKey)
    val res = cipher.doFinal(clearText)
    res
  }

  def rsaSha256Decrypt(privateKey: PrivateKey, cipherText: Array[Byte]): Array[Byte] = {
    val cipher = Cipher.getInstance(CYPHER_ECB_SHA256)
    cipher.init(Cipher.DECRYPT_MODE, privateKey)
    val clearText = cipher.doFinal(cipherText)
    clearText
  }

  def getKeyPairGenerator:KeyPairGenerator = {
    val factory = KeyPairGenerator.getInstance(ALGORITHM_RSA)
    factory.initialize(KEY_SIZE)
    //factory.initialize(KEY_SIZE, SecureRandom.getInstance(SECURE_ALGORITHM))
    factory
  }
  def generateKeyPair:KeyPair = {
    val keyPair:KeyPair = getKeyPairGenerator.generateKeyPair()
    keyPair
  }

  def testRsa = {
    val keys : KeyPair = generateKeyPair
    val publicKey = keys.getPublic
    logger.info(publicKey)
    val someMessage = "some message hello"
    val emptyMessage = ""

    var encryptedMessage = rsaEncrypt(someMessage, publicKey)
    var decryptedMessage = rsaDecrypt(encryptedMessage, keys.getPrivate)
    logger.info("==someMessage:" + someMessage)
    logger.info("==someMessage length:" + someMessage.length)
    logger.info("==encryptedMessage:" + encryptedMessage)
    logger.info("==decryptedMessage:" + decryptedMessage)

    encryptedMessage = rsaEncrypt(emptyMessage, publicKey)
    decryptedMessage = rsaDecrypt(encryptedMessage, keys.getPrivate)
    logger.info("==emptyMessage:" + emptyMessage)
    logger.info("==encryptedMessage:" + encryptedMessage)
    logger.info("==decryptedMessage:" + decryptedMessage)
  }

  def testRsaLength(someMessage:String) = {
    logger.info("==someMessage:" + someMessage)
    logger.info("==someMessage length:" + someMessage.length)

    val keys : KeyPair = generateKeyPair
    var encryptedMessage = rsaEncrypt(someMessage, keys.getPublic)
    var decryptedMessage = rsaDecrypt(encryptedMessage, keys.getPrivate)
   logger.info("==encryptedMessage:" + encryptedMessage.length)
   logger.info("==decryptedMessage:" + decryptedMessage.length)
  }

}
