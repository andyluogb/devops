package com.bmo.idp.encryption.parser

object AddressType extends Enumeration {
  type AddressType = Value
  val HARDWARE_ADDRESS = Value(0)
  val NETWORK_ADDRESS = Value(1)
}





