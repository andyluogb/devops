package com.bmo.idp.encryption.parser

import scodec._
import scodec.bits._
import scodec.codecs._

case class NetworkAddress(domain: Int, subnet: Int, node: Int) {
  require ((0 <= domain) && (domain <= 7))
  require ((0 <= subnet) && (subnet <= 255))
  require ((0 <= node) && (node <= 255))
}

object NetworkAddress {
  implicit val codec: Codec[NetworkAddress] = {
    (constant(bin"1")) ::
      ("domain" | uint(3)) ::
      ("subnet" | uint8) ::
      ("node" | uint8)
    }.as[NetworkAddress]
}
