package com.bmo.idp.encryption.parser

import com.bmo.idp.encryption.parser.AddressType.{AddressType, HARDWARE_ADDRESS, NETWORK_ADDRESS}
import com.bmo.idp.encryption.parser.CommandType.CommandType
import scodec._
import scodec.codecs._

object PacketImplicits {
  implicit val addressTypeCodec = new AddressTypeCodec()
  implicit def networkAddress2Address(address: NetworkAddress) =
    new Address(NETWORK_ADDRESS, None, Some(address))

  implicit val commandTypeCodec: Codec[CommandType] = mappedEnum(uint(2), CommandType.values.map(v => (v, v.id)).toMap)
}

case class Address(addressType: AddressType, hwAddress: Option[HardwareAddress],
                   netAddress: Option[NetworkAddress])

object Address {
  implicit val codec = {
    (("address_type" | Codec[AddressType]) >>:~ { addressType =>
      ("hardware_address" | conditional(
        addressType == HARDWARE_ADDRESS, Codec[HardwareAddress])) ::
        ("network_address" | conditional(
          addressType == NETWORK_ADDRESS, Codec[NetworkAddress]))
    }).as[Address]
  }
}