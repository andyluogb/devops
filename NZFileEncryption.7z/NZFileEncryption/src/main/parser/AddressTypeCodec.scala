package com.bmo.idp.encryption.parser

import com.bmo.idp.encryption.parser.AddressType.{AddressType,HARDWARE_ADDRESS, NETWORK_ADDRESS}
import scodec.{Attempt, Codec, DecodeResult, Err, SizeBound}
import scodec.bits.BitVector

class AddressTypeCodec() extends Codec[AddressType] {
  override def sizeBound = SizeBound.exact(1)
  override def encode(a: AddressType) = Attempt.successful(BitVector.empty)

  override def decode(buffer: BitVector) =
    buffer.acquire(1) match {
      case Left(e) => Attempt.failure(Err.insufficientBits(1, buffer.size))
      case Right(b) =>
        Attempt.successful(
          DecodeResult(
            if (b(0)) NETWORK_ADDRESS else HARDWARE_ADDRESS,
            buffer
          )
        )
    }

  override def toString = s"AddressTypeCodec"
}