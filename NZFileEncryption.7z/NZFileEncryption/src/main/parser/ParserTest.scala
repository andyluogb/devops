package com.bmo.idp.encryption.parser

import scodec._
import scodec.bits._
import scodec.codecs._

import com.bmo.idp.encryption.parser.CommandType._
import com.bmo.idp.encryption.parser.Packet

object ParserTest {
    def main(args:Array[String]):Unit = {
      val p = Packet(false, 0, NetworkAddress(1, 2, 3), REQUEST)
      println(p)
      //Packet(false,0,Address(NETWORK_ADDRESS,None,Some(NetworkAddress(1,2,3))),REQUEST,4,0,Vector())
      println(Codec.encode(p))
      //Successful(BitVector(48 bits, 0x090203040000))
      println(Codec.encode(p).require.toBin)
      //000010010000001000000011000001000000000000000000
      println(Codec[Packet].decode(hex"0x090203040000".bits))
      println(Codec[Packet].decode(bin"000010010000001000000011000001000000000000000000"))
      //Successful(DecodeResult(Packet(false,0,
      //  Address(NETWORK_ADDRESS,None,Some(NetworkAddress(1,2,3))),
      //  REQUEST,4,0,Vector()),BitVector(empty)))
      println(Codec[Packet].decode(Codec.encode(p).require).require.value == p)
      //true
    }

}
