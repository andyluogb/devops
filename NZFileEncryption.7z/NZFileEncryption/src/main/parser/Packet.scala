package com.bmo.idp.encryption.parser

import com.bmo.idp.encryption.parser.CommandType.CommandType
import scodec._
import scodec.codecs._

case class Packet(highPriority: Boolean, tag: Int, address: Address,
                  command:CommandType, dataLength: Int, data: Vector[Int]) {
  require (dataLength == data.length)
}

object Packet {
  implicit val codec: Codec[Packet] = {
    ("high_priority" | bool) ::
      ("tag" | uint(3)) ::
      ("address" | Codec[Address]) ::
      ("command_type" | Codec[CommandType]) ::
      ("command" | uint(6)) ::
      (("data_length" | uint16) >>:~ { length =>
        ("data" | vectorOfN(provide(length), uint8)).hlist
      })
    }.as[Packet]

  def apply(highPriority: Boolean, tag: Int, address: Address,
            commandType: CommandType,  data: Vector[Int] = Vector()) =
    new Packet(highPriority, tag, address, commandType, data.length, data)
}