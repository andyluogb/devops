package com.bmo.idp.encryption.parser

object CommandType extends Enumeration {
  type CommandType = Value
  val REQUEST = Value(0)
  val RESPONSE = Value(1)
  val UNSOLICITED = Value(2)
}


