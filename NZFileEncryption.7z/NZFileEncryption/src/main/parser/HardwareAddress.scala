package com.bmo.idp.encryption.parser

import scodec._
import scodec.bits._
import scodec.codecs._

// src\main\scala\Parse.scala
case class HardwareAddress(address: Vector[Int]) {
  require (address.length == 8)
  address.foreach(digit => require ( (0x00 <= digit) && (digit <= 0x0F) ))
}

object HardwareAddress {
  implicit val codec: Codec[HardwareAddress] = {
    (constant(bin"0")) ::
      (ignore(3)) ::
      ("address" | vectorOfN(provide(8), uint(4)))
    }.as[HardwareAddress]
}