package sample.igite;

import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;

public class SimpleIgniteCallable implements IgniteCallable<List<List<?>>> {
    @IgniteInstanceResource
    Ignite ignite;
    
    private String ids;
    
    public SimpleIgniteCallable(String ids) {
    	this.ids = ids;
    }

    @Override public List<List<?>> call() {
        System.out.println(">> Executing the compute SimpleIgniteCallable");
        CacheConfiguration<?, ?> cacheCfg = new CacheConfiguration<>("dummy_cache").setSqlSchema("PUBLIC");
        IgniteCache<?, ?> dummyCache = ignite.getOrCreateCache(cacheCfg);
        List<List<?>> joinResult = dummyCache.query(new SqlFieldsQuery(
                "SELECT * FROM city a join country b ON a.COUNTRYCODE = b.CODE JOIN PUBLIC.COUNTRYLANGUAGE c ON b.CODE = c.countrycode WHERE a.ID IN (" + ids + ")")).getAll();

        return joinResult;
    }
}