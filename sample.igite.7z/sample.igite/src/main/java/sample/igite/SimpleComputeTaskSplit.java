package sample.igite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.compute.ComputeJob;
import org.apache.ignite.compute.ComputeJobAdapter;
import org.apache.ignite.compute.ComputeJobResult;
import org.apache.ignite.compute.ComputeTaskSplitAdapter;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.jetbrains.annotations.Nullable;

public class SimpleComputeTaskSplit extends ComputeTaskSplitAdapter<String, List<List<?>>> {
        /**
         * Splits the received string to words, creates a child job for each word, and sends
         * these jobs to other nodes for processing. Each such job simply prints out the received word.
         *
         * @param clusterSize Number of available cluster nodes. Note that returned number of
         *      jobs can be less, equal or greater than this cluster size.
         * @param arg Task execution argument. Can be {@code null}.
         * @return The list of child jobs.
         */
        @Override protected Collection<? extends ComputeJob> split(int clusterSize, String arg) {
            Collection<ComputeJob> jobs = new LinkedList<>();
            final int chunkSize = clusterSize;
            final Collection<List<String>> idList = splitString(arg, chunkSize);
            System.out.println(">>> clusterSize '" + clusterSize);
            System.out.println(">>> idList.size() '" + idList.size());

            for (final List<String> ids : idList) {
                jobs.add(new ComputeJobAdapter() {
                    @IgniteInstanceResource
                    Ignite ignite;
                    @Nullable @Override public Object execute() {
                        System.out.println();
                        System.out.println(">>> Printing '" + ids + "' on this node from ignite job.");
                        
                        CacheConfiguration<?, ?> cacheCfg = new CacheConfiguration<>("dummy_cache").setSqlSchema("PUBLIC");
                        IgniteCache<?, ?> dummyCache = ignite.getOrCreateCache(cacheCfg);
                        List<List<?>> joinResult = dummyCache.query(new SqlFieldsQuery(
                                "SELECT * FROM city a join country b ON a.COUNTRYCODE = b.CODE JOIN PUBLIC.COUNTRYLANGUAGE c ON b.CODE = c.countrycode WHERE a.ID IN (" + String.join(",", ids) + ")")).getAll();

                        // Return number of letters in the word.
                        return joinResult;
                    }
                });
            }

            return jobs;
        }

		private Collection<List<String>> splitString(String arg, final int chunkSize) {
                List<String> ags = Arrays.asList(arg.split(","));
                AtomicInteger counter = new AtomicInteger();
                Collection<List<String>> idtempList = ags.stream()
                    .collect(Collectors  .groupingBy(it -> counter.getAndIncrement() % chunkSize))
                    .values();
			return idtempList;
		}

        /** {@inheritDoc} */
        @Nullable @Override public List<List<?>> reduce(List<ComputeJobResult> results) {
        	List<List<?>> sum = new ArrayList<List<?>>();

            for (ComputeJobResult res : results)
                sum.addAll(res.<List<List<?>>>getData());

            return sum;
        }
}
