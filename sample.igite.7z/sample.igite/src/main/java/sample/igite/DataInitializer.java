package sample.igite;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.configuration.ClientConfiguration;

public class DataInitializer {
    public static void init() {
    	ClientConfiguration cfg = new ClientConfiguration().setAddresses("127.0.0.1:10800");
    	try (IgniteClient client = Ignition.startClient(cfg)) {
    		Charset charset = Charset.forName("ISO-8859-1");
    		List<String> result = Files.readAllLines(Paths.get("C:\\apache-ignite-2.9.0\\examples\\sql\\world1.sql"), charset);
    		String resultStr = result.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(" "));
    		List<String> results = Arrays.stream(resultStr.split(";")).map(l->l.replace("\n", " ").replace("\r", " ")).filter(StringUtils::isNotBlank).collect(Collectors.toList());
    		final IgniteClient clientFinal = client;
    		results.forEach(l->clientFinal.query(new SqlFieldsQuery(l)).getAll());
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }

}
