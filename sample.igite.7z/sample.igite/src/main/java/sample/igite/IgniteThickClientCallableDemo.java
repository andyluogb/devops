package sample.igite;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.cluster.ClusterState;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.ClientConfiguration;
import org.apache.ignite.configuration.DeploymentMode;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.ignite.spi.deployment.uri.UriDeploymentSpi;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpDiscoveryMulticastIpFinder;

public class IgniteThickClientCallableDemo {
    public static void main(String[] args) throws IgniteException {
    	//DataInitializer.init();
    	//Ignition.setClientMode(true);
    	//Ignite ignite = Ignition.start("./config/example-ignite.xml")
    	Ignite ignite = startClientNode();
    	IgniteCompute compute = ignite.compute(ignite.cluster().forServers());
        // Executing custom Java compute task on server nodes.
    	Collection<List<List<?>>> callableResult = compute.broadcast(new SimpleIgniteCallable("1"));
    	callableResult.stream().forEach(result -> {
    		result.forEach(columns->System.out.println(">>>>>>>>>callableResult = " + columns));
    	}); 
    	
    	List<List<?>> closureResult = compute.apply(new SimpleIgniteClosure(), "1,2");
    	closureResult.forEach(columns->System.out.println(">>>>>>>>>closureResult = " + columns));
    	
        // Disconnect from the cluster.
        ignite.close();
    }
    
    private static Ignite startClientNode() {
        // Preparing IgniteConfiguration using Java APIs
        IgniteConfiguration cfg = new IgniteConfiguration();
        // The node will be started as a client node.
        cfg.setClientMode(true);
        // Classes of custom Java logic will be transferred over the wire from this app.
        cfg.setPeerClassLoadingEnabled(true);
        cfg.setDeploymentMode(DeploymentMode.CONTINUOUS);
        
        // Setting up an IP Finder to ensure the client can locate the servers.
        TcpDiscoveryMulticastIpFinder ipFinder = new TcpDiscoveryMulticastIpFinder();
        ipFinder.setAddresses(Collections.singletonList("127.0.0.1:47500..47509"));
        cfg.setDiscoverySpi(new TcpDiscoverySpi().setIpFinder(ipFinder));
        
        //Setup deploymebnt SPI
        UriDeploymentSpi deploymentSpi = new UriDeploymentSpi();
        deploymentSpi.setUriList(Arrays.asList("file:///c:/luo/workspace/sample.igite/target/classes"));
        cfg.setDeploymentSpi(deploymentSpi);

        // Starting the node
        Ignite ignite = Ignition.start(cfg);
        //ignite.cluster().state(ClusterState.ACTIVE);
        
        return ignite;
    }
}