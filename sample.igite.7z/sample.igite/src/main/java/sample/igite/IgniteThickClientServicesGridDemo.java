/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sample.igite;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteServices;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.cluster.ClusterState;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.ClientConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.examples.ExampleNodeStartup;
import org.apache.ignite.examples.ExamplesUtils;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.ServiceResource;
import org.apache.ignite.services.ServiceConfiguration;

/**
 * Example that demonstrates how to deploy distributed services in Ignite.
 * Distributed services are especially useful when deploying singletons on the ignite,
 * be that cluster-singleton, or per-node-singleton, etc...
 * <p>
 * To start remote nodes, you must run {@link ExampleNodeStartup} in another JVM
 * which will start node with {@code examples/config/example-ignite.xml} configuration.
 * <p>
 * NOTE:<br/>
 * Starting {@code ignite.sh} directly will not work, as distributed services
 * cannot be peer-deployed and classes must be on the classpath for every node.
 */
public class IgniteThickClientServicesGridDemo {
    /**
     * Executes example.
     *
     * @param args Command line arguments, none required.
     * @throws Exception If example execution failed.
     */
    public static void main(String[] args) throws Exception {
        // Mark this node as client node.
        Ignition.setClientMode(true);
    	

        try (Ignite ignite = Ignition.start("./config/example-ignite.xml")) {
        	//ignite.cluster().state(ClusterState.ACTIVE);
        	
            if (!ExamplesUtils.hasServerNodes(ignite))
                return;
            
            //DataInitializer.init();

        	/*ServiceConfiguration serviceCfg = new ServiceConfiguration();
        	serviceCfg.setName("myClusterSingletonService");
        	serviceCfg.setMaxPerNodeCount(1);
        	serviceCfg.setTotalCount(1);
        	serviceCfg.setService(new SimpleMapServiceImpl());
            // Deploy services only on server nodes.
            IgniteServices svcs = ignite.services(ignite.cluster().forServers());

            svcs.deploy(serviceCfg);*/
        	
            IgniteServices svcs = ignite.services(ignite.cluster().forServers());

            try {
                // Deploy cluster singleton.
                svcs.deployClusterSingleton("myClusterSingletonService", new SimpleMapServiceImpl());

                // Deploy node singleton.
                svcs.deployNodeSingleton("myNodeSingletonService", new SimpleMapServiceImpl());

                // Deploy 2 instances, regardless of number nodes.
                svcs.deployMultiple("myMultiService",
                    new SimpleMapServiceImpl(),
                    2 /*total number*/,
                    0 /*0 for unlimited*/);

                // Example for using a service proxy
                // to access a remotely deployed service.
                serviceProxyExample(ignite);

                // Example for auto-injecting service proxy
                // into remote closure execution.
                serviceInjectionExample(ignite);
            }
            finally {
                // Undeploy all services.
                ignite.services().cancelAll();
            }
        }
    }

    /**
     * Simple example to demonstrate service proxy invocation of a remotely deployed service.
     *
     * @param ignite Ignite instance.
     * @throws Exception If failed.
     */
    private static void serviceProxyExample(Ignite ignite) throws Exception {
        System.out.println(">>>");
        System.out.println(">>> Starting service proxy example.");
        System.out.println(">>>");
        // Get a sticky proxy for node-singleton map service.
        SimpleMapService mapSvc = ignite.services().serviceProxy("myNodeSingletonService",SimpleMapService.class,true);
        List<List<?>> persons = mapSvc.getAllPerson();
        persons.stream().forEach(columns -> {
    	    System.out.println(">>>>>>>>>Person name = " + columns);
    	});  

    }

    /**
     * Simple example to demonstrate how to inject service proxy into distributed closures.
     *
     * @param ignite Ignite instance.
     * @throws Exception If failed.
     */
    private static void serviceInjectionExample(Ignite ignite) throws Exception {
        System.out.println(">>>");
        System.out.println(">>> Starting service injection example.");
        System.out.println(">>>");

        // Get a sticky proxy for cluster-singleton map service.
        SimpleMapService mapSvc = ignite.services().serviceProxy("myClusterSingletonService", SimpleMapService.class, true);
        List<List<?>> persons = mapSvc.getAllPerson();
        persons.stream().forEach(columns -> {
    	    System.out.println(">>>>>>>>>Person name = " + columns);
    	});  
        
        List<List<?>> joinResult = mapSvc.getCities("1,2");
        joinResult.stream().forEach(columns -> {
    	    System.out.println(">>>>>>>>>joinResult = " + columns);
    	});       
        
        // Broadcast closure to every node.
        final Collection<List<List<?>>> results = ignite.compute().broadcast(new SimpleClosure());
        System.out.println("Closure execution result: " + results);

    }

    /**
     * Simple closure to demonstrate auto-injection of the service proxy.
     */
    private static class SimpleClosure implements IgniteCallable<List<List<?>>> {
        // Auto-inject service proxy.
        @ServiceResource(serviceName = "myClusterSingletonService", proxyInterface = SimpleMapService.class)
        private transient SimpleMapService mapSvc;
        /** {@inheritDoc} */
        @Override public List<List<?>> call() throws Exception {
            List<List<?>> persons = mapSvc.getAllPerson();
            persons.stream().forEach(columns -> {
        	    System.out.println(">>>>>>>>>!!!Person name = " + columns);
        	});  
        	return persons;
        }
    }

}
