package sample.igite;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.FieldsQueryCursor;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.cluster.ClusterState;
import org.apache.ignite.configuration.ClientConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpDiscoveryMulticastIpFinder;

public class HelloWorld {
    public static void main(String[] args) throws IgniteException {
    	DataInitializer.init();
    	
        // Preparing IgniteConfiguration using Java APIs
        IgniteConfiguration cfg = new IgniteConfiguration();
        // The node will be started as a client node.
        cfg.setClientMode(true);
        // Classes of custom Java logic will be transferred over the wire from this app.
        cfg.setPeerClassLoadingEnabled(true);
        // Setting up an IP Finder to ensure the client can locate the servers.
        TcpDiscoveryMulticastIpFinder ipFinder = new TcpDiscoveryMulticastIpFinder();
        ipFinder.setAddresses(Collections.singletonList("127.0.0.1:47500..47509"));
        cfg.setDiscoverySpi(new TcpDiscoverySpi().setIpFinder(ipFinder));
        // Starting the node
        Ignite ignite = Ignition.start(cfg);
        ignite.cluster().state(ClusterState.ACTIVE);

        // Create an IgniteCache and put some values in it.
        IgniteCache<Integer, String> cache = ignite.getOrCreateCache("myCache");
        cache.put(1, "Hello");
        cache.put(2, "World!");
        
        //Map<Integer, String> data = IntStream.rangeClosed(3, 100).boxed()
        //        .collect(Collectors.toMap(i -> i, Object::toString));

        //cache.putAll(data);

        System.out.println(">> Created the cache and add the values.");

        // Executing custom Java compute task on server nodes.
        ignite.compute(ignite.cluster().forServers()).broadcast(new RemoteTask());

        System.out.println(">> Compute task is executed, check for output on the server nodes.");

        // Disconnect from the cluster.
        ignite.close();

    }
    

    /**
     * A compute tasks that prints out a node ID and some details about its OS and JRE.
     * Plus, the code shows how to access data stored in a cache from the compute task.
     */
    private static class RemoteTask implements IgniteRunnable {
        @IgniteInstanceResource
        Ignite ignite;

        @Override public void run() {
            System.out.println(">> Executing the compute task");

            System.out.println(
                "   Node ID: " + ignite.cluster().localNode().id() + "\n" +
                "   OS: " + System.getProperty("os.name") +
                "   JRE: " + System.getProperty("java.runtime.name"));

            IgniteCache<Object, Object> cache1 = ignite.cache("myCache");

            IntStream.rangeClosed(1, 2).boxed().forEach(i->System.out.println(">> " + cache1.get(i)));
            
            IgniteCache<Long, Person> cache2 = ignite.cache("SQL_PUBLIC_PERSON");

            SqlFieldsQuery sql = new SqlFieldsQuery("select * from Person").setSchema("PUBLIC");

            // Iterate over the result set.
            try (QueryCursor<List<?>> cursor = cache2.query(sql)) {
                for (List<?> row : cursor)
                    System.out.println("personName=" + row.get(1));
            }
            
            
            FieldsQueryCursor<List<?>> cursor = cache2.query(new SqlFieldsQuery("SELECT * from Person").setSchema("PUBLIC"));

        	// Get the results; the `getAll()` methods closes the cursor; you do not have to
        	// call cursor.close();
        	List<List<?>> results = cursor.getAll();

        	results.stream().findFirst().ifPresent(columns -> {
        	    System.out.println("name = " + columns);
        	});    	
        }
    }
}