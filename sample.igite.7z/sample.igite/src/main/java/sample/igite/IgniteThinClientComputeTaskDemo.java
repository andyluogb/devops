package sample.igite;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.client.ClientCompute;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.configuration.ClientConfiguration;
import org.apache.ignite.lang.IgniteCallable;

public class IgniteThinClientComputeTaskDemo {
    public static void main(String[] args) throws IgniteException {
    	//DataInitializer.init();
    	ClientConfiguration cfg = new ClientConfiguration().setAddresses("127.0.0.1:10800");
    	try (IgniteClient client = Ignition.startClient(cfg)) {    
    		ClientCompute compute = client.compute(client.cluster().forServers());

//    		Collection<List<List<?>>> joinResult = compute.execute(
//    				SimpleIgniteClosure.class.getName(), "1,2");
//        	joinResult.stream().forEach(result -> {
//        		result.forEach(columns->System.out.println(">>>>>>>>>joinResult = " + columns));
//        	}); 
        	
 
            System.out.println();
            System.out.println("Compute task split example started.");
            // Execute task on the cluster and wait for its completion.
        	List<List<?>> result = client.compute().execute(SimpleComputeTaskSplit.class.getName(), "1,2,3,4,5,6");
            System.out.println();
            result.forEach(columns->System.out.println(">>>>>>>>>closureResult = " + columns));
            System.out.println(">>> Check all nodes for output (this node is also part of the cluster).");
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    	}    	
    }
}