package sample.igite;

import java.util.List;

import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.configuration.ClientConfiguration;

public class IgniteThinClientServiceGridDemo {
    public static void main(String[] args) throws IgniteException {
    	//DataInitializer.init();
    	ClientConfiguration cfg = new ClientConfiguration().setAddresses("127.0.0.1:10800");
    	try (IgniteClient client = Ignition.startClient(cfg)) {    		
    		List<List<?>> joinResult = client.services().serviceProxy("myTestService", SimpleMapService.class).getCities("1,2,3,4");
            joinResult.stream().forEach(columns -> {
        	    System.out.println(">>>>>>>>>joinResult = " + columns);
        	});   
    	} catch (Exception e) {
    		e.printStackTrace();
    	}    	
    }
}