/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package sample.igite;

import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.FieldsQueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.ignite.services.Service;
import org.apache.ignite.services.ServiceContext;

/**
 * Simple service which utilizes Ignite cache as a mechanism to provide
 * distributed {@link SimpleMapService} functionality.
 */
public class SimpleMapServiceImpl implements Service, SimpleMapService {
    /** Serial version UID. */
    private static final long serialVersionUID = 0L;

    /** Ignite instance. */
    @IgniteInstanceResource
    private Ignite ignite;

    @Override public List<List<?>> getAllPerson() {
    	IgniteCache<Long, Person> cache2 = ignite.cache("SQL_PUBLIC_PERSON");
    	
    	FieldsQueryCursor<List<?>> cursor = cache2.query(new SqlFieldsQuery("SELECT * from Person").setSchema("PUBLIC"));

    	// Get the results; the `getAll()` methods closes the cursor; you do not have to
    	// call cursor.close();
    	List<List<?>> results = cursor.getAll();
    	
        return results;
    }

    @Override public List<List<?>> getCities(String ids) {
        CacheConfiguration<?, ?> cacheCfg = new CacheConfiguration<>("dummy_cache").setSqlSchema("PUBLIC");
        IgniteCache<?, ?> dummyCache = ignite.getOrCreateCache(cacheCfg);
        List<List<?>> joinResult = dummyCache.query(new SqlFieldsQuery(
                "SELECT * FROM city a join country b ON a.COUNTRYCODE = b.CODE JOIN PUBLIC.COUNTRYLANGUAGE c ON b.CODE = c.countrycode WHERE a.ID IN (" + ids + ")")).getAll();
        System.out.println("Service getCities: " + joinResult.size());
        return joinResult;
    }

    /** {@inheritDoc} */
    @Override public void cancel(ServiceContext ctx) {
        }

    /** {@inheritDoc} */
    @Override public void init(ServiceContext ctx) throws Exception {
        System.out.println("!!Service was initialized: " + ctx.name());
    }

    /** {@inheritDoc} */
    @Override public void execute(ServiceContext ctx) throws Exception {
        System.out.println("!!Executing distributed service: " + ctx.name());
    }
}
