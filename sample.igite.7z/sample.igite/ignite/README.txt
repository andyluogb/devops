This is Apache Ignite working directory that contains information that 
    Ignite nodes need in order to function normally.
Don't delete it unless you're sure you know what you're doing.

You can change the location of working directory with 
    igniteConfiguration.setWorkingDirectory(location) or 
    <property name="workingDirectory" value="location"/> in IgniteConfiguration <bean>.
