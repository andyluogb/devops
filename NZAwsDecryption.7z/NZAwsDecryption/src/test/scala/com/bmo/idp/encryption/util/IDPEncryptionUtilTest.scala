package com.bmo.idp.encryption.util

import java.security.PublicKey
import java.util.Base64

import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.Cipher
import javax.crypto.spec.{IvParameterSpec, SecretKeySpec}

object IDPEncryptionUtilTest extends NZLogger {
  private val Algorithm = "AES/CBC/PKCS5Padding"
  private val Key = new SecretKeySpec(Base64.getDecoder.decode("DxVnlUlQSu3E5acRu7HPwg=="), "AES")
  private val IvSpec = new IvParameterSpec(new Array[Byte](16))

  val AdminKey = "Dx$V!nl%Ul^QS&u3*E5@acR-u7HPwg=="

  def main(args: Array[String]) = {
    testCreateKeyAndEncrypt
  }


  def encrypt(text: String): String = {
    val cipher = Cipher.getInstance(Algorithm)
    cipher.init(Cipher.ENCRYPT_MODE, Key, IvSpec)

    new String(Base64.getEncoder.encode(cipher.doFinal(text.getBytes("utf-8"))), "utf-8")
  }

  def decrypt(text: String): String = {
    val cipher = Cipher.getInstance(Algorithm)
    cipher.init(Cipher.DECRYPT_MODE, Key, IvSpec)

    new String(cipher.doFinal(Base64.getDecoder.decode(text.getBytes("utf-8"))), "utf-8")
  }

  def testCreateKeyAndEncrypt = {
    val publicKey:String = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuor8i/Two/GdvUF2Q54AGhjHu+VHMmEd8Z0vjgqpI3pshr74s99wyeiyEObd06rl+lilmBMox9tT3w5RGb+wz7AqQvSEJH4ruc2/+//54rvcGczD0ZMGhLec1H8SYCbOCOruIMulwJiS6w65NvEoeqrRlugsMvNQWZwjnF9pKI0MZyBn11D+xJmrHFBlb1RbdXvpx0GG8UXMRQA/5BHzTtpt5iNgR3cWaHoAQQ+NEaPGxSSkuQbKJoX67XxLuGGEVdnE3kiXkhPSlkNJmgsXYhHaGUxyF5Fu+7SSsfGBs87jYoeAZwIIuJe7/gxsPIsH+7IEaMZ5AslqCHmiAZnO2QIDAQAB\n-----END PUBLIC KEY-----"
    val pk:PublicKey = RSAUtil.getPublicKeyFromString(publicKey)
    val (a,b) = createDataKey(pk)
    logger.info(s"dataKey:$a")
    logger.info(s"cipherKey:$b")
    val c = AES256Util.encrypt("ABCD", a)
    logger.info(s"cipherText:$c")
    val d = AES256Util.decrypt(c, a)
    logger.info(s"clearText:$d")
  }

  def createDataKey(pk:PublicKey):(String, String) = {
    val securedKey:Array[Byte] = SecretKeyGenerator.genSecuredKey256ByteArray
    val cipherSecuredKey = RSAUtil.rsaSha256Encrypt(pk, securedKey)
    (Base64.getEncoder.encodeToString(securedKey),  Base64.getEncoder.encodeToString(cipherSecuredKey))
  }
}
