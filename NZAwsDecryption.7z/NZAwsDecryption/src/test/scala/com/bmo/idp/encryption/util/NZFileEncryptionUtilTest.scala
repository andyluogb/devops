package com.bmo.idp.encryption.util

import com.bmo.idp.encryption.logger.NZLogger

object NZFileEncryptionUtilTest  extends NZLogger {
  def main(args: Array[String]) = {
    testRSAUtil
  }

  def testRSAUtil={
    RSAUtil.testRsa
    RSAUtil.testRsaLength("1234556")
  }

  def testRSACipher2048 = {
    val l = RSACipher2048
    l.test
  }
}
