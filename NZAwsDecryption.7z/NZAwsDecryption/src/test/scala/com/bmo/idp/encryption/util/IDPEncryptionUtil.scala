package com.bmo.idp.encryption.util

import java.io.{FileInputStream, FileOutputStream}
import java.util.{Base64, Collections}

import com.amazonaws.encryptionsdk.jce.JceMasterKey
import com.amazonaws.encryptionsdk.{AwsCrypto, CryptoInputStream}
import com.amazonaws.util.IOUtils
import com.bmo.idp.encryption.logger.NZLogger
import javax.crypto.spec.{IvParameterSpec, SecretKeySpec}
import javax.crypto.{Cipher, SecretKey}

object IDPEncryptionUtil extends NZLogger {
  private val Algorithm = "AES/CBC/PKCS5Padding"
  private val Key = new SecretKeySpec(Base64.getDecoder.decode("DxVnlUlQSu3E5acRu7HPwg=="), "AES")
  private val IvSpec = new IvParameterSpec(new Array[Byte](16))

  val AdminKey = "Dx$V!nl%Ul^QS&u3*E5@acR-u7HPwg=="

  def encrypt(text: String): String = {
    val cipher = Cipher.getInstance(Algorithm)
    cipher.init(Cipher.ENCRYPT_MODE, Key, IvSpec)

    new String(Base64.getEncoder.encode(cipher.doFinal(text.getBytes("utf-8"))), "utf-8")
  }

  def decrypt(text: String): String = {
    val cipher = Cipher.getInstance(Algorithm)
    cipher.init(Cipher.DECRYPT_MODE, Key, IvSpec)

    new String(cipher.doFinal(Base64.getDecoder.decode(text.getBytes("utf-8"))), "utf-8")
  }

  def encryptFileStreaming(srcFile : String): Unit  = {

    val cryptoKey : SecretKey  = SecretKeyGenerator.genEncryptionKey128

    // Create a JCE master key provider using the random key and an AES-GCM encryption algorithm
    val masterKey : JceMasterKey  = JceMasterKey.getInstance(cryptoKey, "Example", "RandomKey", "AES/GCM/NoPadding")

    // Instantiate the SDK
    val crypto : AwsCrypto = new AwsCrypto

    // Create an encryption context to identify this ciphertext
    val context = Collections.singletonMap("Example", "FileStreaming")

    // Because the file might be too large to load into memory, we stream the data, instead of
    //loading it all at once.
    var in : FileInputStream = new FileInputStream(srcFile)
    val encryptingStream : CryptoInputStream[JceMasterKey] = crypto.createEncryptingStream(masterKey, in, context)

    var out:FileOutputStream = new FileOutputStream(srcFile + ".encrypted")
    IOUtils.copy(encryptingStream, out)
    encryptingStream.close()
    out.close()

    // Decrypt the file. Verify the encryption context before returning the plaintext.
    in = new FileInputStream(srcFile + ".encrypted")
    val decryptingStream = crypto.createDecryptingStream(masterKey, in)
    // Does it contain the expected encryption context?
    if (!("FileStreaming" == decryptingStream.getCryptoResult.getEncryptionContext.get("Example"))) throw new IllegalStateException("Bad encryption context")

    // Return the plaintext data
    out = new FileOutputStream(srcFile + ".decrypted")
    IOUtils.copy(decryptingStream, out)
    decryptingStream.close()
  }

}
