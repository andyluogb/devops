package com.bmo.idp.encryption.util

import com.amazonaws.encryptionsdk.kms.{KmsMasterKey, KmsMasterKeyProvider}
import com.amazonaws.encryptionsdk.{AwsCrypto, CryptoResult}
import com.bmo.idp.encryption.logger.NZLogger

object FileStreamingExample  extends NZLogger {

  def main(args:Array[String]) = {
    var keyArn = "arn:aws:kms:us-east-2:534454167231:key/6141e9b4-875a-4873-879d-2b90bb37ba53"
    var data = "asasdasdas"

    // Instantiate the SDK
    var crypto : AwsCrypto = new AwsCrypto()

    // Set up the KmsMasterKeyProvider backed by the default credentials
    var prov : KmsMasterKeyProvider = KmsMasterKeyProvider.builder().withKeysForEncryption(keyArn).build()

    // Encrypt the data
    //
    // Most encrypted data should have an associated encryption context
    // to protect integrity. This sample uses placeholder values.
    //
    // For more information see:
    // blogs.aws.amazon.com/security/post/Tx2LZ6WBJJANTNW/How-to-Protect-the-Integrity-of-Your-Encrypted-Data-by-Using-AWS-Key-Management
    //var context:java.util.Map[String, String] = Collections.singletonMap("Example", "String")

    val ciphertext:String = crypto.encryptString(prov, data).getResult()
    logger.info("Ciphertext: " + ciphertext)

    // Decrypt the data
    var decryptResult: CryptoResult[String, KmsMasterKey] = crypto.decryptString(prov, ciphertext);

    // Before returning the plaintext, verify that the customer master key that
    // was used in the encryption operation was the one supplied to the master key provider.
    if (!decryptResult.getMasterKeyIds().get(0).equals(keyArn)) {
      throw new IllegalStateException("Wrong key ID!");
    }

    // Also, verify that the encryption context in the result contains the
    // encryption context supplied to the encryptString method. Because the
    // SDK can add values to the encryption context, don't require that
    // the entire context matches.
    //for ((a,b) <- context.asScala.toList)  {
    //   if (!b.equals(decryptResult.getEncryptionContext().get(a))) {
    //     throw new IllegalStateException("Wrong Encryption Context!");
    //   }
    // }

    // Now we can return the plaintext data
    logger.info("Decrypted: " + decryptResult.getResult);


  }
}
