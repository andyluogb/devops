package com.bmo.idp.encryption.util

import java.nio.file.Paths

import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.{BackupDataFile, BackupFile, BackupFilesConfig}

object NZBackupFileUtilTest  extends NZLogger {
  def main(args: Array[String]) = {
    //testBackupFileUtil
    //testJson
    //testBackupFileEqual
    testPathNameMatched
    //testBuildBackupDataFileList
  }


  def testBackupFileUtil = {
    val rootFolder = "nz_backup"
    val dbName = "DB1"
    val dbTimeStamp = "2020-03-24-16-11-34"
    val bf : BackupFile = NZBackupFileUtil.buildBackupFiles(rootFolder, dbName, dbTimeStamp)
    bf.dbSequences.foreach(a=>logger.info(a))
  }

  def testJson = {
    import org.json4s._
    import org.json4s.native.JsonMethods._

    implicit val formats = DefaultFormats


    val js = """ {
  "root_backup":"input",
  "backupFiles":[
    {
      "dbName": ["DB1"],
      "timestamp": ["2020-04-31"],
      "sequence": ["0001"],
      "backupType": ["backup-delete"],
      "dataFileName": ["table1-001","table2-002"]
    },
    {
      "dbName": ["DB2", "DB3"],
      "timestamp": ["2020-04-31"]
    }
  ]
}"""


    val page:BackupFilesConfig = parse(js).extract[BackupFilesConfig]

    logger.info(s"key4(1).submey1 --- ${page.backupFiles(1).dbName}")

  }

  def testBuildBackupDataFileList = {
    val backupFilesConfig : BackupFilesConfig = NZBackupFileUtil.getBackupFilesConfig("src/main/resources/encrypt_files.json")
    val (a,b) =NZBackupFileUtil.buildBackupDataFileList(backupFilesConfig)
    b.foreach(logger.info(_))
  }

  def testBackupFileEqual = {
    val f1 = BackupDataFile("1", "1", "1", "1", "1", "1", "1")
    val f2 = BackupDataFile("1", "1", "1", "1", "1", "1", "11")
    logger.info(f1==f2)
  }

  def testPathNameMatched = {
    val path = Paths.get("thePath1")
    val dbNames = List("!thePath*", "th*")
    val matched = NZBackupFileUtil.pathNameMatched(path, dbNames)
    logger.info(matched)
  }

}
