package com.bmo.idp.encryption.util

import com.bmo.idp.encryption.logger.NZLogger

object S3Example extends NZLogger {
  val bucketName = "gblsoft"

  def main(args:Array[String]): Unit = {
    //testS3()
    //testSSM()
    //testS3List()
    //testDeleteS3Objects()
    //testS3List()
    //testS3CopyStream
    testPath
  }

  def testS3() = {
    logger.info("=====Sample S3")
    val currentDirectory = new java.io.File(".").getCanonicalPath
    logger.info("=====Scurrent:" + currentDirectory)

    var result = IDPS3Client.uploadFile(bucketName, "./observation.json", true)
    logger.info("=====put:" + result)

    IDPS3Client.listObjects(bucketName)

    result = IDPS3Client.download(bucketName, "observation.json")
    logger.info("=====download:" + result)
  }

  def testSSM() = {
    val value = IDPSSMParamClient.getParameter("idpDataKey", true)
    logger.info(s"idpDataKey value is : $value")
  }

  def testS3List() = {
    val objects = IDPS3Client.listObjects(bucketName)
    for (os <- objects) {
      logger.info("* " + os.getKey)
    }

    val objectsHive = IDPS3Client.listObjects(bucketName, "hive")
    for (os <- objectsHive) {
      logger.info("* " + os.getKey)
    }
  }

  def testDeleteS3Objects(): Unit = {
    IDPS3Client.deleteObjectUnderFolder(bucketName, "hive")
  }

  def testS3CopyStream(): Unit = {
    val (meta, s3is) = IDPS3Client.getS3ObjectInputStream(bucketName, "encryption/table.csv")
    val (meta1, dataKey) = IDPS3Client.getS3ObjectInputStream(bucketName, "encryption/key.bin")
    val dataKeyBytes = NZFileUtil.toByteArray(dataKey)
    val cipher = AES256Util.createDecryptedCipher(dataKeyBytes)
    val s3isw = AES256Util.wrapInputStream(s3is, cipher)
    IDPS3Client.copyS3ObjectInputStreamMultipart(s3isw, bucketName, "decryption/table.csv", false, meta.getContentLength)
    System.exit(0)
    //s3.downloadToFile(s3isw, "table2.csv")
  }

  def testPath() ={
    var s="/asd/aaa/bbb/"
    logger.info(IDPS3Client.getS3PathParent(s)) //"asd/aaa"
    logger.info(IDPS3Client.getS3PathFileName(s)) //"bbb"
    s="asd/aaa/bbb"
    logger.info(IDPS3Client.getS3PathParent(s)) //"asd/aaa"
    logger.info(IDPS3Client.getS3PathFileName(s)) //"bbb"

    logger.info(IDPS3Client.makeS3Path("/aaa/bbb/", "/ccc/")) //"aaa/bbb/ccc"

  }
}
