package com.bmo.idp.encryption.config

import java.io.File

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.log4j.Logger

object NZConfig {
  val logger = Logger.getLogger(getClass.getName)
  var applicationConf: Config = _
  var runMode = "local"
  var localProjectDir = ""

  /**
   * Parse a config object from application.conf file in src/main/resources
   * @param args
   * @return
   */
  def parseArgs(args:Array[String]) = {
    if (args==null || args.length < 1) {
      logger.error("There is no configuration specified in the command line. Please user application argument like: <application.conf path> ...")
      System.exit(-1)
    }
    parseConfigFile(args(0))
  }

  def getBackupFilesArgs(args: Array[String]):(String, String) = {
    if (args==null || args.length < 3 ) {
      logger.error("There is no NZBackup files folder specified in the command line. Please user application argument like: <application.conf path> <NZ backup DB name> <NZ backup DB timestamp>")
      System.exit(-1)
    }
    (args(1), args(2))
  }

  def getSingleFileArgs(args: Array[String]):(String, String) = {
    if (args==null || args.length < 3 ) {
      logger.error("There is no source and target file paths specified in the command line. Please user application argument like: <application.conf path> <source file full path> <target file full path>")
      System.exit(-1)
    }
    (args(1), args(2))
  }

  def isSourceS3Bucket(args: Array[String]): (Boolean, String) = {
    if (args!=null && args.length > 4 ) {
       return (args(3)=="s3", args(4))
    }
    (false, null)
  }

  /**
   * Parse a config object from application.conf file in src/main/resources
   * @param configFile
   * @return
   */
  def parseConfigFile(configFile: String) = {
    if(configFile==runMode) {
      defaultSettiing
    } else {
      applicationConf = ConfigFactory.parseFile(new File(configFile))
      runMode = applicationConf.getString("config.mode")
      loadConfig()
    }
  }

  def loadConfig() = {
    NZFileEncryptConfig.load()
  }

  def defaultSettiing() = {
    NZFileEncryptConfig.defaultSettng()
  }
}

object NZFileEncryptConfig {

  val logger:Logger = Logger.getLogger(getClass.getName)

  var PUB_KEY_FOLDER:String = _
  var privateKeyFileName:String = _

  var INPUT:String = _
  var OUTPUT:String = _

  var privateKeyArn:String = _
  var privateKeyOfKey:String = _
  var region:String = _

  val MD_FOLDER:String = "md"
  val DATA_FOLDER:String = "data"
  val DATA_ENC_FOLDER:String = "data_enc"
  val DATA_DEC_FOLDER:String = "data_dec"
  val LOG_FOLDER:String = "log"

  val END_BIN:String = ".bin"
  val END_DONE:String = ".done"
  val END_FAIL:String = ".fail"
  val DATA_KEY_FOLDER:String = "key"
  val encDoneName:String ="encryption.done"
  val decDoneName:String ="decryption.done"
  val encFailName:String ="encryption.fail"
  val decFailName:String ="decryption.fail"
  val cipherKeyFileName:String ="key_cipher.bin"

  /*Configuration setting are loaded from application.conf when you run Spark Standalone cluster*/
  def load() = {
    logger.info("Loading NZ File encryption settings")
    INPUT = NZConfig.applicationConf.getString("config.encryption.INPUT")
    OUTPUT = NZConfig.applicationConf.getString("config.encryption.OUTPUT")
    privateKeyArn = NZConfig.applicationConf.getString("config.encryption.privateKeyArn")
    privateKeyOfKey = NZConfig.applicationConf.getString("config.encryption.privateKeyOfKey")
    region = NZConfig.applicationConf.getString("config.encryption.region")
  }

  /* Default Settings will be used when you run the project from Intellij */
  def defaultSettng() = {
    INPUT = "input_enc"
    OUTPUT = "output_dec"

    PUB_KEY_FOLDER = "key"
    privateKeyFileName ="nz_file_private.pem"

  }
}


