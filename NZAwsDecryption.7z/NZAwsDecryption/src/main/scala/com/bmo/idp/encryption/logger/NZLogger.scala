package com.bmo.idp.encryption.logger

import org.apache.log4j.Logger

trait NZLogger {
  val logger = Logger.getLogger(getClass.getName)
}
