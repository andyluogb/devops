package com.bmo.idp.encryption.util

import java.nio.file.{Files, Path, Paths}

import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model._

object NZBackupFileUtil  extends NZLogger {
  val nzFileUtil = NZFileUtil

  def getBackupFilesConfigs(args: Array[String]):BackupFilesConfig = {
    if (args==null || args.length < 2 ) {
      logger.error("There is no nz backup files json file specified in the command. Please user application argument like: <application.conf path> <decrypt_files.json path>")
      System.exit(-1)
    }
    val backupFilesConfig : BackupFilesConfig = getBackupFilesConfig(args(1))
    backupFilesConfig
  }

  def buildBackupFiles(inputRootFolderName: String, dbName: String, timestampName: String): BackupFile = {
    val backupFile = BackupFile(dbName, timestampName, buildBackupDBSequence(inputRootFolderName, dbName, timestampName))
    backupFile
  }

  def buildBackupDBSequence(inputRootFolderName: String, dbName: String, timestampName: String): List[BackupDBSequence] = {
    val dbPathByTime: Path = Paths.get(inputRootFolderName, dbName, timestampName)
    val dbSequences: List[Path] = nzFileUtil.listFolders(dbPathByTime)
    val dbSequence: List[BackupDBSequence] = dbSequences.map(f => BackupDBSequence(dbName, timestampName, f.getFileName.toString,
      buildBackupTypes(inputRootFolderName, dbName, timestampName, f.getFileName.toString)))
    dbSequence
  }

  def buildBackupTypes(inputRootFolderName: String, dbName: String, timestampName: String, dbSequenceName: String): List[BackupType] = {
    val dbSequencePath: Path = Paths.get(inputRootFolderName, dbName, timestampName, dbSequenceName)
    val dbBackupTypePaths: List[Path] = nzFileUtil.listFolders(dbSequencePath)
    val dbBackupTypes: List[BackupType] = dbBackupTypePaths.map(f => BackupType(dbName, timestampName, dbSequenceName, f.getFileName.toString))
    dbBackupTypes
  }

  def createBackupTypeFolderOnOutput(backupType: BackupType, outputRoot:String, fromEncryption: Boolean):Unit = {
    //create folders
    val outputDBPath = Paths.get(outputRoot, backupType.dbName)
    if (Files.notExists(outputDBPath)) {
      Files.createDirectory(outputDBPath)
    }
    val outputDBTimestampPath = Paths.get(outputDBPath.toAbsolutePath.toString, backupType.timestampName)
    if (Files.notExists(outputDBTimestampPath)) {
      Files.createDirectory(outputDBTimestampPath)
    }
    val outputDBSequencePath = Paths.get(outputDBTimestampPath.toAbsolutePath.toString, backupType.dbSequenceName)
    if (Files.notExists(outputDBSequencePath)) {
      Files.createDirectory(outputDBSequencePath)
    }
    val outputDBBackupTypePath = Paths.get(outputDBSequencePath.toAbsolutePath.toString, backupType.backupTypeName)
    if (Files.notExists(outputDBBackupTypePath)) {
      Files.createDirectory(outputDBBackupTypePath)
    }
    val outputMDPath = Paths.get(outputDBBackupTypePath.toAbsolutePath.toString, NZFileEncryptConfig.MD_FOLDER)
    if (Files.notExists(outputMDPath)) {
      Files.createDirectory(outputMDPath)
    }
    val outputDataPath = Paths.get(outputDBBackupTypePath.toAbsolutePath.toString, NZFileEncryptConfig.DATA_FOLDER)
    if (Files.notExists(outputDataPath)) {
      Files.createDirectory(outputDataPath)
    }

    if (fromEncryption) {
      val outputKeyPath = Paths.get(outputDBBackupTypePath.toAbsolutePath.toString, NZFileEncryptConfig.DATA_KEY_FOLDER)
      if (Files.notExists(outputKeyPath)) {
        Files.createDirectory(outputKeyPath)
      }
    }

    val outputLogPath = Paths.get(outputDBBackupTypePath.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER)
    if (Files.notExists(outputLogPath)) {
      Files.createDirectory(outputLogPath)
    }

    //NZFileUtil.deleteFilesUnderFolder(outputMDPath)
    //NZFileUtil.deleteFilesUnderFolder(outputDataPath)
    //NZFileUtil.deleteFilesUnderFolder(outputKeyPath)
    //NZFileUtil.deleteFilesUnderFolder(outputLogPath)
  }


  def getBackupFilesConfig(jsFileName:String): BackupFilesConfig = {
    import org.json4s._
    import org.json4s.native.JsonMethods._
    implicit val formats = DefaultFormats
    val js = NZFileUtil.readFileAsString(jsFileName)
    val backupFilesConfig:BackupFilesConfig = parse(js).extract[BackupFilesConfig]
    backupFilesConfig
  }

  def buildBackupDataFileList(backupFilesConfig:BackupFilesConfig): (List[Path], List[BackupDataFile]) = {
    val rootPath:List[Path] = List(Paths.get(backupFilesConfig.root_input))
    val backupFiles:List[BackupFileListConfig] = backupFilesConfig.backupFiles

    var dbAllDataFilePaths:List[Path] = List[Path]()

    for (backupFile <- backupFiles) {
      //dbNames
      val dbNames: List[String] = backupFile.dbName
      val dbPaths:List[Path] =getPathsFilterByNames(dbNames, rootPath)

      //timestamps
      val dbTimestamps: List[String] = backupFile.timestamp
      val dbTimestampPaths:List[Path] = getPathsFilterByNames(dbTimestamps, dbPaths)

      //sequences
      val dbSequences: List[String] = backupFile.sequence
      val dbSequencePaths:List[Path] = getPathsFilterByNames(dbSequences, dbTimestampPaths)

      //backup Types
      val dbBackupTypes: List[String] = backupFile.backupType
      val dbBackupTypePaths:List[Path] = getPathsFilterByNames(dbBackupTypes, dbSequencePaths)

      //data folders
      val dbDataFolders: List[String] = backupFile.dataFolder
      val dbDataFolderPaths:List[Path] = getPathsFilterByNames(dbDataFolders, dbBackupTypePaths)

      //DataFiles
      val dbDataFiles: List[String] = backupFile.dataFileName
      var dbDataFilePaths:List[Path] = getFilesFilterByNames(dbDataFiles, dbDataFolderPaths)

      dbAllDataFilePaths ++= dbDataFilePaths
    }

    dbAllDataFilePaths = dbAllDataFilePaths.distinct

    (dbAllDataFilePaths, dbAllDataFilePaths.map(f=>convertDataPathToDataFile(f)))

  }

  def checkOutputDirectoryTreeCreated(backupData:BackupDataFile, outputRootFolder:String) = {
    val outputDBPath: Path = Paths.get(outputRootFolder, backupData.dbName)
    NZFileUtil.createDirectory(outputDBPath)
    val outputTimestampPath: Path = Paths.get(outputDBPath.toAbsolutePath.toString, backupData.timestampName)
    NZFileUtil.createDirectory(outputTimestampPath)
    val outputSequencePath: Path = Paths.get(outputTimestampPath.toAbsolutePath.toString, backupData.dbSequenceName)
    NZFileUtil.createDirectory(outputSequencePath)
    val outputBackupTypePath: Path = Paths.get(outputSequencePath.toAbsolutePath.toString, backupData.backupTypeName)
    NZFileUtil.createDirectory(outputBackupTypePath)
    val outputDataPath: Path = Paths.get(outputBackupTypePath.toAbsolutePath.toString, backupData.dataFolder)
    NZFileUtil.createDirectory(outputDataPath)
    val outputLogPath: Path = Paths.get(outputBackupTypePath.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER)
    NZFileUtil.createDirectory(outputLogPath)

    val outputDataFilePath: Path = Paths.get(outputDataPath.toAbsolutePath.toString, backupData.dataFileName)
    Files.deleteIfExists(outputDataFilePath)
    val outputEncDoneLogPath: Path = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName+"."+NZFileEncryptConfig.encDoneName)
    Files.deleteIfExists(outputEncDoneLogPath)
    val outputEncFailLogPath: Path = Paths.get(outputLogPath.toAbsolutePath.toString, backupData.dataFileName+"."+NZFileEncryptConfig.encFailName)
    Files.deleteIfExists(outputEncFailLogPath)
  }

  /**
   * copy MD Files
   */
  @throws[Exception]
  def copyMDFile(backupData:BackupDataFile, inputRootFolder:String, outputRootFolder:String):Unit = {
    val inputMDPath: Path = Paths.get(inputRootFolder, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)
    val outputMDPath: Path = Paths.get(outputRootFolder, backupData.dbName, backupData.timestampName,
      backupData.dbSequenceName, backupData.backupTypeName, backupData.dataFolder)

    if (!NZFileEncryptionUtil.isToExcludeEncDec(backupData)) {
      try {
        val inputFile = Paths.get(inputMDPath.toAbsolutePath.toString, backupData.dataFileName)
        val outputFile = Paths.get(outputMDPath.toAbsolutePath.toString, backupData.dataFileName)
        NZFileUtil.copyReplacePath(inputFile, outputFile)
        logger.info("MD files copied to:" + outputFile.toAbsolutePath.toString)
        //create md.done under output log folder
        val outputEncDonePath: Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
          backupData.dataFileName + "." + NZFileEncryptConfig.MD_FOLDER + NZFileEncryptConfig.END_DONE)
        NZFileUtil.deleteAndCreateFile(outputEncDonePath)
      } catch {
        case e:Exception => {
          logger.error(s"Failed to copy MD file:$backupData", e )
          val outputEncFailPath: Path = Paths.get(outputMDPath.getParent.toAbsolutePath.toString, NZFileEncryptConfig.LOG_FOLDER,
            backupData.dataFileName + "." + NZFileEncryptConfig.MD_FOLDER + NZFileEncryptConfig.END_FAIL)
          NZFileUtil.deleteAndCreateFile(outputEncFailPath)
        }
      }
    }
  }

  def convertDataPathToDataFile(dataFilePath:Path):BackupDataFile = {
    val dataPath = dataFilePath.getParent
    val backupTypePath = dataPath.getParent
    val sequencePath = backupTypePath.getParent
    val timestampPath = sequencePath.getParent
    val dbPath = timestampPath.getParent
    val rootPath = dbPath.getParent
    BackupDataFile(rootPath.getFileName.toString, dbPath.getFileName.toString, timestampPath.getFileName.toString,
      sequencePath.getFileName.toString, backupTypePath.getFileName.toString, dataPath.getFileName.toString, dataFilePath.getFileName.toString)
  }

  def getPathsFilterByNames(fileNames: List[String], path:List[Path]) = {
    var paths:List[Path] = NZFileUtil.listFoldersUnderFolders(path)
    var result: List[Path] = List[Path]()
    if (fileNames!=null && !fileNames.isEmpty) {
      result = paths.filter(p=>pathNameMatched(p, fileNames))
    } else {
      result = paths
    }
    result
  }

  def getFilesFilterByNames(fileNames: List[String], path:List[Path]) = {
    var paths:List[Path] = NZFileUtil.listFilesUnderFolders(path)
    var result: List[Path] = List[Path]()
    if (fileNames!=null && !fileNames.isEmpty) {
      result = paths.filter(p=>pathNameMatched(p, fileNames))
    } else {
      result = paths
    }
    result
  }

  def pathNameMatched(path:Path, dbNames: List[String]):Boolean={
    for (name<-dbNames) {
      val name1 = name.replace("*", ".*")
      if (path.getFileName.toString.matches(name1)) {
          return true
       }
    }
    false
  }

  def isMDFile(path:Path):Boolean = {
    path.getParent.getFileName == NZFileEncryptConfig.MD_FOLDER
  }
  def isMDFile(backupData:BackupDataFile):Boolean = {
    backupData.dataFolder == NZFileEncryptConfig.MD_FOLDER
  }

}
