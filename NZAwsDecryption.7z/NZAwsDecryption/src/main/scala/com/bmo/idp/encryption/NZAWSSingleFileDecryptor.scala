package com.bmo.idp.encryption

import java.nio.file.{Path, Paths}
import java.security.PrivateKey

import com.bmo.idp.encryption.config.{NZConfig, NZFileEncryptConfig}
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.util.{IDPS3Client, NZFileEncryptionUtil, NZFileUtil, RSAUtil}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

object NZAWSSingleFileDecryptor extends NZLogger {

  def main(args: Array[String]){
    //NZConfig.parseArgs("src/main/resources/application.conf")
    NZConfig.parseArgs(args)
    val (sourceFilePath, targetFilePath) = NZConfig.getSingleFileArgs(args)
    val (isSourceS3Bucket, bucketName) = NZConfig.isSourceS3Bucket(args)

    val spark = SparkSession.builder()
      .master("local[*]")
      .appName("NZAWSDecryptor")
      .getOrCreate()

    val privKey:PrivateKey = NZFileEncryptionUtil.getPrivateKeyFromAWSSecretManager
    val privKeyBroad:Broadcast[PrivateKey] = spark.sparkContext.broadcast(privKey)

    val rdd = spark.sparkContext.parallelize(List((sourceFilePath, targetFilePath)))
    if (!isSourceS3Bucket) {
      rdd.foreach(a => decryptAndCopyDataFile(privKeyBroad.value, a._1, a._2))
    } else {
      rdd.foreach(a => decryptAndCopyDataFileS3(privKeyBroad.value, a._1, a._2, bucketName))
    }


    spark.close()

  }

  def getDataKey(pk:PrivateKey, sourceFilePath:String):Array[Byte] = {
    val inputFile = Paths.get(sourceFilePath)
    val cipherDataKeyPath:Path = Paths.get(sourceFilePath).getParent
    val cipherSecuredKeyFile = Paths.get(cipherDataKeyPath.toAbsolutePath.toString, inputFile.getFileName.toString + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = NZFileUtil.readFileToBytes(cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  @throws[Exception]
  def decryptAndCopyDataFile(pk:PrivateKey, sourceFilePath:String, targetFilePath:String):Unit = {
    val inputFile = Paths.get(sourceFilePath)
    val outputFile = Paths.get(targetFilePath)
    try {
      val securedKey = getDataKey(pk, sourceFilePath)
        NZFileEncryptionUtil.decryptAndCopy(inputFile.toFile, outputFile.toFile, securedKey)
        logger.info("decrypted file: " + outputFile.toAbsolutePath.toString)
        val decDoneFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decDoneName)
        NZFileUtil.deleteAndCreateFile(decDoneFileOutput)
    } catch {
      case e: Exception =>
        logger.error(s"Something wrong when encrypting file ${}", e)
        val decFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
        NZFileUtil.deleteAndCreateFile(decFailFileOutput)
    }
  }

  def getDataKeyS3(pk:PrivateKey, sourceFilePath:String, s3Bucket:String):Array[Byte] = {
    val cipherDataKeyFolder:String = IDPS3Client.getS3PathParent(sourceFilePath)
    val fileName = IDPS3Client.getS3PathFileName(sourceFilePath)
    val cipherSecuredKeyFile = IDPS3Client.makeS3Path(cipherDataKeyFolder, fileName + "." + NZFileEncryptConfig.cipherKeyFileName)
    val cipherKey = IDPS3Client.getS3ObjectBytes(s3Bucket, cipherSecuredKeyFile)
    val securedKey = RSAUtil.rsaSha256Decrypt(pk, cipherKey)
    securedKey
  }

  @throws[Exception]
  def decryptAndCopyDataFileS3(pk:PrivateKey, sourceFilePath:String, targetFilePath:String, s3Bucket:String):Unit = {
    val outputFile = Paths.get(targetFilePath)
    try {
      val securedKey = getDataKeyS3(pk, sourceFilePath, s3Bucket)
      NZFileEncryptionUtil.decryptS3AndCopyFile(s3Bucket, sourceFilePath, outputFile.toFile, securedKey)
      logger.info("decrypted file: " + outputFile.toAbsolutePath.toString)
      val decDoneFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decDoneName)
      NZFileUtil.deleteAndCreateFile(decDoneFileOutput)
      val decFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
      NZFileUtil.deleteFile(decFailFileOutput)
    } catch {
      case e: Exception =>
        logger.error(s"Something wrong when encrypting file ${}", e)
        val decFailFileOutput = Paths.get(outputFile.getParent.toAbsolutePath.toString, outputFile.getFileName.toString + "." + NZFileEncryptConfig.decFailName)
        NZFileUtil.deleteAndCreateFile(decFailFileOutput)
    }
  }

}
