package com.bmo.idp.encryption.util

import java.io.{FileOutputStream, IOException}
import java.nio.channels.FileChannel

import com.bmo.idp.encryption.logger.NZLogger
import software.amazon.awssdk.auth.credentials.{AwsBasicCredentials, StaticCredentialsProvider}
import software.amazon.awssdk.core.SdkBytes
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.kms.KmsClient
import software.amazon.awssdk.services.kms.model.EncryptRequest

object IDPKMSClient extends NZLogger {

  val key = "AKIAXY37TM277PQRIZ4U"
  val secretKey = "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"
  val keyArn = "arn:aws:kms:us-east-2:534454167231:key/6141e9b4-875a-4873-879d-2b90bb37ba53"


  var awsCreds = AwsBasicCredentials.create(key, secretKey)
  lazy implicit val kmsClient = KmsClient.builder
    .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
    .region(Region.US_EAST_2).build



  def encrypt(jsonString: SdkBytes): SdkBytes = {
    val encryptRequest = EncryptRequest.builder.keyId(keyArn).plaintext(jsonString).build
    val encryptResponse = kmsClient.encrypt(encryptRequest)
    encryptResponse.ciphertextBlob
  }

  @throws[IOException]
  def writeToFile(bytesToWrite: SdkBytes, path: String): Unit = {
    val outputStream = new FileOutputStream(path)
    var fc: FileChannel = outputStream.getChannel
    fc.write(bytesToWrite.asByteBuffer)
    outputStream.close()
    fc.close()
  }


}
