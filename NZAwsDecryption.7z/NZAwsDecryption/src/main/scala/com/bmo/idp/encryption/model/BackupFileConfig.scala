package com.bmo.idp.encryption.model

case class BackupFileListConfig(dbName:List[String], timestamp:List[String], sequence:List[String], backupType:List[String], dataFolder:List[String], dataFileName:List[String])
case class BackupFilesConfig(root_input:String, root_output:String, backupFiles:List[BackupFileListConfig])
