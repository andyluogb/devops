package com.bmo.idp.encryption.util

import java.io._
import java.nio.file.Path
import java.security.PrivateKey
import java.time.{Duration, Instant}

import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.logger.NZLogger
import com.bmo.idp.encryption.model.BackupDataFile


object NZFileEncryptionUtil extends NZLogger{
  @throws[IOException]
  def encryptAndCopyRelatedFolder(inputFileName: String, outputFileName: String, ifolder: String, ofolder: String, securedKey: Array[Byte]): Unit = {
    val inputFile: File = NZFileUtil.getRelatedFile(inputFileName, ifolder)
    val outputFile: File = NZFileUtil.getRelatedFile(outputFileName, ofolder)
    encryptAndCopy(inputFile, outputFile, securedKey)
  }

  @throws[IOException]
  def encryptAndCopy(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createEncryptedCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val os = NZFileUtil.getOutputStream(outputFile)
    val wos = AES256Util.wrapOutputStream(os, cipher)
    try {
      NZFileUtil.copy(is, wos)
    } finally {
      if (is != null) is.close()
      if (wos != null) wos.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def decryptAndCopyRelatedFolder(inputFileName: String, outputFileName: String, ifolder: String, ofolder: String, securedKey: Array[Byte]): Unit = {
    val inputFile = NZFileUtil.getRelatedFile(inputFileName, ifolder)
    val outputFile = NZFileUtil.getRelatedFile(outputFileName, ofolder)
    decryptAndCopy(inputFile, outputFile, securedKey)
  }

  @throws[IOException]
  def decryptAndCopy(inputFile: File, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val is = NZFileUtil.getInputStream(inputFile)
    val wis = AES256Util.wrapInputStream(is, cipher)
    val os = NZFileUtil.getOutputStream(outputFile)
    try {
      NZFileUtil.copy(wis, os)
    } finally {
      if (wis != null) wis.close()
      if (os != null) os.close()
    }
    outputFile.setLastModified(inputFile.lastModified())
  }

  @throws[IOException]
  def decryptS3AndCopyFile(s3Bucket:String, inputFile: String, outputFile: File, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val is = IDPS3Client.getS3ObjectInputStream(s3Bucket, inputFile)
    val wis = AES256Util.wrapInputStream(is._2, cipher)
    val os = NZFileUtil.getOutputStream(outputFile)
    try {
      NZFileUtil.copy(wis, os)
    } finally {
      if (wis != null) wis.close()
      if (os != null) os.close()
    }
    outputFile.setLastModified(is._1.getLastModified.getTime)
  }

  def decryptS3AndCopyS3(s3Bucket:String, inputFile: String, outputFile: String, securedKey: Array[Byte]): Unit = {
    val cipher = AES256Util.createDecryptedCipher(securedKey)
    val s3is = IDPS3Client.getS3ObjectInputStream(s3Bucket, inputFile)
    val s3isw = AES256Util.wrapInputStream(s3is._2, cipher)
    IDPS3Client.copyS3ObjectInputStreamMultipart(s3isw, s3Bucket, outputFile, false, s3is._1.getContentLength)
  }

  def isToExcludeEncDec(file:Path):Boolean = {
    (file.getFileName.toString.endsWith(NZFileEncryptConfig.END_BIN)
      || file.getFileName.toString.endsWith(NZFileEncryptConfig.END_DONE)
      || file.getFileName.toString.endsWith(NZFileEncryptConfig.END_FAIL))
  }
  def isToExcludeEncDec(file:BackupDataFile):Boolean = {
    (file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_BIN)
      || file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_DONE)
      || file.dataFileName.toString.endsWith(NZFileEncryptConfig.END_FAIL))
  }

  def printConfigure() = {
    logger.info("bufferSize=%d; END_BIN=%s; encDoneName=%s\n".format(NZFileEncryptConfig.END_BIN, NZFileEncryptConfig.encDoneName))
  }

  def timeInvoke(callback: () => Unit) {
    var start = Instant.now
    callback()
    var finish = Instant.now
    var timeElapsed = Duration.between(start, finish).toMillis
    logger.info(" testEncryption timeElapsed:" + timeElapsed)
  }

  def jsonStrToMap(jsonStr: String): Map[String, Any] = {
    import org.json4s._
    import org.json4s.jackson.JsonMethods._

    implicit val formats = org.json4s.DefaultFormats
    val map = parse(jsonStr).extract[Map[String, Any]]
    map
  }

  def getPrivateKeyFromAWSSecretManager(): PrivateKey =  {
    val secret = IDPSecretsClient.getSecret(NZFileEncryptConfig.privateKeyArn)
    val map = NZFileEncryptionUtil.jsonStrToMap(secret)
    val privateKeyStr:String = map.get("privateKey").get.asInstanceOf[String]
    val privateKey:PrivateKey = RSAUtil.getPrivKeyFromStr(privateKeyStr)
    privateKey
  }

}