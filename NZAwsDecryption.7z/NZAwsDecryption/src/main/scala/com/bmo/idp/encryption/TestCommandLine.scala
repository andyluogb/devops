package com.bmo.idp.encryption

import org.apache.commons.cli.{CommandLine, DefaultParser, HelpFormatter, Option, Options, ParseException}

object TestCommandLine {
  def main(args:Array[String]):Unit = {
    val cmd : CommandLine = buildCommandLines(args)
    if (cmd.hasOption("v")) {
       println( "enable verbose mode..." )
    }
    if (cmd.hasOption("f")) {
      val path = cmd.getOptionValue("f")
      println(s"Option f value is $path, return null if the option does not exist in command line")
    }
    val e = cmd.getOptionValue("encoding", "utf-8")
    println(s"Option encoding value is $e, default value utf-8")
    val d = cmd.getOptionProperties("D")
    println(s"Option D property value is ${d.getProperty("a")}")
  }

  def buildCommandLines(args:Array[String]): CommandLine = {
    val options = new Options
    // Create an option with short name// Create an option with short name

    // "-v" for enabling the verbose mode.
    options.addOption("v", "Enable verbose mode")

    // Create an option with short name
    // "-f" for configuring filepath. It
    // has an argument (hasArg=true).
    options.addOption("f", true, "Config filepath")


    // "-i" or long name "--ignore", for
    // specifying the case-sensitive case.
    options.addOption("i", "ignore", false, "Ignore case")

    val opt = Option.builder("a").longOpt("all").desc("Display all").build
    options.addOption(opt)

     val property : Option =  Option.builder("D").argName( "property=value" )
      .numberOfArgs(2)
      .valueSeparator('=')
      .desc( "use value for given property" )
      .required(true)
      .build()
    options.addOption(property)

    val formatter = new HelpFormatter
    formatter.printHelp("cmd", options)
    val parser = new DefaultParser
    var cmd: CommandLine = null
    try {
      cmd = parser.parse(options, args)
    } catch  {
      case e: ParseException =>
          println(e.getMessage)
        throw e
    }
    cmd
  }

}
