package com.bmo.idp.encryption.util

import java.util.Base64

import com.amazonaws.auth.{AWSStaticCredentialsProvider, BasicSessionCredentials}
import com.amazonaws.services.secretsmanager.model.{GetSecretValueRequest, GetSecretValueResult}
import com.amazonaws.services.secretsmanager.{AWSSecretsManager, AWSSecretsManagerClientBuilder}
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest
import com.bmo.idp.encryption.config.NZFileEncryptConfig
import com.bmo.idp.encryption.logger.NZLogger

object IDPSecretsClient extends NZLogger {
  //val keyArn = "arn:aws:secretsmanager:us-east-2:534454167231:secret:lgbSecrets-yn9aab"
  //val secretName = "lgbSecrets"
  val region = NZFileEncryptConfig.region
  var roleArn:String = _
  var client: AWSSecretsManager = _
  val sessionName:String = "secretManagerSession"

  def initClient() = {
    if (roleArn==null) {
      client = AWSSecretsManagerClientBuilder.standard.withRegion(region).build
    } else {
      val assumeRole = new AssumeRoleRequest().withRoleArn(roleArn).withRoleSessionName(sessionName)
      val sts = AWSSecurityTokenServiceClientBuilder.standard.withRegion(region).build
      val credentials = sts.assumeRole(assumeRole).getCredentials
      val sessionCredentials = new BasicSessionCredentials(credentials.getAccessKeyId, credentials.getSecretAccessKey, credentials.getSessionToken)
      client = AWSSecretsManagerClientBuilder.standard.withRegion(region).withCredentials(new AWSStaticCredentialsProvider(sessionCredentials)).build
    }
  }
  // Use this code snippet in your app.// Use this code snippet in your app.

  // If you need more information about configurations or implementing the sample code, visit the AWS docs:
  // https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/java-dg-samples.html#prerequisites
  @throws[Exception]
  def getSecret(keyArn:String): String = {
    // Create a Secrets Manager client

    // In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    // See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    // We rethrow the exception by default.
    var secret : String = null
    val getSecretValueRequest : GetSecretValueRequest = new GetSecretValueRequest().withSecretId(keyArn)
    var secretValueResult : GetSecretValueResult = client.getSecretValue(getSecretValueRequest)
    // Decrypts secret using the associated KMS CMK.
    // Depending on whether the secret is a string or binary, one of these fields will be populated.
    if (secretValueResult.getSecretString != null) secret = secretValueResult.getSecretString
    else secret = new String(Base64.getDecoder.decode(secretValueResult.getSecretBinary).array)
    secret
  }

}
