package com.bmo.idp.encryption.util

import java.nio.ByteBuffer

import com.amazonaws.services.kms.model._
import com.amazonaws.services.kms.{AWSKMSAsync, AWSKMSAsyncClientBuilder}
import com.amazonaws.util.BinaryUtils
import com.bmo.idp.encryption.logger.NZLogger

object IDPKMSClient2 extends NZLogger {
  val keyArn = "arn:aws:kms:us-east-2:534454167231:key/1afff035-5cc5-4c66-9381-41bb1bc737a2" //asymmetric


  implicit val kmsClient: AWSKMSAsync = AWSKMSAsyncClientBuilder.defaultClient()

  def getPublicKey(): String  = {
    val req = new GetPublicKeyRequest().withKeyId(keyArn)
    val publicKeyResult : GetPublicKeyResult = kmsClient.getPublicKey(req)

    val pk: ByteBuffer = publicKeyResult.getPublicKey

    val bytes =  BinaryUtils.copyAllBytesFrom(pk)

    BinaryUtils.toBase64(bytes)

  }

  def encrypt(plainDataKey:String): String  = {

    val plainDataKeyBytes:Array[Byte] = BinaryUtils.fromBase64(plainDataKey)

    val plaintextBlob = ByteBuffer.wrap(plainDataKeyBytes)

    val req = new EncryptRequest().withKeyId(keyArn).withPlaintext(plaintextBlob).withEncryptionAlgorithm(EncryptionAlgorithmSpec.RSAES_OAEP_SHA_256)
    val ciphertextBlob = kmsClient.encrypt(req).getCiphertextBlob

    val cipherBytes = BinaryUtils.copyAllBytesFrom(ciphertextBlob)
    val ciphertext = BinaryUtils.toBase64(cipherBytes)
    ciphertext
  }

  def decrypt(cipherDataKey:String): String = {
   //val plaintext = ByteBuffer.wrap(plainTextStr.getBytes("UTF-8"))
    val cipherBytes:Array[Byte] = BinaryUtils.fromBase64(cipherDataKey)
    val cipherBlob:ByteBuffer = ByteBuffer.wrap(cipherBytes)

    val req = new DecryptRequest().withKeyId(keyArn).withCiphertextBlob(cipherBlob).withEncryptionAlgorithm(EncryptionAlgorithmSpec.RSAES_OAEP_SHA_256)
    val plainBlob: ByteBuffer = kmsClient.decrypt(req).getPlaintext
    val plainDataKey = BinaryUtils.copyAllBytesFrom(plainBlob)

    BinaryUtils.toBase64(plainDataKey)

  }


}
