package com.bmo.idp.encryption.util

import com.amazonaws.regions.Regions
import com.amazonaws.services.simplesystemsmanagement.model.GetParameterRequest
import com.amazonaws.services.simplesystemsmanagement.{AWSSimpleSystemsManagement, AWSSimpleSystemsManagementClientBuilder}
import com.bmo.idp.encryption.logger.NZLogger

object IDPSSMParamClient extends NZLogger {
  val ssmClient : AWSSimpleSystemsManagement = AWSSimpleSystemsManagementClientBuilder.standard.withRegion(Regions.US_EAST_2).build

  def getParameter(key : String, encryption:Boolean): String  = {
    val getparameterRequest = new GetParameterRequest().withName(key).withWithDecryption(encryption)
    val result = ssmClient.getParameter(getparameterRequest)
    result.getParameter.getValue
  }

}
