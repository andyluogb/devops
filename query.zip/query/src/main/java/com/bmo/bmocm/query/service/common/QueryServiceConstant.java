package com.bmo.bmocm.query.service.common;

public class QueryServiceConstant {
    public static String KEY_RESPONSE_STATISTIC_MAP = "statistic";
    public static String KEY_RESPONSE_TOTAL_COUNT = "totalCount";
    public static String KEY_RESPONSE_METADADA = "meta";
    public static String KEY_RESPONSE_FILE = "file";

    public static String KEY_QUERY_HEADER = "header";
    public static String KEY_STATUS = "status";
    public static String VALUE_STATUS_SUCCESS = "success";
    public static String KEY_ERRORS = "errors";
    public static String VALUE_STATUS_ERROR = "errors";
    public static String KEY_STATISTIC = "statistics";
    public static String KEY_DATA = "data";
    public static String KEY_APP_CODE = "appCode";
    public static String KEY_DOMAIN = "domain";
    public static String KEY_IP_ADDRESS = "ip";
    public static String KEY_USER_CODE = "userCode";

    public static String GZIP_FILE_EXT = "zip";
    public static String FILE_TYPE_JSON = "json";

    public static String ACTION_GET_DATA = "query";
    public static String ACTION_GET_COUNT = "count";
    public static String ACTION_REFRESH_META_DATA = "refresh";
    public static String ACTION_GET_DATA_FILE = "export";

    public static String KEY_SESSION_ID = "session";


    public static String DB_TYPE_MEMSQL = "MemSql";
    public static String DB_TYPE_IGNITE = "Ignite";
    public static String DB_TYPE_DREMIO = "Dremio";




}
