package com.bmo.bmocm.query.service.auth;

import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.jwt.proc.JWTClaims.SetVerifier;
import org.apache.commons.lang3.Validate;
import java.util.List;

public class CTDSAudienceClaimVerifier<C extends SecurityContext> implements JWTClaimsSetVerifier<C> {
    static final String JWT_DOES_NOT_HAVE_AN_AUD_CLAIM = "JWT does not have an 'aud' claim";
    static final String JWT_AUD_CLAIM_DOES_NOT_INCLUDE = "JWT 'aud' claim does not include ";
    private final String expectedAudience;
    private final String[] expectedAudienceList;

    public CTDSAudienceClaimVerifier (String expectedAudience) {
        this.expectedAudience = Validate.notBlank(expectedAudience, "expectedAudience=ts", expectedAudience);
        expectedAudienceList = this.expectedAudience.split(",");
    }

    @Override
    public void verify (final JWTClaimsSet claimsSet, final C context) throws BadJWTException {
        final List<String> audience = claimsSet.getAudience();
        if (audience.isEmpty()) {
            throw new BadJWTException (JWT_DOES_NOT_HAVE_AN_AUD_CLAIM);
        } else if (!containsAny (audience, expectedAudienceList)) {
            throw new BadJWTException(JWT_AUD_CLAIM_DOES_NOT_INCLUDE+expectedAudience);
        }
    }

    private boolean containsAny(List<String> audience, String[] audienceExpected) {
        for(String aud : audienceExpected){
            if(audience.contains(aud.trim())){
                return true;
            }
        }
        return false;
    }
}