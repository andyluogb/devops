package com.bmo.bmocm.query.service.exception;

public class ExportFileException extends RuntimeException {
    public ExportFileException() {
        super();
    }
    public ExportFileException(String msg) {
        super(msg);
    }
}
