package com.bmo.bmocm.query.service.rest;

import java.io. UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

import com.bmo.bmocm.query.service.rest.handler.QueryHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.bmo.bmocm.query.service.common.CommonUtils;
import com.bmo.bmocm.query.service.common.QueryServiceConstant;
import com.bmo.bmocm.query.service.exception.ExceptionConstants;
import com.bmo.bmocm.query.service.exception.QueryServiceException;
import org.apache.commons.lang3.StringUtils;

//@CrossOrigin (origins = "*")
@RestController
public class QueryController {
    private static final Logger log = LoggerFactory.getLogger(QueryController.class);
    @Autowired
    private QueryHandler queryHandler;

    @RequestMapping(value = "/query", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> executeQueryPost(@RequestBody String query, @RequestHeader Map<String, String> headers) {
        CommonUtils.validateInputString(query);
        validQueryMethod(query, new String[]{QueryServiceConstant.ACTION_GET_DATA, QueryServiceConstant.ACTION_GET_COUNT}, "/query");
        Map<String, Object> result = queryHandler.executeQuery(query, headers);
        ResponseEntity<Map<String, Object>> response = processResponseHeader(result);
        return response;
    }

    @RequestMapping(value = "/query/{queryRaw}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> executeQueryGet(@PathVariable String queryRaw, @RequestHeader Map<String, String> headers) throws UnsupportedEncodingException {
        String query = URLDecoder.decode(queryRaw, "UTF-8");
        CommonUtils.validateInputString(query);
        validQueryMethod(query, new String[]{QueryServiceConstant.ACTION_GET_DATA, QueryServiceConstant.ACTION_GET_COUNT}, "/query");
        Map<String, Object> result = queryHandler.executeQuery(query, headers);
        ResponseEntity<Map<String, Object>> response = processResponseHeader(result);
        return response;
    }

    @RequestMapping(value = "/refresh", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> executeRefreshMeta(@RequestBody String query, @RequestHeader Map<String, String> headers) {
        CommonUtils.validateInputString(query);
        validQueryMethod(query, new String[]{QueryServiceConstant.ACTION_REFRESH_META_DATA}, "/refresh");
        Map<String, Object> result = queryHandler.executeRefreshMeta(query, headers);
        ResponseEntity<Map<String, Object>> response = processResponseHeader(result);
        return response;
    }

    private void validQueryMethod(String query, String[] methods, String request) {
        log.info("executeQuery:" + query);
        String action = CommonUtils.parseGraphqlAction(query);
        log.info("the graphql method is {}", action);
        if (!checkMethod(action, methods)) {
            throw new QueryServiceException(String.format(ExceptionConstants.REQUEST_QUERY_ACTION_NOT_SUPPORT, action, request));
        }
    }

    private boolean checkMethod(String action, String[] methods) {
        boolean checked = false;
        if (!StringUtils.isBlank(action) && methods != null && methods.length > 0) {
            for (String m : methods) {
                if (action.equalsIgnoreCase(m)) {
                    checked = true;
                    break;
                }
            }
        }
        return checked;
    }

    @RequestMapping(value = "/export", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> executeQueryFilePost(@RequestBody String query, @RequestHeader Map<String, String> headers) {
        validQueryMethod(query, new String[]{QueryServiceConstant.ACTION_GET_DATA_FILE}, "/export");
        Map<String, Object> result = queryHandler.executeQueryFile(query, headers);
        ResponseEntity<Map<String, Object>> response = processResponseHeader(result);
        return response;
    }

    @RequestMapping(value = "/export/{queryRaw}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> executeQueryFileGet(@PathVariable String queryRaw, @RequestHeader Map<String, String> headers)
            throws UnsupportedEncodingException {
        String query = URLDecoder.decode(queryRaw, "UTF-8");
        validQueryMethod(query, new String[]{QueryServiceConstant.ACTION_GET_DATA_FILE}, "/export");
        Map<String, Object> result = queryHandler.executeQueryFile(query, headers);
        ResponseEntity<Map<String, Object>> response = processResponseHeader(result);
        return response;
    }

    private ResponseEntity<Map<String, Object>> processResponseHeader (Map<String, Object> result) {
        String sessionId = (String) result.get(QueryServiceConstant.KEY_SESSION_ID);
        //result.remove (GraphqlConstant.KEY_SESSION_ID);
        ResponseEntity<Map<String, Object>> response = ResponseEntity.ok().header(QueryServiceConstant.KEY_SESSION_ID, sessionId).body(result);
        return response;
    }

}

