package com.bmo.bmocm.query.service.exception;

public class ExceptionConstants {
    public static String QUERY_RECORD_OVER_LIMIT = "Query record over limit";
    public static String REQUEST_QUERY_ACTION_NOT_SUPPORT = "Not supported action";


}
