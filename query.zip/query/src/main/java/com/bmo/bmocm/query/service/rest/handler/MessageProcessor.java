package com.bmo.bmocm.query.service.rest.handler;

public class MessageProcessor {
}
