package com.bmo.bmocm.query.service.model;

import java.util.List;
import java.util.Map;

public class ResponseDataFile {
    private String exportFileNames;
    private int recCount;
    private Map<String, Object> dataMap;

    public ResponseDataFile() {
    }

    public ResponseDataFile(String exportFileNames, int recCount) {
        this.exportFileNames = exportFileNames;
        this.recCount = recCount;
    }

    public String getExportFileNames() {
        return exportFileNames;
    }

    public void setExportFileNames(String exportFileNames) {
        this.exportFileNames = exportFileNames;
    }

    public int getRecCount() {
        return recCount;
    }

    public void setRecCount(int recCount) {
        this.recCount = recCount;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }
}
