package com.bmo.bmocm.query.service.graphql;

import graphql.GraphQLError;

import java.util.List;

public class CustomerGraphQLError extends RuntimeException {
    private String msg;
    private List<Object> path;

    public CustomerGraphQLError() {

    }
    public CustomerGraphQLError(String msg) {
        super(msg);
        this.msg = msg;
    }
    public CustomerGraphQLError(String msg, List<Object> path) {
        super(msg);
        this.msg = msg;
        this.path = path;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<Object> getPath() {
        return path;
    }

    public void setPath(List<Object> path) {
        this.path = path;
    }
}
