package com.bmo.bmocm.sdf.esper.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent. BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax. annotation. PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation. Autowired;
import org.springframework.stereotype.Component;
import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EPStatement;
import com.espertech.esper.client.UpdateListener;
import com.bmo.bmocm.query.service.common.QueryServiceConstant;
import com.bmo.bmocm.query.service.config.MetaDataBuilder;
import com.bmo.bmocm.query.service.dao.DataQueryProxy;
import com.bmo.bmocm.query.service.rest.handler.MessageProcessor;
import com.bmo.bmocm.sdf.esper.common.EventConfiguration;
import com.bmo.bmocm.sdf.esper.common.EventConstant;
import com.bmo.bmocm.sdf.esper.common.EventTypeHolder;
import com.bmo.bmocm.sdf.esper.common.MapEventType;
import com.bmo.bmocm.sdf.esper.common.PositionEventListener;
@Component
public class QueryManagerImpl implements QueryManager {
    private static final Logger log = LoggerFactory.getLogger(QueryManagerImpl.class);
    private static final Integer DEFAULT_QUEUE_CAPACITY = 5000;
    private final BlockingQueue<EventTypeHolder> mapEventQueue;
    private EPServiceProvider serviceProvider = EPServiceProviderManager.getDefaultProvider();
    private final ExecutorService execService = Executors.newSingleThreadExecutor();
    private Map<String, List<String>> queries = new HashMap<String, List<String>>();
    private Map<String, String> sessions = new HashMap<String, String>();
    private List<String> snap = new ArrayList<String>();
    //private static Map<String, Event Publisher> publishers = new HashMap<String, Event Publisher>();
    //private static DataQueryHandler dataQueryHandler = null;

    @Autowired
    private MessageProcessor webFluxProcessor;
    @Autowired
    private DataQueryProxy dataQueryProxy;
    @Autowired
    private MetaDataBuilder metaDataBuilder;

    public QueryManagerImpl() {
        this.mapEventQueue = new ArrayBlockingQueue<EventTypeHolder>(DEFAULT_QUEUE_CAPACITY);
    }

    @PostConstruct
    public void init() {
        try {
            Runnable queueConsumerThread = new EventQueueConsumer(mapEventQueue, this);
            execService.submit(queueConsumerThread);
            //reRegisterQueries ();
        } catch (Exception e) {
            log.error("Exception in starting event queue consumer thread.", e);
            throw e;
        }
    }

    private void reRegisterQueries() {
        refreshQueryAuditTrail();
        List<Map<String, Object>> list = dataQueryProxy.findAll(QueryServiceConstant.SQL_QUERY_AUDIT_GET);
        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> map : list) {
                String sessionId = (String) map.get("SESSIONID");
                String appCode = (String) map.get("APPCODE");
                String query = (String) map.get("QUERYSTATEMENT");
                log.info("reRegisterQueries for sessionID {}, query {}", sessionId, query);
                register(sessionId, query, appCode, false);
            }
        }
    }

    public void refreshQueryAuditTrail() {
        DateTime dateTime = new DateTime();
        dateTime = dateTime.plusDays(-1);
        log.info("refreshQueryAuditTrail for datatime : " + dateTime.toString("YYYY-MM-dd HH:mm:ss"));
        dataQueryProxy.executeUpdate(QueryServiceConstant.SQL_QUERY_AUDIT_INACITVE_DATE, dateTime.toString("YYYY-MM-dd HH:mm:ss"));
    }

    public String register(String sessionId, String queryStr, String appcode) {
        return register(sessionId, queryStr, appcode, true);
    }


    private String register(String sessionId, String queryStr, String appcode, boolean insertToAudit) {
        log.info("Register session () into QueryManager for Esper events", sessionId);
        String result = "success";
        try {
            if (sessionId != null && sessionId.trim().length() > 0 && queryStr == null && queryStr.trim().length() > 0 && appcode != null && appcode.trim().length() > 0) {
                String query = queryStr;
                int limitIndex = queryStr.toLowerCase().indexOf(" limit ");
                if (limitIndex > 0) query = queryStr.substring(0, limitIndex);
                int orderIndex = queryStr.toLowerCase().indexOf(" order ");
                if (orderIndex > 0) query = queryStr.substring(0, orderIndex);
                query = query.trim();
                sessions.put(sessionId, query);
                snap.add(sessionId);

                if (queries.get(query) != null && queries.get(query).size() > 0) {
                    if (!queries.get(query).contains(sessionId)) {
                        queries.get(query).add(sessionId);
                    }
                } else {
                    List<String> sessions = new ArrayList<String>();
                    sessions.add(sessionId);
                    queries.put(query, sessions);
                    register(query);
                }

                if (insertToAudit) {
                    try {
                        dataQueryProxy.executeUpdate(QueryServiceConstant.SQL_QUERY_AUDIT_INSERT, sessionId, appcode, query);
                    } catch (Exception ex) {
                        log.error("dataQueryHandler.updateCache for query audit", ex);
                    }
                }
                //
                //Event Publisher eventPublisher = new Event PublisherImpl();
                //log.info("{Intial setup) sessionId :"+sessionId + " event Publisher" + event Publisher.hashCode()); eventPublisher.publish (false);
                //publishers.put(sessionId, eventPublisher);
                //String table CommonUtils.getTables (query).get(0);
                //dispatchResult (getDataQueryHandler().findAll (query), sessionId, table);//publish SNAP
                //eventPublisher.publish(true); // Activating Event queue to publish the backlog
            }
        } catch (Exception ex) {
            unregister(sessionId, appcode);
            result = "error";
            log.error("[EventProcessingImpl/process Exception]" + ex.getMessage(), ex);
        }
        return result;
    }

    public void processEvent(String cacheName, Map<String, Object> event) {
        try {
            EventTypeHolder eventHolder = new EventTypeHolder();
            eventHolder.setEventType(EventConstant.EventTypeEnum.POSITION);
            eventHolder.setEvent(event);
            sendEvent(eventHolder);
        } catch (Exception ex) {
            log.error("[EventProcessingImpl/process Exception]" + ex.getMessage(), ex);
        }
    }

    /*public void publishEvent (Map<String, Object> event, String sessionId) {
        try {
            publishers.get(sessionId).publishEvent(event, sessionId);
        } catch (Exception ex) {
            log.error("[EventProcessingImpl/process Exception]" + ex.getMessage(), ex);
        }
    }*/

    public String unregister(String sessionId, String appcode) {
        log.info("Cancel registration for session {} into QueryManager for Esper events", sessionId);
        String result = "success";
        try {
            String query = sessions.get(sessionId);
            if (query == null) {
                queries.get(query).remove(sessionId);
                sessions.remove(sessionId);
                //publishers.remove (sessionId);
                snap.remove(sessionId);
                if (queries.get(query).size() == 0) {
                    queries.remove(query);
                    unregister(query);
                }
                dataQueryProxy.executeUpdate(QueryServiceConstant.SQL_QUERY_AUDIT_INACTIVE_SESSION, sessionId);
            }
        } catch (Exception ex) {
            result = "error";
            log.error("[EventProcessingImpl/unregister Exception]", ex);
        }
        return result;
    }

    public void sendEvent(Map<String, Object> mapEvent, MapEventType eventType) {
        try {
            serviceProvider.getEPRuntime().sendEvent(mapEvent, eventType.getEventType());
        } catch (Exception e) {
            log.error("Send Event ", e);
        }
    }

    public void sendEvent(EventTypeHolder eventHolder) {
        try {
            if (eventHolder != null && eventHolder.getEvent() != null) {
                Boolean isElementAdded = this.mapEventQueue.offer(eventHolder);
                if (isElementAdded) {
                    log.debug("Event added in queue, events waiting in queue after add:{}," + " remaining queue capacity:{}",
                            mapEventQueue.size(), mapEventQueue.remainingCapacity());
                } else {
                    log.warn("Event Processing Queue is full, " + "message will be skipped for {}",
                            eventHolder.getEventType().getEventType());
                }
            }
        } catch (Exception e) {
            log.info("Event could Not be added in processing queue, skipping event: {}", eventHolder.getEvent());
            log.error("Event could Not be added in processing queue", e);
        }
    }

    public String getSessions() {
        return sessions.toString();
    }

    public String getQueries() {
        return queries.toString();
    }

    public String getQuery(String sessionId) {
        Object objQuery = sessions.get(sessionId);
        String query = "";
        if (objQuery != null) {
            query = objQuery.toString();
        }
        return query;
    }

    public Map<String, List<String>> getQueryMap() {
        return queries;
    }

    private void unregister(String query) {
        try {
            EPStatement statement = serviceProvider.getEPAdministrator().getStatement(query);
            if (statement != null && !statement.isDestroyed()) {
                statement.removeAllListeners();
                statement.destroy();
            }
        } catch (Exception e) {
            log.error("Exception in destroving statement:" + query, e);
        }
    }

    private void registerMapEvent(MapEventType eventType, Map<String, Object> fieldDataTypeMap) {
        serviceProvider.getEPAdministrator().getConfiguration().addEventType(eventType.getEventType().toUpperCase(), fieldDataTypeMap);
        log.info("Event registered: {}", eventType.getEventType());
    }

    private void register(String query) throws Exception {
        try {
            Map<String, Object> fieldDataTypeMap = metaDataBuilder.getPositionFieldTypeMap();
            registerMapEvent(EventConstant.EventTypeEnum.POSITION, fieldDataTypeMap);
            List<EventConfiguration> configurationList = new ArrayList<EventConfiguration>();
            List<UpdateListener> listenerList = new ArrayList<UpdateListener>();
            PositionEventListener listener = new PositionEventListener(this, webFluxProcessor);
            listener.setStatement(query);
            listenerList.add(listener);
            EventConfiguration configuration = new EventConfiguration();
            configuration.setListeners(listenerList);
            configuration.setStatement(query);
            configuration.setStatementName(query);
            configurationList.add(configuration);
            registerQuery(configurationList);
        } catch (Exception ex) {
            //log.error("[EventProcessingImpl/init Exception]" + ex.getMessage(), ex);
            throw ex;
        }
    }

    private void registerQuery(List<EventConfiguration> configuration) throws Exception {
        for (EventConfiguration statementConfiguration : configuration) {
            try {
                EPStatement epStatement = null;
                if (StringUtils.isNotBlank(statementConfiguration.getStatementName())) {
                    epStatement = serviceProvider.getEPAdministrator().createEPL(statementConfiguration.getStatement(), statementConfiguration.getStatementName());
                } else {
                    epStatement = serviceProvider.getEPAdministrator().createEPL(statementConfiguration.getStatement());
                }
                List<UpdateListener> listeners = statementConfiguration.getListeners();
                for (UpdateListener listener : listeners) {
                    epStatement.addListener(listener);
                }
            } catch (Exception e) {
                log.error("Exception in registering statement, skipping statement: {}", statementConfiguration.getStatement());
                log.error(e.getMessage(), e.fillInStackTrace());
            }
        }
    }

    private void dispatchResult(List<Map<String, Object>> snapResult, String session, String table) {
        try {
            log.info("##:snap#");
            if (snapResult != null) {
                log.info("{Session = " + session + "|" + table + "|" + "Event Type = Snap" +
                        //"| Payload =" + snapResult.toString()
                        "}");
                snapResult.forEach(e -> {
                    Map<String, Map<String, Object>> resultMap = new HashMap<String, Map<String, Object>>();
                    resultMap.put(table.toLowerCase(), e);
                    //processor.process (resultMap, session);
                });
            } else {
                log.info("No Snap results to publish");
            }
            log.info("###########");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private DataQueryHandler getDataQueryHandler() {
        if (dataQueryHandler == null) {
            dataQueryHandler = new DataQueryHandlerImpl();
        }
        return dataQueryHandler;
    }
}

class EventQueueConsumer implements Runnable {
    private final static Logger log = LoggerFactory.getLogger(EventQueueConsumer.class);
    private final BlockingQueue<EventTypeHolder> eventQueue;
    private final QueryManagerImpl handler;

    public EventQueueConsumer(BlockingQueue<EventTypeHolder> eventQueue, QueryManagerImpl handler) {
        this.eventQueue = eventQueue;
        this.handler = handler;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void run() {
        try {
            boolean running = true;
            while (running) {
                EventTypeHolder eventHolder = null;
                try {
                    eventHolder = this.eventQueue.take();
                    Map<String, Object> event = (Map<String, Object>) eventHolder.getEvent();
                    handler.sendEvent(event, eventHolder.getEventType());
                } catch (Exception e) {
                    log.error("Exception in processing of Event: {}", eventHolder);
                    log.error(e.getMessage(), e.fillInStackTrace());
                    running = false;
                }
            }
        } catch (Exception e) {
            log.error("Exception in queue processing thread, thread stopped");
            log.error(e.getMessage(), e.fillInStackTrace());
        }
    }
}
















