package com.bmo.bmocm.query.service.model;

import java.util.List;
import java.util.Map;

public class DBTable {
    private String db;
    private String schema;
    private String tableName;
    private String schemaTableName;
    private String dbType;

    private String schemaNameQuoter;
    private String schemaTableNamePrefix;
    private Map<String, Object> tableNameMap;

    private List<DBColumn> columns;

    private String graphQLTableName;

    public DBTable() {
    }

    public DBTable(String dbType, String db, String schema, String table) {
        this.dbType = dbType;
        this.db = db;
        this.schema = schema;
        this.tableName = table;
    }

    public DBTable(String dbType, String db, String schema, String tableName, Map<String, Object> tableNameMap, String schemaNameQuoter, String schemaTableNamePrefix) {
        this.dbType = dbType;
        this.db = db;
        this.schema = schema;
        this.tableName = tableName;
        this.tableNameMap = tableNameMap;
        this.schemaNameQuoter = schemaNameQuoter;
        this.schemaTableNamePrefix = schemaTableNamePrefix;
    }

    public String getDb() {
        return db;
    }

    public void setDb(String db) {
        this.db = db;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getSchemaTableName() {
        return schemaTableName;
    }

    public void setSchemaTableName(String schemaTableName) {
        this.schemaTableName = schemaTableName;
    }

    public String getDbType() {
        return dbType;
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }

    public List<DBColumn> getColumns() {
        return columns;
    }

    public void setColumns(List<DBColumn> columns) {
        this.columns = columns;
    }

    public String getSchemaNameQuoter() {
        return schemaNameQuoter;
    }

    public void setSchemaNameQuoter(String schemaNameQuoter) {
        this.schemaNameQuoter = schemaNameQuoter;
    }

    public String getSchemaTableNamePrefix() {
        return schemaTableNamePrefix;
    }

    public void setSchemaTableNamePrefix(String schemaTableNamePrefix) {
        this.schemaTableNamePrefix = schemaTableNamePrefix;
    }

    public Map<String, Object> getTableNameMap() {
        return tableNameMap;
    }

    public void setTableNameMap(Map<String, Object> tableNameMap) {
        this.tableNameMap = tableNameMap;
    }

    public String getGraphQLTableName() {
        return graphQLTableName;
    }

    public void setGraphQLTableName(String graphQLTableName) {
        this.graphQLTableName = graphQLTableName;
    }
}
