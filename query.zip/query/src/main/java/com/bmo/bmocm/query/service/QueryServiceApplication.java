package com.bmo.bmocm.query.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation. EnableScheduling;

@ComponentScan (basePackages={ "com.bmo.bmocm.query.service", "com.bmo.bmocm.sdf"})
@SpringBootApplication
@EnableScheduling
public class QueryServiceApplication {
    //private static QueryManager queryManager = null;
    //private static EventListenerImpl eventListener = null;
    public static void main(String[] args) throws Exception {
        //ApplicationContext context =
        SpringApplication.run(QueryServiceApplication.class, args);
    }
}

