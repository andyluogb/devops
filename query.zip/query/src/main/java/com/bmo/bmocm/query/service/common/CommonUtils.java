package com.bmo.bmocm.query.service.common;

import com.google.gson.Gson;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.UUID;

public class CommonUtils {
    public static void  createTextFile(String string, String fileName) throws IOException {
        Files.createFile(Paths.get(fileName));
    }
    public static String getUUIDFromTimestamp() {
        return UUID.randomUUID().toString();
    }
    public static boolean validateInputString(String query) {
        return true;
    }

    public static String parseGraphqlAction(String query) {
        return QueryServiceConstant.ACTION_GET_DATA;
    }

    public static String parseGraphqlDataset(String query) {
        String dataSetName = "";
        return dataSetName;
    }
    public static String parseGraphqlAppCode(String query) {
        return "";
    }

    public static Map<String, Object> jsonToMap(String json) {
        Map<String, Object> map = new Gson().fromJson(json,Map.class);
        return map;
    }
    public static Map<String, Map<String, Object>> jsonToMapOfMap(String json) {
        Map<String, Map<String, Object>> map = new Gson().fromJson(json, Map.class);
        return map;
    }


}
