package com.bmo.bmocm.query.service.rest.handler;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import com.bmo.bmocm.query.service.graphql.GraphQLProvider;
import com.bmo.bmocm.query.service.model.QueryHeader;
import com.bmo.bmocm.query.service.telemetry.TelemetryUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.bmo.bmocm.query.service.auth.QueryAuthHelper;
import com.bmo.bmocm.query.service.common.CommonUtils;
import com.bmo.bmocm.query.service.common.QueryServiceConstant;
import com.bmo.bmocm.query.service.graphql.CustomerGraphQLError;
import org.apache.commons.lang3.StringUtils;
import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQLError;

@Component
public class QueryHandlerImpl implements QueryHandler {
    @Autowired
    private GraphQLProvider gprovider;
    @Autowired
    private TelemetryUtils telemetryUtils;
    @Autowired
    private QueryAuthHelper queryAuthHelper;

    public Map<String, Object> executeQuery(String query, Map<String, String> headers) {
        String action = CommonUtils.parseGraphqlAction(query);
        if (QueryServiceConstant.ACTION_GET_COUNT.equalsIgnoreCase(action)) {
            return executeRequest(action, query, headers, QueryServiceConstant.KEY_RESPONSE_TOTAL_COUNT);
        }
        return executeRequest(action, query, headers, null);
    }

    public Map<String, Object> executeQueryFile(String query, Map<String, String> headers) {
        return executeRequest(QueryServiceConstant.ACTION_GET_DATA_FILE, query, headers, QueryServiceConstant.KEY_RESPONSE_FILE);
    }

    public Map<String, Object> executeRefreshMeta(String query, Map<String, String> headers) {
        return executeRequest(QueryServiceConstant.ACTION_REFRESH_META_DATA, query, headers, QueryServiceConstant.KEY_RESPONSE_METADADA);
    }

    protected List<CustomerGraphQLError> filterGraphQLErrors(List<GraphQLError> errors) {
        List<CustomerGraphQLError> filteredErrors = errors.stream() //.filter(e -> e instanceof ExceptionWhile DataFetching)
                .map(e -> {
                    CustomerGraphQLError error = new CustomerGraphQLError(e.getMessage(), e.getPath());
                    return error;
                })
                .collect(Collectors.toList());
        return filteredErrors;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> executeRequest(String action, String query, Map<String, String> headers, String responseObjectKey) {
        //String action = CommonUtils.parseGraphqlAction (query);
        String dataSetName = CommonUtils.parseGraphqlDataset(query);
        String appCode = CommonUtils.parseGraphqlAppCode(query);
        Map<String, Object> context = new HashMap<String, Object>();
        QueryHeader queryHeader = getQueryHeaderFromRequestHeader(headers);
        String sessionId = UUID.randomUUID().toString();
        queryHeader.setSessionId(sessionId);
        context.put(QueryServiceConstant.KEY_QUERY_HEADER, queryHeader);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put(QueryServiceConstant.KEY_STATUS, QueryServiceConstant.VALUE_STATUS_SUCCESS);
        try {
            queryAuthHelper.performAuthencation(action, headers, queryHeader);
            ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).context(context).build();
            ExecutionResult executionResult = gprovider.graphQL().execute(executionInput);
            if (executionResult.getErrors().size() > 0) {
                result.put(QueryServiceConstant.KEY_ERRORS, filterGraphQLErrors(executionResult.getErrors()));
                result.put(QueryServiceConstant.KEY_STATUS, QueryServiceConstant.VALUE_STATUS_ERROR);
            }
            Map<String, Object> statisticMap = (Map<String, Object>) context.get(QueryServiceConstant.KEY_RESPONSE_STATISTIC_MAP);
            if (statisticMap != null && !statisticMap.isEmpty()) {
                result.put(QueryServiceConstant.KEY_STATISTIC, statisticMap);
            }
            if (StringUtils.isBlank(responseObjectKey)) {
                result.put(QueryServiceConstant.KEY_DATA, executionResult.getData());
            } else {
                List<Map<String, Object>> responseDataFile = (List<Map<String, Object>>) context.get(responseObjectKey);
                result.put(QueryServiceConstant.KEY_DATA, responseDataFile);
            }
        } catch (Exception e) {
            result.put(QueryServiceConstant.KEY_ERRORS, e.getMessage());
            result.put(QueryServiceConstant.KEY_STATUS, QueryServiceConstant.VALUE_STATUS_ERROR);
        }
        result.put(QueryServiceConstant.KEY_SESSION_ID, sessionId);
        //telemetryUtils.submitTelemetry (sessionId, appCode, queryHeader.getUserCode(),
        //action, dataSetName, query, (String) result.get (QueryServiceConstant.KEY_STATUS));
        telemetryUtils.submitTelemetry(sessionId, appCode, queryHeader.getUserId() == null ? "" : queryHeader.getUserId(), action, dataSetName, query, (String) result.get(QueryServiceConstant.KEY_STATUS));
        return result;
    }

    private QueryHeader getQueryHeaderFromRequestHeader(Map<String, String> headers) {
        QueryHeader queryHeader = new QueryHeader();
        if (headers.containsKey(QueryServiceConstant.KEY_SESSION_ID))
            queryHeader.setSessionId(headers.get(QueryServiceConstant.KEY_SESSION_ID));
        if (headers.containsKey(QueryServiceConstant.KEY_APP_CODE))
            queryHeader.setAppCode(headers.get(QueryServiceConstant.KEY_APP_CODE));
        if (headers.containsKey(QueryServiceConstant.KEY_DOMAIN))
            queryHeader.setDomain(headers.get(QueryServiceConstant.KEY_DOMAIN));
        if (headers.containsKey(QueryServiceConstant.KEY_IP_ADDRESS))
            queryHeader.setIpAddress(headers.get(QueryServiceConstant.KEY_IP_ADDRESS));
        if (headers.containsKey(QueryServiceConstant.KEY_USER_CODE))
            queryHeader.setUserCode(headers.get(QueryServiceConstant.KEY_USER_CODE));

        /*if (headers.containsKey (QueryServiceConstant.KEY_AUTHORIZATION.toLowerCase())) {
        String[] basicAuth = queryAuthHelper.decodebasicAuthorization(headers.get(QueryServiceConstant.KEY_AUTHORIZATION.toLowerCase()));
        if (basicAuth != null && basicAuth.length >= 1) {
            queryHeader.setUserCode(basicAuth[0]);
        }*/
        //if (headers.containsKey (QueryServiceConstant.KEY_ACCESS_TOKEN)) queryHeader.setAccessToken (headers.get (QueryServiceConstant.KEY_ACCESS_TOKEN));
        return queryHeader;
    }

    public GraphQLProvider getGprovider() {
        return gprovider;
    }

    public void setGprovider(GraphQLProvider gprovider) {
        this.gprovider = gprovider;
    }
}


