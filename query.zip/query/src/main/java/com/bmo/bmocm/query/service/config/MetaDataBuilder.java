package com.bmo.bmocm.query.service.config;

import java.math. BigDecimal;
import java.math.BigInteger;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax. annotation. PostConstruct;

import com.bmo.bmocm.query.service.common.CommonUtils;
import com.bmo.bmocm.query.service.common.QueryServiceConstant;
import com.bmo.bmocm.query.service.model.DBColumn;
import com.bmo.bmocm.query.service.model.DBTable;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
//import com.bmo.bmocm.data.discovery.service.model.DataCatalog;
//import com.bmo.bmocm.sdf.utils.Constant;
import graphql.Scalars;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLScalarType;
import graphql.schema.idl.SchemaPrinter;

@Component
public class MetaDataBuilder {
    private static final Logger log = LoggerFactory.getLogger(MetaDataBuilder.class);
    public static final String REC_COUNT_FIELD_NAME = "__REC_COUNT__";
    private static final String TABLE_TYPE_SYSTEM_TABLE= "SYSTEM_TABLE";

    //@Autowired
    //private DremioConfig dremioConfig;

    @Autowired
    private MemSQLConfig memSQLConfig;

    //@Autowired
    //private DataDiscoveryConfig dataDiscoveryConfig;
    //@Value ("${graphql.ignite.tables.exclude}")
    //private String[] exclude TableArrayIgnite;
    @Value("${graphql.memsql.tables.exclude}")
    private String[] excludeTableArrayMemsql;
    //@Value("${graphql.dremio.tables.exclude}")
    //private String[] excludeTableArrayDremio;

    //@Value ("${graphql.dremio.schemas}")
    //private String[] dremioSchemas;
    @Value("${query.service.datasources.tablename.map}")
    private String tableNamMapStr;
    private Map<String, Object> tableNameMap;
    @Value("${query.service.datasources.schema.quoter)")
    private String schemaNameQuoterStr;
    private Map<String, Object> schemaNameQuoterMap;
    @Value("${query.service.datasources.schema.table.name.prefix}")
    private String schemaTableNamePrefixStr;
    private Map<String, Map<String, Object>> schemaTableNamePrefixMap;
    private SchemaPrinter schemaPrinter = new SchemaPrinter();
    private Map<String, List<DBTable>> dbMetaData = new HashMap<String, List<DBTable>>();  //table to DB type map
    private Map<String, String> tableCatalog = new HashMap<String, String>(); //DBSchemaTableName -> DBType
    private Map<String, DBTable> tableMap = new HashMap<String, DBTable>(); //get GraphQLTableName -> DBTable
    //Map to hold the table->sub select
    private Map<String, String> tableToSubqueryMap = new HashMap<String, String>();
    //Map to hold json spec
    private Map<String, String> jsonSpecMap = new HashMap<String, String>();


    public MetaDataBuilder() {
    }

    @PostConstruct
    public void init() throws SQLException {
        this.dbMetaData = new HashMap<String, List<DBTable>>();
        this.tableCatalog = new HashMap<String, String>(); //DBSchemaTableName -> DBType
        this.tableMap = new HashMap<String, DBTable>(); //getGraphQLTableName -> DBTable
        this.tableToSubqueryMap = new HashMap<String, String>();
        this.jsonSpecMap = new HashMap<String, String>();

        this.tableNameMap = CommonUtils.jsonToMap(this.tableNamMapStr);
        this.schemaNameQuoterMap = CommonUtils.jsonToMap(this.schemaNameQuoterStr);
        this.schemaTableNamePrefixMap = CommonUtils.jsonToMapOfMap(this.schemaTableNamePrefixStr);
        Set<String> existedTable = new HashSet<String>();
        Set<String> excludeTablesMemsql = new HashSet<String>();
        Arrays.asList(excludeTableArrayMemsql).forEach(t -> {
            excludeTablesMemsql.add(t.toLowerCase());
        });

        //List<DataCatalog> memSqlDataCatalogList = dataDiscoveryConfig.getMemSqlDataCatalog();
        //List<DBTable> memSqlDBTables = lookupDBTables(memSqlDataCatalogList, excludeTablesMemsql, existedTable, QueryServiceConstant.DB_TYPE_MEMSQL);
        //Set<String> excludeTables Ignite = new HashSet<String>();
        //Arrays.asList (excludeTableArrayIgnite).forEach (t->{
        //excludeTablesIgnite.add(t.toLowerCase());
        //)};
        //List<DataCatalog> igniteDataCatalogList = dataDiscoveryConfig.getIgniteDataCatalog ();
        //List<DBTable> igniteDBTables = lookupDBTables(igniteDataCatalogList, excludeTablesIgnite, existedTable, QueryServiceConstant.DB_TYPE_IGNITE);
        //Set<String> excludeTablesDremio = new HashSet<String>();
        //Arrays.asList(excludeTableArrayDremio).forEach(t -> {
        //    excludeTablesDremio.add(t.toLowerCase());
        //});
        //List<DataCatalog> dremioDataCatalogList = dataDiscoveryConfig.getDremioDataCatalog();
        //List<DBTable> dremioDBTables = lookupDBTables(dremioDataCatalogList, excludeTablesDremio, existedTable, QueryServiceConstant.DB_TYPE_DREMIO);
        /* get schema from DB connection*/
           String[][] memSqlSchemaList={{"client1", null}}; //[0]-db/catalog; [1]-schema
           Connection connection = memSQLConfig.memSqlConnection();
           List<DBTable> memSqlDBTables = lookupDBTablesFromConnection(existedTable, connection, memSqlSchemaList, QueryServiceConstant.DB_TYPE_MEMSQL);

        /* get schema from DB connection*/

        /*List<DBTable> dremioDBTables = new ArrayList<DBTable>();
        if (dremioSchemas!=null && dremioSchemas.length > 0) {
            //{{null, "QA.BAQO"), (null, "DEV.Test"), (null, "DEV.tmp-BIO"), (null, "TQA.ZPQO")); //[0]-db/catalog; [1]-schema
            String[][] dbDremioSchemaList = new String[dremioSchemas.length][2];
            for (int i = 0; i < dremioSchemas.length; i++) {
                dbDremioSchemaList[i][0] = null;
                if (StringUtils.isBlank(dremioSchemas[i]) || dremioSchemas[i].trim().equalsIgnoreCase("null")) {
                    dbDremioSchemaList[i][1] = null;
                } else {
                    dbDremioSchemaList[i][1] = dremioSchemas[i].trim();
                }
            }
            try (Connection connection = dremioConfig.dremioConnection()) {
                dremioDBTables = lookupDBTablesFromConnection(existedTable, connection, dbDremioSchemaList, QueryServiceConstant.DB_TYPE_MEMSQL);
            } catch (Exception e) {
                log.error("failed to connect to dremio", e);
            }
        }*/

        /* get schema from Ignite meta data */
        /*List<DBTable> igniteDBTables= new ArrayList<DBTable>();
        List<String> igniteTables = getIgniteTables();
        for (String schemaTableName: igniteTables) {
            DBTable dbTable = lookupIgniteTableMetadata(schemaTableName);
            if (!excludeTablesIgnite.contains(dbTable.getTableName().toLowerCase())) {
                if (!existedTable.contains(dbTable.getTableName().toLowerCase())) {
                    existedTable.add(dbTable.getTableName().toLowerCase());
                    igniteDBTables.add(dbTable);
                    addToMetaMap(dbTable, QueryServiceConstant.DB_TYPE_IGNITE);
                } else {
                    log.info("Duplicated table name ) in Ignite", dbTable.getSchemaTableName());
                }
            }
        }*/

        dbMetaData.put(QueryServiceConstant.DB_TYPE_MEMSQL, memSqlDBTables);
        //dbMetaData.put (QueryServiceConstant.DB_TYPE_IGNITE, igniteDBTables);
        //dbMetaData.put(QueryServiceConstant.DB_TYPE_DREMIO, dremioDBTables);

        /*List<JsonSpec> jsonSpecList = dataDiscoveryConfig.getJsonSpecList();
        if (jsonSpecList != null && !jsonSpecList.isEmpty()) {
            jsonSpecList.forEach(jsonSpec -> {
                if (!StringUtils.isBlank(jsonSpec.getSpec())) {
                    log.info("Adding jsonSpec {}", jsonSpec.getId());
                    jsonSpecMap.put(jsonSpec.getId().toLowerCase(), jsonSpec.getSpec());
                }
            });
        }*/
    }

    public String getSubQueryWithTableName(String tableName) {
        return tableToSubqueryMap.get(tableName.toLowerCase());
    }

    private void addToSubqueryMap(String dbSchemaTableName, String sql) {
        if (!StringUtils.isBlank(dbSchemaTableName) && !StringUtils.isBlank(sql)) {
            log.info("Added subQuery for table () {}", dbSchemaTableName, sql);
            tableToSubqueryMap.put(dbSchemaTableName.trim().toLowerCase(), sql.trim());
        }
    }

    public String getJsonSpecWithSpecName(String gqlTableName, String jsonSpecName) {
        String jsonSpec = null;
        if (!StringUtils.isBlank(gqlTableName) && !StringUtils.isBlank(jsonSpecName)) {
            jsonSpec = jsonSpecMap.get(getJsonSpecKey(gqlTableName, jsonSpecName));
        }
        return jsonSpec;
    }

    private void addToJsonSpecMap(String gqlTableName, String jsonSpecName, String jsonSpec) {
        if (!StringUtils.isBlank(gqlTableName) && !StringUtils.isBlank(jsonSpecName) && !StringUtils.isBlank(jsonSpec)) {
            log.info("Added JsonSpec for jsonSpecName {} - {} - {}", gqlTableName, jsonSpecName, jsonSpec);
            jsonSpecMap.put(getJsonSpecKey(gqlTableName, jsonSpecName), jsonSpec.trim());
        }
    }

    private void addToJsonSpecMap(String gqlTableName, Map<String, String> theJsonSpecMap) {
        if (theJsonSpecMap != null && !theJsonSpecMap.isEmpty()) {
            for (String key : theJsonSpecMap.keySet()) {
                addToJsonSpecMap(gqlTableName, key, theJsonSpecMap.get(key));
            }
        }
    }

    private String getJsonSpecKey(String gqlTableName, String jsonSpecName) {
        return String.format("%s_ts", gqlTableName.trim(), jsonSpecName.trim()).toLowerCase();
    }


    /*
    private List<DBTable> lookupDBTables(List<DataCatalog> dataCatalogList, Set<String> excludeTables, Set<String> existedTable, String dbType) {
        List<DBTable> dBTables = new ArrayList<DBTable>();
        if (dataCatalogList != null && !dataCatalogList.isEmpty()) {
            dataCatalogList.forEach(dataCatalog -> {
                DBTable dbTable = new DBTable(dataCatalog, tableNameMap,
                        (String) schemaNameQuoterMap.get(dataCatalog.getLocation()),
                        schemaTableNamePrefixMap.get(dataCatalog.getLocation()));
                String gqlTableName = dbTable.getGraphQLTableName().toLowerCase();
                if (!excludeTables.contains(gqlTableName)) {
                    if (!existedTable.contains(gqlTableName)) {
                        existedTable.add(gqlTableName);
                        dBTables.add(dbTable);
                        addToMetaMap(dbTable, dbType);
                        addToSubqueryMap(dbTable.getSchemaTableName(), dataCatalog.getSql());
                        addToJsonSpecMap(gqlTableName, dataCatalog.getJsonSpec());
                    } else {
                        log.info("Duplicated table name () in MemSql", dbTable.getSchemaTableName());
                    }
                }
            });
        }
        return dBTables;
    }*/


    private List<DBTable> lookupDBTablesFromConnection (Set<String> existedTable, Connection connection, String[] [] dbSchemaList, String dbType) {
        List<DBTable> dBTables = new ArrayList<DBTable>();
        try {
            DatabaseMetaData databaseMetaData = connection.getMetaData();
            dBTables = lookupSqlTableMetadata(databaseMetaData, dbSchemaList, dbType);
            for (DBTable dbTable : dBTables) {
                if (!existedTable.contains(dbTable.getGraphQLTableName().toLowerCase())) {
                    dbTable = lookupSqlColumnMetadata(databaseMetaData, dbTable);
                    existedTable.add(dbTable.getGraphQLTableName().toLowerCase());
                    addToMetaMap(dbTable, dbType);
                } else {
                    log.info("Duplicated table name {} in dbType {}", dbTable.getSchemaTableName(), dbType);
                }
            }
        } catch (Exception e) {
            log.error("failed to build schema for Dremio", e);
            dBTables = new ArrayList<DBTable>();
        }
        return dBTables;
    }

    private void addToMetaMap(DBTable dbTable, String dbType) {
        tableCatalog.put(dbTable.getSchemaTableName().toLowerCase(), dbType);
        tableMap.put(dbTable.getGraphQLTableName().toLowerCase(), dbTable);
    }

    public String getDBTypeWithFullTableName(String tableName) {
        return tableCatalog.get(tableName.toLowerCase());
    }

    public DBTable getDBTable(String gqlTableName) {
        DBTable table = tableMap.get(gqlTableName.toLowerCase());
        return table;
    }

    public String getDBTableFullName(String gqlTableName) {
        DBTable table = tableMap.get(gqlTableName.toLowerCase());
        return table == null ? "" : table.getSchemaTableName();
    }

    public boolean isIgniteTable(String tableName) {
        return tableName != null && getDBTypeWithFullTableName(tableName) != null && getDBTypeWithFullTableName(tableName).equalsIgnoreCase(QueryServiceConstant.DB_TYPE_IGNITE);
    }

    public boolean isMemSqlTable(String tableName) {
        return tableName != null && getDBTypeWithFullTableName(tableName) != null && getDBTypeWithFullTableName(tableName).equalsIgnoreCase(QueryServiceConstant.DB_TYPE_MEMSQL);
    }

    public boolean isDremioTable(String tableName) {
        return tableName != null && getDBTypeWithFullTableName(tableName) != null && getDBTypeWithFullTableName(tableName).equalsIgnoreCase(QueryServiceConstant.DB_TYPE_DREMIO);
    }

    /*public Map<String, Object> getPositionFieldTypeMap() {
        Map<String, Object> valueMap = new HashMap<String, Object>();
        DBTable table = tableMap.get(Constant.CACHE_POSITION.toLowerCase());
        for (DBColumn column : table.getColumns()) {
            String field = column.getColumnName();
            field = field.toUpperCase();
            String fieldType = column.getColumnType();
            valueMap.put(field, convertJavaClassType(fieldType));
        }
        return valueMap;
    }*/

    public String buildGraphqlSchema() throws Exception {
        StringBuilder schema = new StringBuilder();

        Set<String> excludeSet = new HashSet<String>();

        dbMetaData.values().forEach(tableList -> {
            tableList.forEach(dbTable -> {
                String cacheSchema = this.buildGraphqlSchema(dbTable);
                if (!StringUtils.isBlank(cacheSchema)) {
                    schema.append(cacheSchema).append(System.lineSeparator());
                } else {
                    excludeSet.add(dbTable.getGraphQLTableName().toLowerCase());
                }
            });
        });

        String[] allTables = dbMetaData.values().stream().flatMap(dbTable -> {
            return dbTable.stream().map(theTable -> {
                return theTable.getGraphQLTableName();
            });
        }).filter(t -> !excludeSet.contains(t.toLowerCase())).toArray(String[]::new);

        schema.append(this.createResposeDataSchema(allTables)).append(System.lineSeparator()).append(System.lineSeparator());
        schema.append(this.createSubscriptionDataSchema(allTables)).append(System.lineSeparator()).append(System.lineSeparator());
        return schema.toString();
    }

    private String createResposeDataSchema(String[] tables) {
        String[] types = Arrays.stream(tables).map(table -> {
            return String.format("%s: [s]", table.toLowerCase(), StringUtils.capitalize(table));
        }).toArray(String[]::new);
        String schema = String.format("type Response Data (ststs}",
                System.lineSeparator(),
                String.join(System.lineSeparator(), types), System.lineSeparator()
        );
        return schema;
    }

    private String createSubscriptionDataSchema(String[] tables) {
        String[] types = (String[]) Arrays.stream(tables).map(table -> {
            return String.format("%s:%s", table.toLowerCase(), StringUtils.capitalize(table));
        }).toArray(String[]::new);
        String schema = String.format("type SubscriptionData {%s%s%s}",
                System.lineSeparator(),
                String.join(System.lineSeparator(), types),
                System.lineSeparator());
        return schema;
    }

    private String buildGraphqlSchema(DBTable dbTable) {
        String schemaStr = null;
        if (dbTable != null && dbTable.getColumns() != null && !dbTable.getColumns().isEmpty()) {
            try {
                GraphQLObjectType.Builder graphQLObjectType = GraphQLObjectType.newObject().name(StringUtils.capitalize(dbTable.getGraphQLTableName()));
                for (DBColumn column : dbTable.getColumns()) {
                    graphQLObjectType.field(
                            GraphQLFieldDefinition.newFieldDefinition()
                                    .name(column.getGraphqlColumnName().toUpperCase())
                                    .type(convertReturnType(column.getColumnType()))
                    );
                }
                boolean recCountFieldExists = false;
                for (DBColumn column : dbTable.getColumns()) {
                    if (column.getGraphqlColumnName().equalsIgnoreCase(REC_COUNT_FIELD_NAME)) {
                        recCountFieldExists = true;
                        break;
                    }
                }
                if (recCountFieldExists) {
                    graphQLObjectType.field(GraphQLFieldDefinition.newFieldDefinition()
                            .name(REC_COUNT_FIELD_NAME)
                            .type(Scalars.GraphQLInt));
                }
                schemaStr = schemaPrinter.print(graphQLObjectType.build());
            } catch (Exception e) {
                log.error("Failed to build graphQL schema for () {}", dbTable.getGraphQLTableName(), e.getMessage());
            }
        }
        return schemaStr;
    }

    /*
    private List<String> getIgniteTables() {
        List<Map<String, Object>> tables = dataQueryHandlerIgnite.findAll(SQL_QUERY_GET_TABLES);
        List<String> list = new ArrayList<String>();
        if (tables != null && !tables.isEmpty()) {
            tables.forEach(m -> {
                list.add((String) m.values().toArray()[0]);
            });
        }
        return list;
    }

    private DBTable lookupIgniteTableMetadata(String schemaTableName) {
        DBTable dbTable = parseIgniteDBTable(schemaTableName);
        List<DBColumn> columnList = new ArrayList<DBColumn>();
        String cacheName = dataQueryHandlerIgnite.getCacheNameByTableName(dbTable.getSchema(), dbTable.getTableName());
        Map<String, String> columns = igniteHandler.getCacheEntity(cacheName);
        for (String columnName : columns.keySet()) {
            DBColumn column = new DBColumn(columnName, columns.get(columnName));
            columnList.add(column);
        }
        dbTable.setColumns(columnList);
        return dbTable;
    }
    private DBTable parseIgniteDBTable(String schemaTableName) {
        String[] tableSplits = StringUtils.split(schemaTableName, ".");
        String schema = null;
        String table = schemaTableName;
        if (tableSplits.length > 1) {
            schema = tableSplits[0];
            table = tableSplits[1];
        }
        DBTable dbTable = new DBTable(QueryServiceConstant.DB_TYPE_IGNITE, schema, table);
        return dbTable;
    }
    */

     private List<DBTable> lookupSqlTableMetadata(DatabaseMetaData databaseMetaData, String[][] dbSchemaList, String dbType) throws SQLException {
        List<DBTable> tableList = new ArrayList<DBTable>();
        for (String[] dbSchema : dbSchemaList) {
            ResultSet resultSet = null;
            try {
                resultSet = databaseMetaData.getTables(dbSchema[0], dbSchema[1], null, null);
                while (resultSet.next()) {
                    String tableName = resultSet.getString("Table_NAME");
                    String tableType = resultSet.getString("TABLE_TYPE");
                    String schema = resultSet.getString("TABLE_SCHEM");
                    String db = resultSet.getString("TABLE_CAT");
                    if (!TABLE_TYPE_SYSTEM_TABLE.equalsIgnoreCase(tableType)) { //filter out system tables
                        log.info("Table catalog: {}, Table schema: {}, Table name: {}, Table type: {}", db, schema, tableName, tableType);
                        DBTable table = new DBTable(dbType, db, schema, tableName, tableNameMap,
                                (String) schemaNameQuoterMap.get(dbType), (String)schemaTableNamePrefixMap.get(dbType).get(db));
                        tableList.add(table);
                    }
                }
            } catch (Exception e) {
                log.error("Failed to lookupSqlTableMetadata for DB scehema {} under DB Type {}", dbSchema, dbType);
            } finally {
                if (resultSet != null) {
                    resultSet.close();
                }
            }
        }
        return tableList;
    }

    private DBTable lookupSqlColumnMetadata(DatabaseMetaData databaseMetaData, DBTable dbTable) throws SQLException {
        List<DBColumn> columnList = new ArrayList<DBColumn>();
        ResultSet resultSet = null;
        try {
            resultSet = databaseMetaData.getColumns(dbTable.getDb(), dbTable.getSchema(), dbTable.getTableName(), null);
            while (resultSet.next()) {
                String columnName = resultSet.getString("COLUMN_NAME");
                String columnType = resultSet.getString("TYPE_NAME");
                DBColumn column = new DBColumn(columnName, columnType);
                columnList.add(column);
            }
        } catch (Exception e) {
            log.error("Failed to lookupSqlColumnMetadata for DB Table {} under DB Type {}", dbTable.getSchemaTableName(), dbTable.getDbType());
            columnList = new ArrayList<DBColumn>();
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
        }
        dbTable.setColumns(columnList);
        return dbTable;
    }



    private DBTable parseSqlDBTable(String[] dbSchemaTableName, String dbType) {
        String db  = dbSchemaTableName[0];
        String schema = dbSchemaTableName[1];
        String table = dbSchemaTableName [2];
        DBTable dbTable = new DBTable(dbType, db, schema, table);
        return dbTable;
    }


    public GraphQLScalarType convertReturnType(String type) {
        String[] typeSplit = StringUtils.split(type, ".");
        String rawType = (typeSplit == null ? "" : typeSplit[typeSplit.length - 1]).toLowerCase();
        switch (rawType) {
            case "double":
                return Scalars.GraphQLFloat;
            case "integer":
            case "int":
            case "tinyint":
            case "smallint":
                return Scalars.GraphQLInt;
            case "float":
                return Scalars.GraphQLFloat;
            case "boolean":
                return Scalars.GraphQLBoolean;
            case "long":
            case "bigint":
                return Scalars.GraphQLInt;
            case "short":
                return Scalars.GraphQLInt;
            case "decimal":
            case "bigdecimal":
                return Scalars.GraphQLFloat;
            case "biginteger":
                return Scalars.GraphQLInt;
            default:
                return Scalars.GraphQLString;
        }
    }

    public Object convertJavaClassType(String type) {
        String[] typeSplit = StringUtils.split(type, ".");
        String rawType = (typeSplit == null ? "" : typeSplit[typeSplit.length - 1]).toLowerCase();
        switch (rawType) {
            case "double":
                return Double.class;
            case "integer":
            case "int":
            case "tinyint":
            case "smallint":
                return Integer.class;
            case "float":
                return Float.class;
            case "boolean":
                return Boolean.class;
            case "long":
            case "bigint":
                return Long.class;
            case "short":
                return Short.class;
            case "decimal":
            case "bigdecimal":
                return BigDecimal.class;
            case "biginteger":
                return BigInteger.class;
            case "date":
                return Date.class;
            case "timestamp":
                return Timestamp.class;
            default:
                return String.class;
        }
    }

    public void setExcludeTableArrayMemsql(String[] excludeTableArrayMemsql) {
        this.excludeTableArrayMemsql = excludeTableArrayMemsql;
    }

    //public void setExcludeTableArrayDremio(String[] excludeTableArrayDremio) {
    //    this.excludeTableArrayDremio = excludeTableArrayDremio;
    //}

    public void setTableNamMapStr(String tableNamMapStr) {
        this.tableNamMapStr = tableNamMapStr;
    }

    public void setSchemaNameQuoterStr(String schemaNameQuoterStr) {
        this.schemaNameQuoterStr = schemaNameQuoterStr;
    }

    public void setSchemaTableNamePrefixStr(String schemaTableNamePrefixStr) {
        this.schemaTableNamePrefixStr = schemaTableNamePrefixStr;
    }

}