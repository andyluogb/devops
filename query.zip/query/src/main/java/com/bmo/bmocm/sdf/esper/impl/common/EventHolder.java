package com.bmo.bmocm.sdf.esper.impl.common;

import java.util.Map;

public class EventHolder {
    private Map<String, Object> event;
    private String sessionId;
    private String subscriptionType;

    public EventHolder() {
    }


    public Map<String, Object> getEvent() {
        return event;
    }

    public void setEvent(Map<String, Object> event) {
        this.event = event;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSubscriptionType() {
        return subscriptionType;
    }

    public void setSubscriptionType(String subscriptionType) {
        this.subscriptionType = subscriptionType;
    }
}
