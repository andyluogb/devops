package com.bmo.bmocm.query.service.export.json;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class QueryJsonTransformer {

    public void transformAndWriteBackJsonFile(String jsonSpec, List<String> allExportFileList, boolean isToZip) {

    }
}
