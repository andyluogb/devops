package com.bmo.bmocm.query.service.s3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
//import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration; import com.amazonaws.regions. Regions;
import com.amazonaws.services.s3.Amazon53;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing; import com.amazonaws.services.s3.model.S30bject;
import com.amazonaws.services.s3.model.S30bjectInputStream;
import com.amazonaws.services.s3.model.S30bjectSummary;
import com.bmo.bmocm.bago.query.service.exception.QueryServiceException;
import com.bmo.bmocm.baqo.query.service.model.S3Profile;
public class QueryS3Client {
    protected static final Logger log = LoggerFactory.getLogger(QueryS3Client.class);
    private AmazonS3 s3;
    private String bucketName;

    //private TransferManager xfer_mgr;
    public QueryS3Client() {
    }

    public QueryS3Client(S3Profile profile) {
        init(profile.getEndpoint(), profile.getMaxConnection(), profile.getMaxRetry(),
                profile.getSocketTimeoutMinutes(), profile.getAccessKey(), profile.getSecretKey(),
                profile.getMaxFileTransferThreads(), profile.getMaxFileTransferThresholdMegabyte(), profile.getS3Bucket());
    }

    protected void close() {
        log.info(">>>>>>>>Closing s3 connections");
        if (s3 != null) {
            s3.shutdown();
        }
    }

    protected void init(String bmoS3Endpoint, int bmoS3MaxConnection, int bmoS3MaxRetry, int bmoS3SocketTimeoutMinutes,
                        String bmoS3ClientAccessKey, String bmoS3ClientSecretKey, int bmoS3MaxFileTransferThreads,
                        int bmoS3MaxFileTransferThresholdMegaByte, String s3Bucket) {
        this.bucketName = s3Bucket;
        ClientConfiguration clientConfiguration = new ClientConfiguration()
                .withMaxErrorRetry(bmoS3MaxRetry)
                .withMaxConnections(bmoS3MaxConnection)
                .withSocketTimeout(bmoS3SocketTimeoutMinutes * 60 * 1000);
        //clientConfiguration.setMaxConnections (bmoS3ConnectionPool);
        BasicAWSCredentials credentials = new BasicAWSCredentials(bmoS3ClientAccessKey, bmoS3ClientSecretKey);
        //s3 = new AmazonS3Client (credentials, clientConfiguration);
        //s3.setEndpoint (bmoS3Endpoint);
        s3 = AmazonS3ClientBuilder.standard()
                //.withCredentials (new DefaultAWSCredentials ProviderChain ())
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                //.withRegion (Regions. DEFAULT_REGION)
                .withClientConfiguration(clientConfiguration)
                .withEndpointConfiguration(new EndpointConfiguration(bmoS3Endpoint, Regions.DEFAULT_REGION.getName()))
                .build();
        /*xfer_mgr = TransferManagerBuilder.standard()
                .withS3Client (s3)
                .withMultipartUploadThreshold ((long) (bmoS3MaxFileTransferThresholdMegaByte 1024 1024))
                .withExecutorFactory(()-> Executors.newFixedThreadPool (bmoS3MaxFileTransferThreads))
                .build();*/

        /* testing codes*/
         /*deleteFolderFromS3(s3Bucket, "BAQO/Test");
         List<String> list = getObjectslistFromFolder (s3Bucket, "Product");
         log.info("S3 bucket folder { list {}", s3Bucket, "Product", list == null ?0:list.size());
         if (list!=null && !list.isEmpty()) {
             list.forEach(s -> {
                 log.info("S3 object list -- {}", s);
             });
         }*/
    }

    public void uploadAndDeleteLocalFile(String keyName, String filePath) {
        try {
            keyName = formalizeKeyName(keyName);
            log.info("Upload file to bucket with object key {}", filePath, this.bucketName, keyName);
            s3.putObject(this.bucketName, keyName, new File(filePath));
            Files.deleteIfExists(Paths.get(filePath));
        } catch (Exception e) {
            String msg = String.format("Failed to upload file is to bucket is with object key %s", filePath, this.bucketName, keyName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        }
    }

    public void uploadFileToS3(String keyName, String filePath) {
        try {
            keyName = formalizeKeyName(keyName);
            log.info("Upload file () to bucket {} with object key {}", filePath, this.bucketName, keyName);
            s3.putObject(this.bucketName, keyName, new File(filePath));
        } catch (Exception e) {
            String msg = String.format("Failed to upload file %s to bucket %s with object key %s", filePath, this.bucketName, keyName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        }
    }

    public void deleteObjectFromS3(String keyName) {
        try {
            keyName = formalizeKeyName(keyName);
            log.info("Delete object key {} from bucket {}", keyName, this.bucketName);
            s3.deleteObject(this.bucketName, keyName);
        } catch (Exception e) {
            String msg = String.format("Failed to delete object is from bucket %s", keyName, this.bucketName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        }
    }

    public void deleteFolderFromS3(String folderName) {
        try {
            folderName = formalizeKeyName(folderName);
            log.info("Delete folder {} from bucket {}", folderName, this.bucketName);
            List<S3ObjectSummary> list = getObjectsListFromFolder(folderName);
            for (S3ObjectSummary object : list) {
                String key = object.getKey();
                Date lastModify = object.getLastModified();
                log.info("Deleting s3 object {} with date {}", key, lastModify);
                s3.deleteObject(this.bucketName, key);
            }
        } catch (Exception e) {
            String msg = String.format("Failed to delete folder is from bucket %s", folderName, this.bucketName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        }
    }

    public void downloadFile(String keyName, String filePath) {
        S3ObjectInputStream s3is = null;
        FileOutputStream fos = null;
        try {
            keyName = formalizeKeyName(keyName);
            log.info("downloadFile file () to bucket with object key ()", filePath, this.bucketName, keyName);
            S30bject o = s3.getObject(this.bucketName, keyName);
            s3is = o.getObjectContent();
            fos = new FileOutputStream(new File(filePath));
            byte[] read_buf = new byte[1024];
            int read_len = 0;
            while ((read_len = s3is.read(read_buf)) > 0) {
                fos.write(read_buf, 0, read_len);
            }
        } catch (Exception e) {
            String msg = String.format("Failed to download files from bucket s with object key %s", filePath, this.bucketName, keyName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        } finally {
            if (s3is != null) {
                try {
                    s3is.close();
                } catch (IOException e) {
                    log.error("Failed to close S30bjectInputStream", e);
                }
            }

            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    log.error("Failed to close FileOutputStream", e);
                }
            }
        }
    }

    public void uploadFileTransferAndDeleteStaging(String keyName, String filePath) {
        keyName = formalizeKeyName(keyName);
        log.info("uploadFileTransfer file {} to bucket {} with object key {}", filePath, bucketName, keyName);
        File file = new File(filePath);
        try {
            //ProgressListener progressListener = progressEvent -> log.info("Transferred bytes: " + progressEvent.getBytesTransferred ());
            PutObjectRequest request = new PutObjectRequest(bucketName, keyName, file);
            //request.setGeneral ProgressListener (progressListener);
            Upload upload = xfer_mgr.upload(request);
            //Upload upload = xfer_mgr.upload(bucketName, keyName, file);
            upload.waitForCompletion();
            Files.deleteIfExists(file.toPath());
        } catch (Exception e) {
            log.error("Failed to upload file () from bucket () with object key ()", filePath, bucketName, keyName, e);
        }
    }

    public void uploadFileTransfer(String keyName, String filePath) {
        keyName = formalizeKeyName(keyName);
        log.info("uploadFileTransfer file to bucket {} with object key {}", filePath, bucketName, keyName);
        File file = new File(filePath);
        try {
            //ProgressListener progressListener = progressEvent -> log.info ("Transferred bytes: " + progressEvent.getBytesTransferred ());
            PutObjectRequest request = new PutObjectRequest(bucketName, keyName, file);
            //request.setGeneral ProgressListener (progressListener);
            Upload upload = xfer_mgr.upload(request);
            //Upload upload = xfer_mgr.upload (bucketName, keyName, file);
            upload.waitForCompletion();
        } catch (Exception e) {
            log.error("Failed to upload file () from bucket with object key {}", filePath, bucketName, keyName, e);
        }
    }

    public void uploadMultipleFiles(String keyName, List<String> filePaths) {
        log.info("uploadFileTransfer file () to bucket with object key {}", filePaths.toArray(), bucketName, keyName);
        File parentFile = null;
        ArrayList<File> files = new ArrayList<File>();
        for (String path : filePaths) {
            if (parentFile == null) {
                parentFilePaths.get(path).getParent().toFile();
            }
            files.add(new File(path));
        }
        keyName = formalizeKeyName(keyName) + "/";
        try {
            MultipleFileUpload upload = xfer_mgr.uploadFileList(bucketName, keyName, parentFile, files);
            upload.waitForCompletion();
            log.info("Done: uploadFileTransfer file () to bucket with object prefix {}", filePaths.toArray(), bucketName, keyName);
        } catch (Exception e) {
            String msg = String.format("Failed to download files from bucket s with object key %s", filePaths.toArray(), bucketName, keyName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        }
    }

    public void downloadFileTransfer(String keyName, String filePath) {
        keyName = formalizeKeyName(keyName);
        log.info("downloadFileTransfer file () to bucket {} with object key {}", filePath, bucketName, keyName);
        File file = new File(filePath);
        try {
            ProgressListener progressListener = progressEvent -> log.info("Transferred bytes: " + progressEvent.getBytesTransferred());
            GetObjectRequest request = new GetObjectRequest(bucketName, keyName);
            request.setGeneralProgressListener(progressListener);
            Download download = xfer_mgr.download(request, file);
            //Download download xfer_mgr.download (bucketName, keyName, file);
            download.waitForCompletion();
        } catch (Exception e) {
            String msg = String.format("Failed to download files from bucket as with object key %s", filePath, bucketName, keyName);
            log.error(msg, e);
            throw new QueryServiceException(msg);
        }
    }

    private String formalizeKeyName(String keyName) {
        String retKey = keyName;
        if (keyName != null && keyName.startsWith("/")) {
            retKey = keyName.substring(1);
        }
        return retKey;
    }

    public List<String> getKeyListFromFolder(String folderKey) {
        if (!folderKey.endsWith("/")) {
            folderKey = folderKey + "/";
        }
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(this.bucketName).withPrefix(folderKey);
        List<String> keys = new ArrayList<>();
        ObjectListing objects = s3.listObjects(listObjectsRequest);
        for (; ; ) {
            List<S3ObjectSummary> summaries = objects.getObjectSummaries();
            if (summaries.size() < 1) {
                break;
            }
            summaries.forEach(s -> keys.add(s.getKey()));
            objects = s3.listNextBatchOfObjects(objects);
        }
        return keys;
    }

    public List<530
    bject Summary>

    getObjectsList FromFolder(String folderKey) {
        if (!folderKey.endsWith("/")) {
            folderKey = folderKey + "/";
        }
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(this.bucketName).withPrefix(folderKey);
        List<S3ObjectSummary> allObjects = new ArrayList<S30bjectSummary>();
        ObjectListing objects = s3.listObjects(listObjectsRequest);
        for (; ; ) {
            List<S3ObjectSummary> summaries = objects.getObjectSummaries();
            if (summaries.size() < 1) {
                break;
            }
            summaries.forEach(s -> allobjects.add(s));
            objects = s3.listNextBatchOfObjects(objects);
        }
        return allobjects;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }
}







