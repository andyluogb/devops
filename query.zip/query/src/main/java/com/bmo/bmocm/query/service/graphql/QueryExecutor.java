package com.bmo.bmocm.query.service.graphql;

import com.bmo.bmocm.query.service.model.QueryParam;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class QueryExecutor {
    public static String RETURN_REC_COUNT = "count";
    public static String RETURN_REC_FROM = "from";
    public static String RETURN_REC_TO = "to";
    public static String TOTAL_REC_COUNT = "totalCount";
    public static String ALL_COLUMN_GROUP = "*";
    public static String AGGREGATION_FIELDS_MAX = "max";
    public static String AGGREGATION_FIELDS_MIN = "min";
    public static String AGGREGATION_FIELDS_SUM = "sum";
    public static String AGGREGATION_FIELDS_COUNT = "count";
    public static String AGGREGATION_FIELDS_AVG = "avg";

    //TODO
    public Map<String, String[]> processMetaToken(QueryParam queryParam, String gqlTableName) {
        Map<String, String[]> tokenMap = new HashMap<String, String[]>();
        return tokenMap;
    }

    public void updateQueryParamMetaToken(QueryParam queryParam, Map<String, String[]> tokenMap) {

    }

    public void refreshMetaTokenValue(String gqlTableName, QueryParam queryParam, Map<String, String[]> tokenMap) {

    }

    public void updateMetaTokenTable(String gqlTableName, QueryParam queryParam, Map<String, String[]> tokenMap) {

    }

    public int getMaxRowPerRound(long pageLimit, int maxRowPerExport) {
        int maxRowPerExport1 = 0;
        return maxRowPerExport1;
    }

    public long getRounds(long totalCount, int maxRowPerExport) {
        long exportRounds = 0;
        return exportRounds;
    }

    public String getSelectCountQuery(String gqlTableName, int first, int limit,
                String where, String order,String gtoupby, String having, boolean isDistinct, List<String> columnNames) {
        return "";
    }

}
