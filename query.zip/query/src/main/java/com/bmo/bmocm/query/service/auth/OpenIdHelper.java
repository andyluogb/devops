package com.bmo.bmocm.query.service.auth;

import javax. annotation. PostConstruct;
import org.apache.commons.lang3.exception.ContextedException; import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value; import org.springframework. stereotype.Component;
import com.bmo.bmocm.oauth.OpenIdConfig;
import com.bmo.bmocm.oauth.OpenIdTokenProcessor;
import com.bmo.bmocm.oauth.OpenIdUser;
import com.bmo.bmocm.oauth.claimverifiers. ExpiredJWTException;
@Component
public class OpenIdHelper {
    private static final Logger log = LoggerFactory.getLogger(OpenIdHelper.class);
    private OpenIdTokenProcessor openIdTokenProcessor;
    @Value("${oauth.issuerUrl: https://ssoa-cm.cm.bmo.com}")
    String issuerUrl; // = "https://ssoa-cm.cm.bmo.com";
    @Value("${oauth.jwksEndPoint: /pf/JWKS}")
    String jwksEndPoint; // = "/pf/JWKS";
    @Value("${oauth.connectTimeoutMillis:500}")
    int connectTimeoutMillis; // = 500;
    @Value("${oauth.readTimeoutMillis:500}")
    int readTimeoutMillis; // = 500;
    @Value("${oauth.allowDomains: cm.bmo.COM, cm.bmo.COM}")
    String allowDomains; // = "BMO.COM, cm.bmo.COM";
    @Value("${oauth.audience: Springboard}")
    String audience; // = "Springboard";
    @Value("${oauth.enableExpirationTime:true}")
    boolean enableExpirationTime; // = true;
    @Value("${oauth.enabled:true}")
    boolean enabled; // = true;

    public OpenIdHelper() {
    }

    @PostConstruct
    public void init() {
        CTDSOpenIdTokenProcessorFactory openIdTokenProcessorFactory = new CTDSOpenIdTokenProcessorFactory(); //DefaultOpenIdTokenProcessorFactory();
        OpenIdConfig myOpenIdConfig = new OpenIdConfig(
                issuerUrl,
                jwksEndPoint,
                connectTimeoutMillis,
                readTimeoutMillis,
                allowDomains,
                audience,
                enableExpirationTime,
                enabled
        );
        openIdTokenProcessor = openIdTokenProcessorFactory.createInstance(myOpenIdConfig);
    }

    public OpenIdUser verifyAuthorization(String authorization) {
        String idToken = authorization != null ? authorization.replace("Bearer", "").trim() : "";
        return verifyOpenId(idToken);
    }

    public OpenIdUser verifyOpenId(String idToken) {
        OpenIdUser openIdUser = null;
        try {
            openIdUser = openIdTokenProcessor.process(idToken);
            log.info("openIdUser:" + openIdUser);
        } catch (ContextedException e) {
            if (e.getCause() instanceof ExpiredJWTException) {
                log.error("Token is expired", e);
            }
            log.error("Token is invalid", e);
        }

        return openIdUser;
    }
}

