package com.bmo.bmocm.query.service.config;

import org.apache.commons.dbcp2.BasicDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class MemSQLConfig {

    public Connection memSqlConnection() throws SQLException {
        DataSource dataSource = new BasicDataSource();
        return dataSource.getConnection();
    }
}
