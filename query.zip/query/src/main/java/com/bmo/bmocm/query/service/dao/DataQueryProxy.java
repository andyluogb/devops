package com.bmo.bmocm.query.service.dao;

import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;

@Component
public class DataQueryProxy {
    public void processAll(RowCallbackHandler callBack, String query) {
    }

    public Object findSingle(String query) {
        return "";
    }
}
