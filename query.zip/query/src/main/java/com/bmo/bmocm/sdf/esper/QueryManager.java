package com.bmo.bmocm.sdf.esper;

public interface QueryManager {

}
