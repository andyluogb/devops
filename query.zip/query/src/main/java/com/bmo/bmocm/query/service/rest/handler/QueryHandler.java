package com.bmo.bmocm.query.service.rest.handler;

import com.bmo.bmocm.query.service.graphql.GraphQLProvider;

import java.util.Map;

public interface QueryHandler {
    public Map<String, Object> executeQuery(String query, Map<String, String> headers);
    public Map<String, Object> executeQueryFile(String query, Map<String, String> headers);
    public Map<String, Object> executeRefreshMeta(String query, Map<String, String> headers);
    public GraphQLProvider getGprovider();
    public void setGprovider(GraphQLProvider gprovider);

}
