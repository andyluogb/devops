package com.bmo.bmocm.query.service.graphql;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.bmo.bmocm.query.service.common.CommonUtils;
import com.bmo.bmocm.query.service.common.QueryServiceConstant;
import com.bmo.bmocm.query.service.dao.DataQueryProxy;
import com.bmo.bmocm.query.service.exception.DataSetValidationException;
import com.bmo.bmocm.query.service.exception.ExceptionConstants;
import com.bmo.bmocm.query.service.exception.ExportFileException;
import com.bmo.bmocm.query.service.exception.QueryServiceException;
import com.bmo.bmocm.query.service.export.json.QueryJsonTransformer;
import com.bmo.bmocm.query.service.model.ResponseData;
import com.bmo.bmocm.query.service.rest.handler.MessageProcessor;
import com.bmo.bmocm.query.service.s3.QueryS3Client;
import com.bmo.bmocm.query.service.s3.S3Exporter;
import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;
import com.bmo.bmocm.query.service.export.ExportBeanFactory;
import com.bmo.bmocm.query.service.export.ExportFileHelper;
import com.bmo.bmocm.query.service.export.ExportFileStorageType;
import com.bmo.bmocm.query.service.export.ExportRowCallbackHandler;
import com.bmo.bmocm.query.service.export.QueryServiceExportor;
import com.bmo.bmocm.query.service.model.QueryParam;
import com.bmo.bmocm.query.service.model.QueryVariable;
import com.bmo.bmocm.query.service.model.ResponseDataFile;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema. DataFetchingFieldSelectionSet;
import graphql.schema.SelectedField;
import reactor.core.publisher.Flux;
import reactor.core.publisher. FluxSink;


@Component
public class GraphQLDataFetcherImpl implements GraphQLDataFetcher {
    private static final Logger log = LoggerFactory.getLogger(GraphQLDataFetcherImpl.class);

    @Autowired
    private GraphQLDataFetcherHelper fetcherHelper;
    @Autowired
    private QueryJsonTransformer queryJsonTransformer;
    @Autowired
    private MessageProcessor processor;
    @Autowired
    private QueryExecutor queryExecutor;
    @Autowired
    private ExportBeanFactory exportBeanFactory;
    @Autowired
    private DataQueryProxy dataQueryProxy;
    @Autowired
    private ExportFileHelper exportFileHelper;

    @Value("${data.export.processor.thread.pool:5}")
    private int s3ExportThreadPool;
    @Value("${data.query.max.row.request}")
    private int MAX_ROW_PER_REQUEST;
    @Value("${data.export.max.row.page:100000}")
    private int MAX_ROW_PER_EXPORT;

    public DataFetcher<Map<String, List<Map<String, Object>>>> getResponseDataFetcher() {
        return dataFetchingEnvironment -> {
            DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
            fetcherHelper.validateDataFetchingField(selectionSet);
            return createResponseData(dataFetchingEnvironment).getDataMap();
        };
    }


    public DataFetcher<Map<String, List<Map<String, Object>>>> getResponseDataFileFetcher() {
        return dataFetchingEnvironment -> {
            DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
            fetcherHelper.validateDataFetchingField(selectionSet);
            QueryParam queryParam = fetcherHelper.getAndValidateQueryParam(dataFetchingEnvironment);
            queryParam.getVariable().setLiveUpdate(false);
            Map<String, List<Map<String, Object>>> dataMap = null;
            if (!queryParam.getVariable().isStreaming()) {
                dataMap = createResponseDataFile(dataFetchingEnvironment, queryParam).getDataMap();
            } else {
                dataMap = createResponseDataFileStreaming(dataFetchingEnvironment, queryParam).getDataMap();
            }
            return dataMap;
        };
    }

    public DataFetcher<Map<String, List<Map<String, Object>>>> refreshMetaDataFetcher() {
        return dataFetchingEnvironment -> {
            DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
            fetcherHelper.validateDataFetchingField(selectionSet);
            return refreshMetaData(dataFetchingEnvironment).getDataMap();
        };
    }

    public DataFetcher<Map<String, List<Map<String, Object>>>> getCountFetcher() {
        return dataFetchingEnvironment -> {
            DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
            fetcherHelper.validateDataFetchingField(selectionSet);
            return createDataCount(dataFetchingEnvironment).getDataMap();
        };
    }

    private ResponseData createResponseData(DataFetchingEnvironment dataFetchingEnvironment) {
        Map<String, Object> context = dataFetchingEnvironment.getContext();
        QueryParam queryParam = fetcherHelper.getAndValidateQueryParam(dataFetchingEnvironment);
        DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        ResponseData responseData = new ResponseData();
        for (SelectedField f : selectionSet.getFields()) {
            if (f.getQualifiedName().equals(f.getName())) {
                String gqlTableName = f.getName();
                Map<String, String[]> tokenMap = queryExecutor.processMetaToken(queryParam, gqlTableName);
                queryExecutor.updateQueryParamMetaToken(queryParam, tokenMap);
                List<String> columnNames = fetcherHelper.getColumnNamesForQuery(gqlTableName, f.getSelectionSet());
                handleTotalCount(queryParam, responseData, f, gqlTableName, columnNames);
                long returnedCount = queryParam.getVariable().isFetchCount() ? getDataCount(gqlTableName, queryParam, columnNames) : 0;
                int oriFirst = queryParam.getVariable().getFirst();
                if (returnedCount > MAX_ROW_PER_REQUEST) {
                    throw new DataSetValidationException(String.format(ExceptionConstants.QUERY_RECORD_OVER_LIMIT, returnedCount, MAX_ROW_PER_REQUEST));
                }
                List<Map<String, Object>> dbList = new ArrayList<Map<String, Object>>();
                if (!queryParam.getVariable().isFetchCount() || returnedCount > 0) {
                    if (returnedCount > 0) {
                        queryParam.getVariable().setLimit((int) returnedCount);
                    }
                    dbList = fetcherHelper.getAllData(gqlTableName, f.getSelectionSet(), queryParam);
                }
                //queryExecutor.refreshMetaTokenValue (gqlTableName, queryParam, tokenMap);
                //queryExecutor.updateMetaTokenTable (gqlTableName, queryParam, tokenMap);
                responseData.putData(gqlTableName, dbList);
                if (returnedCount <= 0) {
                    returnedCount = (dbList != null ? dbList.size() : 0);
                }
                responseData.setStatisticMap(QueryExecutor.RETURN_REC_COUNT, new Long(returnedCount));
                responseData.setStatisticMap(QueryExecutor.RETURN_REC_FROM, oriFirst);
                responseData.setStatisticMap(QueryExecutor.RETURN_REC_TO, oriFirst + returnedCount - 1);
                context.put(QueryServiceConstant.KEY_RESPONSE_STATISTIC_MAP, responseData.getStatisticMap());
            }
        }
        return responseData;
    }

    private void handleTotalCount(QueryParam queryParam, ResponseData responseData, SelectedField f, String gqlTableName, List<String> columnNames) {
        if (queryParam.getVariable().isTotalCount()) {
            int orgLimit = queryParam.getVariable().getLimit();
            List<String> groupbyOri = queryParam.getVariable().getGroupby();
            String havingOri = queryParam.getVariable().getHaving();
            queryParam.getVariable().setLimit(0);
            //queryParam.getVariable().setGroupbyStr(null);
            //queryParam.getVariable() .setHaving (null);
            long totalCountForAll = getDataCount(gqlTableName, queryParam, columnNames);
            responseData.setStatisticMap(QueryExecutor.TOTAL_REC_COUNT, new Long(totalCountForAll));
            if (//CommonUtils.isCollectionEmpty (queryParam.getVariable().getGroupby()) &&
                    queryParam.getVariable().isHasAggregationColumns()) {
                queryParam.getVariable().setGroupbyStr(QueryExecutor.ALL_COLUMN_GROUP);
                queryParam.getVariable().setHaving(null);
                List<Map<String, Object>> aggregationList = fetcherHelper.getAllData(gqlTableName, f.getSelectionSet(), queryParam);

                if (aggregationList != null && !aggregationList.isEmpty()) {
                    Map<String, Object> returnMap = abstractAggregationFields(aggregationList.get(0), queryParam.getVariable().getMaxFields());
                    if (returnMap != null && !returnMap.isEmpty()) {
                        responseData.setStatisticMap(QueryExecutor.AGGREGATION_FIELDS_MAX, returnMap);
                    }
                    returnMap = abstractAggregationFields(aggregationList.get(0), queryParam.getVariable().getMinFields());
                    if (returnMap != null && !returnMap.isEmpty()) {
                        responseData.setStatisticMap(QueryExecutor.AGGREGATION_FIELDS_MIN, returnMap);
                    }
                    returnMap = abstractAggregationFields(aggregationList.get(0), queryParam.getVariable().getSumFields());
                    if (returnMap != null && !returnMap.isEmpty()) {
                        responseData.setStatisticMap(QueryExecutor.AGGREGATION_FIELDS_SUM, returnMap);
                    }
                    returnMap = abstractAggregationFields(aggregationList.get(0), queryParam.getVariable().getCountFields());
                    if (returnMap != null && !returnMap.isEmpty()) {
                        responseData.setStatisticMap(QueryExecutor.AGGREGATION_FIELDS_COUNT, returnMap);
                    }
                    returnMap = abstractAggregationFields(aggregationList.get(0), queryParam.getVariable().getAvgFields());
                    if (returnMap != null && !returnMap.isEmpty()) {
                        responseData.setStatisticMap(QueryExecutor.AGGREGATION_FIELDS_AVG, returnMap);
                    }
                }
                queryParam.getVariable().setLimit(orgLimit);
                queryParam.getVariable().setGroupby(groupbyOri);
                queryParam.getVariable().setHaving(havingOri);
            }
        }
    }

    private Map<String, Object> abstractAggregationFields(Map<String, Object> aggregationMap, List<String> fields) {
        Map<String, Object> returnMap = null;
        if (aggregationMap != null && !aggregationMap.isEmpty() && fields != null && !fields.isEmpty()) {
            returnMap = new HashMap<String, Object>();
            for (String field : fields) {
                if (aggregationMap.containsKey(field)) {
                    returnMap.put(field, aggregationMap.get(field));
                }
            }
        }
        return returnMap;
    }

    private ResponseData createDataCount(DataFetchingEnvironment dataFetchingEnvironment) {
        Map<String, Object> context = dataFetchingEnvironment.getContext();
        QueryParam queryParam = fetcherHelper.getAndValidateQueryParam(dataFetchingEnvironment);
        DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        ResponseData responseData = new ResponseData();
        List<Map<String, Object>> countList = new ArrayList<Map<String, Object>>();
        for (SelectedField f : selectionSet.getFields()) {
            if (f.getQualifiedName().equals(f.getName())) {
                String gqlTableName = f.getName();
                Map<String, String[]> tokenMap = queryExecutor.processMetaToken(queryParam, gqlTableName);
                queryExecutor.updateQueryParamMetaToken(queryParam, tokenMap);
                List<String> columnNames = fetcherHelper.getColumnNamesForQuery(gqlTableName, f.getSelectionSet());
                long totalCount = getDataCount(gqlTableName, queryParam, columnNames);
                Map<String, Object> count = new HashMap<String, Object>();
                count.put(gqlTableName, totalCount);
                countList.add(count);
            }
        }
        context.put(QueryServiceConstant.KEY_RESPONSE_TOTAL_COUNT, countList);
        return responseData;
    }

    private ResponseData refreshMetaData(DataFetchingEnvironment dataFetchingEnvironment) {
        Map<String, Object> context = dataFetchingEnvironment.getContext();
        QueryParam queryParam = fetcherHelper.getAndValidateQueryParam(dataFetchingEnvironment);
        DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        ResponseData responseData = new ResponseData();
        List<Map<String, Object>> responseDataMapList = new ArrayList<Map<String, Object>>();
        try {
            for (SelectedField f : selectionSet.getFields()) {
                if (f.getQualifiedName().equals(f.getName())) {
                    String gqlTableName = f.getName();
                    Map<String, String[]> tokenMap = queryExecutor.processMetaToken(queryParam, gqlTableName);
                    queryExecutor.updateQueryParamMetaToken(queryParam, tokenMap);
                    List<String> columnNames = fetcherHelper.getColumnNamesForQuery(gqlTableName, f.getSelectionSet());
                    long totalCount = getDataCount(gqlTableName, queryParam, columnNames);
                    queryParam.getVariable().setLimit((int) totalCount);
                    //List<Map<String, Object>> dbList = getAllData (gqlTableName, f.getSelectionSet (), queryParam);
                    queryExecutor.refreshMetaTokenValue(gqlTableName, queryParam, tokenMap);
                    queryExecutor.updateMetaTokenTable(gqlTableName, queryParam, tokenMap);

                    List<Map<String, Object>> list = tokenMap.values().stream().map(v -> {
                        Map<String, Object> m = new HashMap<String, Object>();
                        m.put("token", v[2]);
                        m.put("oldValue", v[0]);
                        m.put("newValue", v[1]);
                        return m;
                    }).collect(Collectors.toList());
                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("tokenMap", list);
                    responseDataMapList.add(map);
                }
            }
        } catch (Exception e) {
            log.error("Failure when exporting files.", e);
            throw new ExportFileException("Failure when exporting files.");
        } finally {
            context.put(QueryServiceConstant.KEY_RESPONSE_METADADA, responseDataMapList);
        }
        return responseData;
    }

    private ResponseData createResponseDataFile(DataFetchingEnvironment dataFetchingEnvironment, QueryParam queryParam) {
        QueryS3Client queryS3Client = null;
        S3Exporter s3Exporter = null;
        if (ExportFileStorageType.S3.equalsIgnoreCase(queryParam.getVariable().getStorageType())) {
            queryS3Client = fetcherHelper.getS3ClientWithAppCode(queryParam);
            s3Exporter = new S3Exporter(exportFileHelper, s3ExportThreadPool, queryS3Client);
        }
        Map<String, Object> context = dataFetchingEnvironment.getContext();
        DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        ResponseData responseData = new ResponseData();
        List<Map<String, Object>> responseDataFile = new ArrayList<Map<String, Object>>();
        try {
            for (SelectedField f : selectionSet.getFields()) {
                if (f.getQualifiedName().equals(f.getName())) {
                    String gqlTableName = f.getName();
                    Map<String, String[]> tokenMap = queryExecutor.processMetaToken(queryParam, gqlTableName);
                    queryExecutor.updateQueryParamMetaToken(queryParam, tokenMap);
                    List<String> columnNames = fetcherHelper.getColumnNamesForQuery(gqlTableName, f.getSelectionSet());
                    long totalCount = getDataCount(gqlTableName, queryParam, columnNames);
                    int maxRowPerExport = queryExecutor.getMaxRowPerRound(queryParam.getVariable().getPageLimit(), MAX_ROW_PER_EXPORT);
                    //if (selectCount> maxRowPerExport && StringUtils.isBlank (queryParam.getVariable().getOrder())) {
                    //throw new DataSetValidationException (String.format (ExceptionConstants.QUERY_RECORD_OVER_LIMIT_NO_ORDER, selectCount, maxRowPerExport));
                    //}
                    int recCount = 0;
                    List<String> allExportFileList = new ArrayList<String>();
                    if (totalCount > 0) {
                        long exportRounds = queryExecutor.getRounds(totalCount, maxRowPerExport);
                        int first = queryParam.getVariable().getFirst();
                        int limit = (int) Math.min(maxRowPerExport, totalCount);
                        long rear = totalCount;
                        String timeStamp = this.getFileTimestamp(queryParam);
                        for (long i = 0; i < exportRounds; i++) {
                            log.info("export records from {} limit {}", first, limit);
                            String seqNo = null;
                            if (exportRounds > 1) {
                                seqNo = StringUtils.leftPad(i + "", (int) (Math.log10(exportRounds) + 1), '0');
                            }
                            queryParam.getVariable().setFirst(first);
                            queryParam.getVariable().setLimit(limit);
                            String definedFileName = exportFileHelper.getFileName(queryParam.getVariable().getFileName(), queryParam.getVariable().getFileType(), gqlTableName, timeStamp, seqNo);
                            String fileAbsolutePath = exportFileHelper.getExportFileAbsolutePath(queryParam.getVariable().getStorageType(), queryParam.getHeader().getAppCode(), definedFileName);
                            Files.createDirectories(Paths.get(fileAbsolutePath).getParent());
                            List<String> exportFileList = new ArrayList<String>();
                            if (queryParam.getVariable().isBatch()) {
                                List<Map<String, Object>> dbList = fetcherHelper.getAllDataForExport(gqlTableName, f.getSelectionSet(), queryParam);
                                exportFileList = exportToFile(queryParam.getVariable(), gqlTableName, f, dbList, fileAbsolutePath);
                                recCount += (dbList == null ? 0 : dbList.size());
                            } else {
                                ExportRowCallbackHandler callBack = exportBeanFactory.createExportRowCallbackHandler(fileAbsolutePath, gqlTableName, queryParam.getVariable(), maxRowPerExport, limit);
                                processAllDataForExport(callBack, gqlTableName, f.getSelectionSet(), queryParam);
                                exportFileList = callBack.getExportFiles();
                                recCount += callBack.getTotalSize();
                            }
                            allExportFileList.addAll(exportFileList);
                            rear -= limit;
                            if (rear <= 0) {
                                break;
                            }
                            first += limit;
                            limit = (int) Math.min(maxRowPerExport, rear);
                        }

                        if (exportRounds > 0) {
                            queryExecutor.refreshMetaTokenValue(gqlTableName, queryParam, tokenMap);
                        }

                        String tokenMaxValue = fetcherHelper.getTokenMaxValue(tokenMap);
                        String definedFileName = exportFileHelper.getFileName(queryParam.getVariable().getFileName(), queryParam.getVariable().getFileType(), gqlTableName, timeStamp, null);
                        String fileAbsolutePath = exportFileHelper.getExportFileAbsolutePath(queryParam.getVariable().getStorageType(), queryParam.getHeader().getAppCode(), definedFileName);
                        if (queryParam.getVariable().isOkFile()) {
                            //create OK file
                            CommonUtils.createTextFile(fetcherHelper.getEndFileContent(totalCount, tokenMap), exportFileHelper.getEndFileName(fileAbsolutePath, tokenMaxValue));
                        }
                        allExportFileList = postExport(gqlTableName, queryParam, allExportFileList, s3Exporter, definedFileName, fileAbsolutePath, tokenMaxValue);
                        if (exportRounds > 0) {
                            queryExecutor.updateMetaTokenTable(gqlTableName, queryParam, tokenMap);
                        }
                    }
                    String exportFileNames = String.join("; ", allExportFileList);
                    ResponseDataFile dataFile = new ResponseDataFile(exportFileNames, recCount);
                    responseDataFile.add(dataFile.getDataMap());
                }
            }
        } catch (Exception e) {
            log.error("Failure when exporting files.", e);
            throw new ExportFileException("Failure when exporting files.");
        } finally {
            context.put(QueryServiceConstant.KEY_RESPONSE_FILE, responseDataFile);
        }
        return responseData;
    }

    private ResponseData createResponseDataFileStreaming(DataFetchingEnvironment dataFetchingEnvironment, QueryParam queryParam) {
        QueryS3Client queryS3Client = null;
        S3Exporter s3Exporter = null;
        if (ExportFileStorageType.S3.equalsIgnoreCase(queryParam.getVariable().getStorageType())) {
            queryS3Client = fetcherHelper.getS3ClientWithAppCode(queryParam);
            s3Exporter = new S3Exporter(exportFileHelper, s3ExportThreadPool, queryS3Client);
        }

        Map<String, Object> context = dataFetchingEnvironment.getContext();
        DataFetchingFieldSelectionSet selectionSet = dataFetchingEnvironment.getSelectionSet();
        ResponseData responseData = new ResponseData();
        List<Map<String, Object>> responseDataFile = new ArrayList<Map<String, Object>>();
        try {
            for (SelectedField f : selectionSet.getFields()) {
                if (f.getQualifiedName().equals(f.getName())) {
                    String gqlTableName = f.getName();
                    Map<String, String[]> tokenMap = queryExecutor.processMetaToken(queryParam, gqlTableName);
                    queryExecutor.updateQueryParamMetaToken(queryParam, tokenMap);
                    List<String> columnNames = fetcherHelper.getColumnNamesForQuery(gqlTableName, f.getSelectionSet());
                    long totalCount = getDataCount(gqlTableName, queryParam, columnNames);
                    List<String> allExportFileList = new ArrayList<String>();
                    int totalReturnSize = 0;
                    if (totalCount > 0) {
                        String timeStamp = this.getFileTimestamp(queryParam);
                        String definedFileName = exportFileHelper.getFileName(queryParam.getVariable().getFileName(), queryParam.getVariable().getFileType(), gqlTableName, timeStamp, null);
                        String fileAbsolutePath = exportFileHelper.getExportFileAbsolutePath(queryParam.getVariable().getStorageType(), queryParam.getHeader().getAppCode(), definedFileName);
                        int maxRowPerExport = queryExecutor.getMaxRowPerRound(queryParam.getVariable().getPageLimit(), MAX_ROW_PER_EXPORT);
                        Files.createDirectories(Paths.get(fileAbsolutePath).getParent());
                        ExportRowCallbackHandler callBack = exportBeanFactory.createExportRowCallbackHandler(fileAbsolutePath, gqlTableName, queryParam.getVariable(), maxRowPerExport, totalCount);
                        processAllDataForExport(callBack, gqlTableName, f.getSelectionSet(), queryParam);
                        queryExecutor.refreshMetaTokenValue(gqlTableName, queryParam, tokenMap);
                        String tokenMaxValue = fetcherHelper.getTokenMaxValue(tokenMap);
                        if (queryParam.getVariable().isOkFile()) {
                            //create OK file
                            CommonUtils.createTextFile(fetcherHelper.getEndFileContent(callBack.getTotalSize(), tokenMap), exportFileHelper.getEndFileName(fileAbsolutePath, tokenMaxValue));
                        }
                        allExportFileList = callBack.getExportFiles();
                        allExportFileList = postExport(gqlTableName, queryParam, allExportFileList, s3Exporter, definedFileName, fileAbsolutePath, tokenMaxValue);
                        queryExecutor.updateMetaTokenTable(gqlTableName, queryParam, tokenMap);
                        totalReturnSize = callBack.getTotalSize();
                    }
                    String exportFileNames = String.join("; ", allExportFileList);
                    ResponseDataFile dataFile = new ResponseDataFile(exportFileNames, totalReturnSize);
                    responseDataFile.add(dataFile.getDataMap());
                    //setResponseDataField (responseData, f.getName(), dbList); //list for exporting, not for displaying
                }
            }
        } catch (Exception e) {
            log.error("Failure when exporting files.", e);
            throw new ExportFileException("Failure when exporting files.");
        } finally {
            context.put(QueryServiceConstant.KEY_RESPONSE_FILE, responseDataFile);
        }
        return responseData;
    }

    private String getFileTimestamp(QueryParam queryParam) {
        String timeStamp = null;
        if (queryParam.getVariable().isAppendFileNameHash()) {
            timeStamp = CommonUtils.getUUIDFromTimestamp();
        }
        return timeStamp;
    }

    private List<String> exportToFile(QueryVariable queryVariable, String gqlTableName, SelectedField f, List<Map<String, Object>> dbList, String fileAbsolutePath) throws Exception {
        Files.createDirectories(Paths.get(fileAbsolutePath).getParent());
        List<String> columnNames = fetcherHelper.getColumnNamesInDataSet(f.getSelectionSet());
        Map<String, Object> extraParam = new HashMap<String, Object>();
        extraParam.put(ExportBeanFactory.EXTRA_PARAM_NAME_MAP_HEADER, columnNames.toArray(new String[]{}));
        extraParam.put(ExportBeanFactory.EXTRA_PARAM_NAME_TABLE_NAME, gqlTableName);
        QueryServiceExportor fileExporter = exportBeanFactory.createQueryServiceExporter(fileAbsolutePath, dbList, queryVariable, extraParam);
        List<String> fileList = fileExporter.exportData();
        return fileList;
    }

    private List<String> postExport(String gqlTableName, QueryParam queryParam, List<String> allExportFileList, S3Exporter s3Exporter, String definedFileName, String fileAbsolutePath, String tokenMaxValue) {
        if (queryParam.getVariable().isToZip()) {
            allExportFileList = allExportFileList.stream().map(theItem -> theItem + QueryServiceConstant.GZIP_FILE_EXT).collect(Collectors.toList());
        }

        if (QueryServiceConstant.FILE_TYPE_JSON.equalsIgnoreCase(queryParam.getVariable().getFileType())) {
            queryJsonTransformer.transformAndWriteBackJsonFile(fetcherHelper.getJsonSpec(gqlTableName, queryParam), allExportFileList, queryParam.getVariable().isToZip());
        }

        if (ExportFileStorageType.S3.equalsIgnoreCase(queryParam.getVariable().getStorageType())){
            allExportFileList = s3Exporter.exportToS3(allExportFileList, queryParam.getHeader().getAppCode(), fileAbsolutePath, definedFileName);
            if (queryParam.getVariable().isOkFile()) {
                s3Exporter.uploadS3EndFile(queryParam.getHeader().getAppCode(), fileAbsolutePath, definedFileName, tokenMaxValue);
            }
        }

        return allExportFileList;
    }

    private void processAllDataForExport(RowCallbackHandler callBack, String gqlTableName, DataFetchingFieldSelectionSet selectionSet, QueryParam param) {
        try {
            String query = fetcherHelper.getQuery(gqlTableName, selectionSet, param);
            log.info("sql query: " + query);
            dataQueryProxy.processAll(callBack, query);
        } catch (Exception e) {
            String msg = String.format("Exception in processAllDataForExport for gqlTableName: %s, sessionId: %s, appCode: %s", gqlTableName, param.getHeader().getSessionId(), param.getHeader().getAppCode());
            log.error(msg, e);
            throw new QueryServiceException(msg + "\n" + e.getMessage());
        }
    }

    private long getDataCount(String gqlTableName, QueryParam param, List<String> columnNames) {
        if (param.getVariable().getGroupby() != null && !param.getVariable().getGroupby().isEmpty() && param.getVariable().getGroupby().get(0).equals(QueryExecutor.ALL_COLUMN_GROUP)) {
            return 1;
        }
        String query = queryExecutor.getSelectCountQuery(gqlTableName, param.getVariable().getFirst(), param.getVariable().getLimit(),
                param.getVariable().getWhere(), param.getVariable().getOrder(),
                fetcherHelper.convertColumns(param.getVariable().getGroupby(), gqlTableName),
                param.getVariable().getHaving(), param.getVariable().isDistinct(), columnNames);
        long count = 0;
        try {
            Object result = dataQueryProxy.findSingle(query);
            count = result == null ? 0 : Long.valueOf(result.toString());
            log.info("get count for {} is {}", query, count);
        } catch (Exception e) {
            log.error(String.format("Exception in getDataCount for %s", query), e);
        }
        return count;
    }

    //TODO
    /*
    public DataFetcher<Publisher<<Map<String, Map<String, Object>>>> lookup() {
        return dataFetchingEnvironment -> {
            String sessionId = dataFetchingEnvironment.getArgument("sessionId");
            return lookupData(sessionId);
        };
    }

    private Publisher<Map<String, Map<String, Object>>> lookupData(String sessionId) {
        return Flux.create(sink -> {
            processor.register(sink::next, sessionId);
            sink.onDispose(() -> {
                log.info("dispose subscription for sessionId:");
                //processor.unRegister (sessionId);
            });
            sink.onCancel(() -> {
                log.info("cancel subscription for sessionId:");
                //processor.unRegister (sessionId);
            });
        }, FluxSink.OverflowStrategy.LATEST);
        //return Flux.create (sink -> {
        // processor.register (sink:: next, sessionId); //});
    }
    */

    public void setFetcherHelper(GraphQLDataFetcherHelper fetcherHelper) {
        this.fetcherHelper = fetcherHelper;
    }

    public void setQueryExecutor(QueryExecutor queryExecutor) {
        this.queryExecutor = queryExecutor;
    }

    public void setExportBeanFactory(ExportBeanFactory exportBeanFactory) {
        this.exportBeanFactory = exportBeanFactory;
    }

    public void setDataQueryProxy(DataQueryProxy dataQueryProxy) {
        this.dataQueryProxy = dataQueryProxy;
    }

    public void setExportFileHelper(ExportFileHelper exportFileHelper) {
        this.exportFileHelper = exportFileHelper;
    }
}
