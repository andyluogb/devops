package com.bmo.bmocm.query.service.s3;

import java.util.Map;
import javax. annotation. PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Service;
import com.bmo.bmocm.query.service.config.S3Config;
import com.bmo.bmocm.query.service.model.S3Profile;
@Service
public class QueryS3Factory {
    @Autowired
    private S3Config s3Config;
    @Autowired
    private ApplicationContext context;

    public QueryS3Factory() {
    }

    @PostConstruct
    public void createS3Client() {
        Map<String, S3Profile> s3Profiles = s3Config.getProfile();
        if (s3Profiles != null && !s3Profiles.isEmpty()) {
            for (String profileName : s3Profiles.keySet()) {
                String s3ClientName = profileName + "S3";
                S3Profile profile = s3Config.getProfile(profileName);
                QueryS3Client s3Client = new QueryS3Client(profile);
                ConfigurableListableBeanFactory beanFactory = ((ConfigurableApplicationContext) context).getBeanFactory();
                beanFactory.registerSingleton(s3ClientName, s3Client);
            }
        }
    }
}
