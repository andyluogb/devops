package com.bmo.bmocm.query.service.graphql;

import com.bmo.bmocm.query.service.model.QueryParam;
import com.bmo.bmocm.query.service.s3.QueryS3Client;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class GraphQLDataFetcherHelper {
    public void validateDataFetchingField(DataFetchingFieldSelectionSet selectionSet) {
        //TODO
    }
    public QueryParam getAndValidateQueryParam(DataFetchingEnvironment env) {
        //TODO
        QueryParam queryParam = new QueryParam();
        return queryParam;
    }

    public List<String> getColumnNamesForQuery(String gqlTableName, DataFetchingFieldSelectionSet selectionSet) {
        List<String> columnNames = new ArrayList<String>();
        //TODO
        return columnNames;
    }

    public List<Map<String, Object>> getAllData(String gqlTableName, DataFetchingFieldSelectionSet selectionSet, QueryParam queryParam) {
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
        //TODO
        return mapList;
    }

    public List<Map<String, Object>> getAllDataForExport(String gqlTableName, DataFetchingFieldSelectionSet selectionSet, QueryParam queryParam) {
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
        //TODO
        return mapList;
    }

    public QueryS3Client getS3ClientWithAppCode(QueryParam queryParam) {
        //TODO
        QueryS3Client queryS3Client = new QueryS3Client();
        return queryS3Client;
    }

    public String getTokenMaxValue(Map<String, String[]> tokenMap) {
        String tokenMaxValue = "";
        //TODO
        return tokenMaxValue;
    }

    public String getEndFileContent(long totalCount, Map<String, String[]> tokenMap) {
        String endFileContent = "";
        //TODO
        return endFileContent;
    }

    public List<String> getColumnNamesInDataSet(DataFetchingFieldSelectionSet selectionSet) {
        List<String> columnNames = new ArrayList<String>();
        //TODO
        return columnNames;
    }

    public String getJsonSpec(String gqlTableName, QueryParam queryParam) {
        String jsonSpec = "";
        //TODO
        return jsonSpec;
    }

    public String getQuery(String gqlTableName, DataFetchingFieldSelectionSet selectionSet, QueryParam queryParam) {
        String query = "";
        //TODO
        return query;
    }


    public String convertColumns(List<String> columns, String gqlTableName) {
        return "";
    }

}
