package com.bmo.bmocm.query.service.graphql;

public interface GraphQLDataFetcher {
}
