package com.bmo.bmocm.sdf.esper.impl;

import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent. BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.bmo.bmocm.sdf.esper.impl.common.EventHolder;
import com.bmo.bmocm.sdf.esper.EventPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventPublisherImpl implements EventPublisher {
    private static final Logger log = LoggerFactory.getLogger(EventPublisherImpl.class);
    private static final Integer DEFAULT_QUEUE_CAPACITY = 5000;
    private final BlockingQueue<EventHolder> mapEventQueue;
    private final ExecutorService execService  = Executors.newSingleThreadExecutor();
    private PublishEventConsumer publishEventConsumer = null;

    public EventPublisherImpl() {
        this.mapEventQueue = new ArrayBlockingQueue<EventHolder>(DEFAULT_QUEUE_CAPACITY);
        init();
    }

    private void init() {
        try {
            publishEventConsumer = new PublishEventConsumer(mapEventQueue, this);
            execService.submit(publishEventConsumer);
        } catch (Exception e) {
            log.error("Exception in starting event queue consumer thread. ");
            log.error(e.getMessage(), e.fillInStackTrace());
            throw e;
        }
    }

    public void publishEvent(Map<String, Object> event, String sessionId) {
        try {
            EventHolder eventHolder = new EventHolder();
            eventHolder.setEvent(event);
            eventHolder.setSessionId(sessionId);
            eventHolder.setSubscriptionType(null);
            boolean isOffer = this.mapEventQueue.offer(eventHolder);
            log.info("success offer:" + isOffer);
        } catch (Exception e) {
            log.error(e.getMessage(), e.fillInStackTrace());
        }
    }


    public void publishEvent(Map<String, Object> payload, String sessionId, String preference) {
        try {
            //TODO:
            log.info("publishEvent sessionId:" + sessionId);
        } catch (Exception e) {
            log.error(e.getMessage(), e.fillInStackTrace());
        }
    }

    public void publish(boolean publishFlag) {
        try {
            publishEventConsumer.publish(publishFlag);
        } catch (Exception e) {
            log.error(e.getMessage(), e.fillInStackTrace());
        }
    }
}

class PublishEventConsumer implements Runnable {
    private final static Logger log = LoggerFactory.getLogger(PublishEventConsumer.class);
    private CountDownLatch publishLatch =new CountDownLatch(1);

    private final BlockingQueue<EventHolder> eventQueue;
    private final EventPublisherImpl publisher;

    public PublishEventConsumer(BlockingQueue<EventHolder> eventQueue, EventPublisherImpl eventPublisher) {
        this.eventQueue = eventQueue;
        this.publisher = eventPublisher;
    }

    public void publish(boolean publishFlag) {
        if (publishFlag) {
            publishLatch.countDown();
        } else {
            publishLatch = new CountDownLatch(1);
        }
    }

    @Override
    public void run() {
        try {
            boolean running = true;
            while (running) {
                EventHolder eventHolder = null;
                try {
                    publishLatch.await();
                    eventHolder = this.eventQueue.take();
                    log.info("{Uses) sessionId :" + eventHolder.getSessionId() + " event Publisher" + eventQueue.hashCode());
                    publisher.publishEvent(eventHolder.getEvent(), eventHolder.getSessionId(), null);
                } catch (Exception e) {
                    log.error("Exception in processing of Event: {}", eventHolder);
                    log.error(e.getMessage(), e.fillInStackTrace());
                    running = false;
                }
            }
        } catch (Exception e) {
            log.error("Exception in queue processing thread, thread stopped");
            log.error(e.getMessage(), e.fillInStackTrace());
        }
    }
}
