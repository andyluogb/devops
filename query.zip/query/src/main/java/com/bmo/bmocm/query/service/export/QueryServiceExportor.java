package com.bmo.bmocm.query.service.export;

import com.bmo.bmocm.query.service.model.QueryVariable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class QueryServiceExportor {
    public QueryServiceExportor(String fileAbsolutePath, List<Map<String, Object>> dbList, QueryVariable queryVariable, Map<String, Object> extraParam) {

    }

    public List<String> exportData() {
        List<String> fileList = new ArrayList<String>();
        return fileList;
    }
}
