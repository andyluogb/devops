package com.bmo.bmocm.query.service.s3;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.bmo.bmocm.query.service.exception.ExportFileException;
import com.bmo.bmocm.query.service.export.ExportFileHelper;

public class S3Exporter {
    private static final Logger logger = LoggerFactory.getLogger(S3Exporter.class);
    private ExportFileHelper exportFileHelper;
    private QueryS3Client queryS3Client;
    private int s3ExportThreadPool;

    public S3Exporter(ExportFileHelper exportFileHelper, int s3ExportThreadPool, QueryS3Client queryS3Client) {
        this.exportFileHelper = exportFileHelper;
        this.s3ExportThreadPool = s3ExportThreadPool;
        this.queryS3Client = queryS3Client;
    }

    /*
    @PostConstruct
    private void test () {
        long startTime = System.currentTimeMillis();
        logger.info(">>>>>>>>Start S3 uploading...");
        String s3Staging = "C:\\bag0\\33\\";
        String appCode = "Query1";
        String csvFileAbsolutePaths3Staging = appCode + "\\TradeRevenue_20201230_231830461.csv";
        String definedFileName = "TradeRevenue";
        String[] list = {
                "TradeRevenue_20201230_231830461_0.csv.gz"
                , "TradeRevenue_20201230_231830461_1.csv.gz"
                , "TradeRevenue_20201230_231830461_2.csv.gz"
                , "TradeRevenue_20201230_231830461_3.csv.gz"
                , "TradeRevenue_20201230_231830461_4.csv.gz"
                , "TradeRevenue_20201230_231830461_5.csv.gz"
                , "TradeRevenue_20201230_231830461_6.csv.gz"
                , "TradeRevenue_20201230_231830461_10.csv.gz"
                , "TradeRevenue_20201230_231830461_11.csv.gz"
                , "TradeRevenue_20201230_231830461_12.csv.gz"
                , "TradeRevenue_20201230_231830461_13.csv.gz"
                , "TradeRevenue 20201230 231830461 14.csv.az"
                , "TradeRevenue_20201230_231830461_15.csv.gz"
                , "TradeRevenue_20201230_231830461_16.csv.gz"
        };
        List<String> exportFileList = Arrays.stream(list).map(s -> {
            return (s3Staging appCode + "\\" + 8);
        }).collect(Collectors.toList());
        List<String> s3List = exportToS3(exportFileList, appCode, csvFileAbsolutePath, definedFileName);
        logger.info(">>>>>>>>Start S3 done in " + (System.currentTimeMillis() - startTime) + "milliseonds");
        logger.info(">>>>53 location: \n" + String.join(";\n", s3List));
    }*/

    public List<String> exportToS3(List<String> exportFileList, String appCode, String csvFileAbsolutePath, String definedFileName) {
        //s3Utils.uploadMultipleFiles (exportFileHelper.getS3Bucket (), exportFileHelper.getS3ExportFilePath(""), exportFileList);
        List<String> exportFileListS3 = new ArrayList<String>();
        int jobSize = exportFileList.size();
        boolean success = false;
        int successfulCount = 0;
        if (jobSize == 1 || s3ExportThreadPool == 1) {
            for (String exportCsvFile : exportFileList) {
                String splitCsvFilePath = exportFileHelper.getS3StagingExportFilePath(appCode, Paths.get(exportCsvFile).getFileName().toString(), definedFileName);
                String s3Path = exportFileHelper.getS3ExportFilePath(appCode, Paths.get(exportCsvFile).getFileName().toString(), definedFileName);
                queryS3Client.uploadAndDeleteLocalFile(s3Path, splitCsvFilePath);
                //queryS3Client.uploadFileTransferAndDeleteStaging (exportFileHelper.getS3Bucket (), s3Path, splitCsvFilePath);
                exportFileListS3.add(this.getFull53ExportFilePath(queryS3Client.getBucketName(), s3Path));
            }
            success = true;
            successfulCount = jobSize;
        } else {
            int threadPool = Math.min(jobSize, s3ExportThreadPool);
            ExecutorService executor = Executors.newFixedThreadPool(threadPool);
            logger.info("Starting s3ExportThreadPool with {} threads.", threadPool);
            List<S3ExportCallable> calls = new ArrayList<S3ExportCallable>();
            for (String exportCsvFile : exportFileList) {
                String splitCsvFilePath = exportFileHelper.getS3StagingExportFilePath(appCode, Paths.get(exportCsvFile).getFileName().toString(), definedFileName);
                String s3Path = exportFileHelper.getS3ExportFilePath(appCode, Paths.get(exportCsvFile).getFileName().toString(), definedFileName);
                calls.add(new S3ExportCallable(s3Path, splitCsvFilePath));
            }
            try {
                List<Future<String>> results = executor.invokeAll(calls);
                for (Future<String> result : results) {
                    if (result.isDone()) {
                        exportFileListS3.add(this.getFull53ExportFilePath(queryS3Client.getBucketName(), result.get()));
                        successfulCount++;
                    }
                }
            } catch (Exception e) {
                logger.info("Failed in exporting {} to 53 path pattern {}", exportFileList, csvFileAbsolutePath);
                logger.error("Exception", e);
            } finally {
                logger.info("Shutdown s3ExportThreadPool with threads.", threadPool);
                executor.shutdown();
            }
            success = (successfulCount == jobSize);
        }

        if (!success) {
            String msg = String.format("Failed exporting s to 53 path pattern %s. Completed job %d, failed job %d", exportFileList, csvFileAbsolutePath,
                    successfulCount, jobSize - successfulCount);
            logger.info(msg);
            throw new ExportFileException(msg);
        } else {
            logger.info("All completed in exporting {} to 53 path pattern ()", exportFileList, csvFileAbsolutePath);
        }

        //if (success) {
        //uploadS3EndFile (appCode, csvFileAbsolutePath, definedFileName);
        //}
        return exportFileListS3;
    }

    public void uploadS3EndFile(String appCode, String csvFileAbsolutePath, String definedFileName, String tokenMaxValue) {
        String csvFileEndPath = exportFileHelper.getEndFileName(csvFileAbsolutePath, tokenMaxValue);
        String s3EndFilePath = exportFileHelper.getS3ExportFilePath(appCode, Paths.get(csvFileEndPath).getFileName().toString(), definedFileName);
        if (Files.exists(Paths.get(csvFileEndPath))) {
            queryS3Client.uploadAndDeleteLocalFile(s3EndFilePath, csvFileEndPath);
        }
    }

    private class S3ExportCallable implements Callable<String> {
        private String s3Path;
        private String splitCsvFilePath;

        public S3ExportCallable(String s3Path, String splitCsvFilePath) {
            this.s3Path = s3Path;
            this.splitCsvFilePath = splitCsvFilePath;
        }

        @Override
        public String call() throws Exception {
            queryS3Client.uploadAndDeleteLocalFile(s3Path, splitCsvFilePath);
            //queryS3Client.uploadFileTransferAndDeleteStaging (exportFileHelper.getS3Bucket (), s3Path, splitCsvFilePath);
            return s3Path;
        }
    }

    private String getFull53ExportFilePath(String dataExportS3Bucket, String s3FilePath) {
        return "33://" + dataExportS3Bucket + s3FilePath;
    }
}












