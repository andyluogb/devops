package com.bmo.bmocm.query.service.graphql;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import javax. annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import com.bmo.bmocm.query.service.config.MetaDataBuilder;
import graphql.GraphQL;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
@Component
public class GraphQLProvider {
    private static final Logger log = LoggerFactory.getLogger(GraphQLProvider.class);
    @Value("classpath:schema.graphqls")
    Resource resource;
    @Autowired
    private MetaDataBuilder metaDataBuilder;
    @Autowired
    private GraphQLDataFetcherImpl graphQLDataFetcher;
    private GraphQL graphQL;
    private String schema;

    @PostConstruct
    public void init() throws Exception {
        //File file resource.getFile();
        //log.info("file.toPath().toAbsolutePath() :" + file.toPath().toAbsolutePath());
        //schema= String.join (System.lineSeparator ()+" ",
        //Files.lines (file.toPath().toAbsolutePath(), StandardCharsets.UTF_8).collect (Collectors.toList())) + System.lineSeparator ();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()))) {
            ArrayList<String> list = new ArrayList<String>();
            while (reader.ready()) {
                String line = reader.readLine();
                list.add(line);
            }
            schema = String.join(System.lineSeparator() + " ", list) + System.lineSeparator();
            schema += metaDataBuilder.buildGraphqlSchema();
            log.info(schema);
        }
        GraphQLSchema graphQLSchema = buildSchema(schema);
        this.graphQL = GraphQL.newGraphQL(graphQLSchema).build();
    }

    private GraphQLSchema buildSchema(String sdl) {
        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(sdl);
        RuntimeWiring runtimeWiring = buildWiring();
        SchemaGenerator schemaGenerator = new SchemaGenerator();
        return schemaGenerator.makeExecutableSchema(typeRegistry, runtimeWiring);
    }

    private RuntimeWiring buildWiring() {
        return RuntimeWiring.newRuntimeWiring()
                .type(newTypeWiring("Query").dataFetcher("getData", graphQLDataFetcher.getResponseDataFetcher()))
                .type(newTypeWiring("Query").dataFetcher("getCount", graphQLDataFetcher.getCountFetcher()))
                .type(newTypeWiring("Query").dataFetcher("getDataFile", graphQLDataFetcher.getResponseDataFileFetcher()))
                .type(newTypeWiring("Query").dataFetcher("refreshMetaData", graphQLDataFetcher.refreshMetaDataFetcher()))
                .type(newTypeWiring("Subscription").dataFetcher("lookup", graphQLDataFetcher.lookup())).build();
    }

    @Bean
    public GraphQL graphQL() {
        return graphQL;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }
}
