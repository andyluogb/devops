package com.bmo.bmocm.query.service.exception;

public class QueryServiceException extends RuntimeException {
    public QueryServiceException() {
        super();
    }
    public QueryServiceException(String msg) {
        super(msg);
    }
}
