package com.bmo.bmocm.query.service.export;

public class ExportFileHelper {
    public String getFileName(String fileName, String fileType, String gqlTableName, String timeStamp, String seqNo) {
        return String.format("%s-%s-%s-%s-%s", fileName, fileType, gqlTableName, timeStamp, seqNo);
    }

    public String getExportFileAbsolutePath(String storageType, String appCode, String definedFileName) {
        return String.format("%s-%s-%s", storageType, appCode, definedFileName);
    }

    public String getEndFileName(String fileAbsolutePath, String tokenMaxValue) {
        return String.format("%s-%s.end", fileAbsolutePath, tokenMaxValue);
    }
}
