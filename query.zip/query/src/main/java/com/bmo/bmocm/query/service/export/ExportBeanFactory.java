package com.bmo.bmocm.query.service.export;

import com.bmo.bmocm.query.service.model.QueryVariable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class ExportBeanFactory {
    public static final String EXTRA_PARAM_NAME_MAP_HEADER = "map_header";
    public static final String EXTRA_PARAM_NAME_TABLE_NAME = "table_name";

    public ExportRowCallbackHandler createExportRowCallbackHandler(String fileAbsolutePath, String gqlTableName, QueryVariable variable, int maxRowPerExport, long limit) {
        ExportRowCallbackHandler callBack = new ExportRowCallbackHandler();
        return callBack;
    }


    public QueryServiceExportor createQueryServiceExporter(String fileAbsolutePath, List<Map<String, Object>> dbList, QueryVariable queryVariable, Map<String, Object> extraParam) {
        QueryServiceExportor fileExporter = new QueryServiceExportor(fileAbsolutePath,dbList, queryVariable, extraParam);
        return fileExporter;
    }
}
