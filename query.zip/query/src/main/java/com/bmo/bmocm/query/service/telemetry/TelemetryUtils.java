package com.bmo.bmocm.query.service.telemetry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.bmo.bmocm.query.service.common.CommonUtils;
import org.apache.commons.lang3.StringUtils;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
@Component
public class TelemetryUtils {
    private static final Logger log = LoggerFactory.getLogger(TelemetryUtils.class);
    //private static final String TELEMETRY_URL = "https://clientfirstdev-telemetry-service.devcm.bmo.com:8009/telemetry-service"; //private static final String TELEMETRY_CONTENT_TYPE = "application/json";
    @Value("${cdts.telemetry.url)")
    private String TELEMETRY_URL;
    @Value("${cdts.telemetry.contenttype)")
    private String TELEMETRY_CONTENT_TYPE;
    @Value("${cdts.telemetry.payload)")
    private String TELEMETRY_PAYLOAD;
    @Value("${cdts.telemetry.enable}")
    private boolean telemetryEnable;
    /*private static final String TELEMETRY_PAYLOAD = "{\"username\":\"\"," + "\"hostname\": \"%s\"," +
      \"systemname\": \"CTDS\"," +
      "\"devicesource\": \"Desktop\ "," +
      "\"module\": \"QueryService\", " + "\"eventname\":\"\"," +
      "\"payload\":{\"status\":\"%s\", \"query\":\"%s\"}" +
      "";
    */

    //cdts.telemetry.url=https://clientfirstdev-telemetry-service.devcm.bmo.com:8009/telemetry-service
    //cdts.telemetry.payload={"username": "%s", "hostname": "%s", "systemname": "CTDS", "devicesource": "Desktop", "module": "QueryService", "eventname": "%s", "payload": {"status":"%s", "query":""}}

    private static String HostIP = CommonUtils.getLocalIPAddress();

    public String submitTelemetry(String sessionId, String appCode, String userCode, String eventName, String datasetName, String query, String status) {
        if (!telemetryEnable) {
            log.info("telemetryEnable: " + telemetryEnable);
            return "";
        }
        eventName = StringUtils.isBlank(appCode) ? eventName : (appCode + "-" + eventName);
        //eventName StringUtils.isBlank (datasetName) ?eventName: (eventName+"-"+datasetName); eventName = StringUtils.isBlank (status) ?eventName: (eventName+": "+status);
        String payload = String.format(TELEMETRY_PAYLOAD,
                CommonUtils.getStringMaxLength(userCode, 32),
                CommonUtils.getStringMaxLength(HostIP, 64),
                datasetName == null ? "" : datasetName,
                CommonUtils.getStringMaxLength(eventName, 100),
                CommonUtils.getStringMaxLength(status, 100),
                CommonUtils.getStringMaxLength(CommonUtils.purifyStringForElastic(query), 4000)
        );
        String result = null;
        try {
            Unirest.config().verifySsl(false);
            HttpResponse<String> response = Unirest.post(TELEMETRY_URL)
                    .header("Content-Type", TELEMETRY_CONTENT_TYPE).header("X-Request-Id", sessionId)
                    .body(payload)
                    .asString();
            result = response.getBody();
        } catch (Exception e) {
            log.warn("Failed to submitTelemetry: ().", e.getMessage());
        }

        if (!StringUtils.isBlank(result)) {
            log.warn("Failed to submitTelemetry: ().", result);
        }
        return result;
    }
}


