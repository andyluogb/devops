package com.bmo.bmocm.query.service.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResponseData {
    private Map<String, List<Map<String, Object>>> dataMap = new HashMap<String, List<Map<String, Object>>>();
    private Map<String, Object> statisticMap = new HashMap<String, Object>();

    public ResponseData() {
    }

    public Map<String, Object> getStatisticMap() {
        return statisticMap;
    }

    public void setStatisticMap(Map<String, Object> statisticMap) {
        this.statisticMap = statisticMap;
    }

    public Map<String, List<Map<String, Object>>> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, List<Map<String, Object>>> dataMap) {
        this.dataMap = dataMap;
    }

    public void setStatisticMap(String key, Object obj) {
        statisticMap.put(key, obj);
    }

    public void putData(String gqlTableName, List<Map<String, Object>> dbList) {
        dataMap.put(gqlTableName, dbList);
    }

}
