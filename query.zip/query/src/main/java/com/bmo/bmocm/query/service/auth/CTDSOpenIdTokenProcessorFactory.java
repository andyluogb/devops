package com.bmo.bmocm.query.service.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.nimbusds.jose.proc.SecurityContext;
import com.bmo.bmocm.oauth.DefaultOpenIdTokenProcessorBuilder;
import com.bmo.bmocm.oauth.OpenIdConfig;
import com.bmo.bmocm.oauth.OpenIdTokenProcessor;
import com.bmo.bmocm.oauth.claimverifiers.ClaimVerifierPipelineBuilder;
import com.bmo.bmocm.oauth.claimverifiers.DomainClaimVerifier;
import com.bmo.bmocm.oauth.claimverifiers. ExpirationTimeClaimVerifier;
import com.bmo.bmocm.oauth.claimverifiers. IssuerClaimVerifier;

public class CTDSOpenIdTokenProcessorFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(CTDSOpenIdTokenProcessorFactory.class);

    public OpenIdTokenProcessor createInstance(OpenIdConfig openIdConfig) {
        LOGGER.info("create instance with openIdConfig={}", openIdConfig);
        final ClaimVerifierPipelineBuilder<SecurityContext> pipelineBuilder =
                new ClaimVerifierPipelineBuilder<>()
                        .add(new IssuerClaimVerifier<>(openIdConfig.getIssuerUrl()))
                        .add(new DomainClaimVerifier<>(openIdConfig.getAllowDomains()))
                        .add(new CTDSAudienceClaimVerifier<>(openIdConfig.getAudience()));

        if (openIdConfig.isEnableExpirationTime()) {
            pipelineBuilder.add(new ExpirationTimeClaimVerifier<>());
            return new DefaultOpenIdTokenProcessorBuilder()
                    .setIssuerUrl(openIdConfig.getIssuerUrl())
                    .setJwksEndPoint(openIdConfig.getJwksEndPoint())
                    .setConnectTimeoutMillis(openIdConfig.getConnectTimeoutMillis())
                    .setReadTimeoutMillis(openIdConfig.getReadTimeoutMillis())
                    .setClaimVerifierPipeline(pipelineBuilder.build()).setEnabled(openIdConfig.isEnabled())
                    .build();
        }
    }
}

