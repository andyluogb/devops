package com.bmo.bmocm.query.service.export;

public class ExportFileStorageType {
    public static String S3 = "S3";
}
