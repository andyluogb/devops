package com.bmo.bmocm.query.service.exception;

public class DataSetValidationException extends RuntimeException{
    public DataSetValidationException() {
        super();
    }
    public DataSetValidationException(String msg) {
        super(msg);
    }
}
