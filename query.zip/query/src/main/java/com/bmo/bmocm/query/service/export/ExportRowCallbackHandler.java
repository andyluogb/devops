package com.bmo.bmocm.query.service.export;

import com.bmo.bmocm.query.service.model.QueryVariable;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ExportRowCallbackHandler implements RowCallbackHandler {
    private List<String> exportFiles;
    private int totalSize;

    public ExportRowCallbackHandler() {
    }

    public List<String> getExportFiles() {
        return exportFiles;
    }

    public void setExportFiles(List<String> exportFiles) {
        this.exportFiles = exportFiles;
    }

    public int getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(int totalSize) {
        this.totalSize = totalSize;
    }

    @Override
    public void processRow(ResultSet rs) throws SQLException {

    }
}
