package com.bmo.bmocm.sdf.esper;

import java.util.Map;

public interface EventPublisher {
    public void publishEvent(Map<String, Object> event, String sessionId);
    public void publishEvent(Map<String, Object> payload, String sessionId, String preference);
}
