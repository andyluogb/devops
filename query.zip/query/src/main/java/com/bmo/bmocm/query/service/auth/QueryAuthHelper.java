package com.bmo.bmocm.query.service.auth;

import com.bmo.bmocm.query.service.model.QueryHeader;
import com.bmo.bmocm.query.service.common.QueryServiceConstant;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import com.bmo.bmocm.query.service.config.QueryServiceAuthConfig;
import com.bmo.bmocm.query.service.exception.ExceptionConstants;
import com.bmo.bmocm.query.service.exception.QueryServiceException;
import com.bmo.bmocm.query.service.model.QueryServiceAuth;
import com.bmo.bmocm.oauth.OpenIdUser;
import org.springframework.stereotype.Component;

@Component
public class QueryAuthHelper {
    private static final Logger log = LoggerFactory.getLogger(QueryAuthHelper.class);
    private static final String ROLE_QUERY = "QUERY";
    @Autowired
    private QueryServiceAuthConfig authConfig;
    @Autowired
    private OpenIdHelper openIdHelper;

    public void performAuthencation(String action, Map<String, String> headers, QueryHeader queryHeader) {
        if (headers.containsKey(QueryServiceConstant.KEY_AUTHORIZATION.toLowerCase())) {
            String authorization = headers.get(QueryServiceConstant.KEY_AUTHORIZATION.toLowerCase());
            AuthenUser authenUser = performAuthenAuthor(action, authorization);
            if (authenUser == null || !authenUser.isActive()) {
                log.info("Authorization invalid {}", (authenUser != null && authenUser.getLogonName() != null) ? ("for user " + authenUser.getLogonName()) : "");
                throw new QueryServiceException(ExceptionConstants.ACCESS_TOKEN_ERROR_NOT_ACTIVE);
            }
            queryHeader.setUserId(authenUser.getLogonName());
        } else {
            log.info("No authorization code provided.");
            throw new QueryServiceException(ExceptionConstants.ACCESS_TOKEN_ERROR_MISSED);
        }
    }

    private AuthenUser performAuthenAuthor(String action, String authorization) {
        AuthenUser authenUser = new AuthenUser();
        if (authorization.contains(QueryServiceConstant.KEY_AUTH_BASIC)) { //Authorization: Basic base64credentials
            String base64Credentials = authorization.substring(QueryServiceConstant.KEY_AUTH_BASIC.length()).trim(); //"Basic"
            byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
            String credentialStr = new String(credDecoded, StandardCharsets.UTF_8);
            String[] credentials = credentialStr.split(":", 2);
            authenUser.setLogonName(credentials[0]);
            authenUser.setCredential(credentials[1]);
            validateBasicAuthenUser(action, authenUser);
            authenUser.setCredential(null);
        } else { //if (authorization.contains (QueryServiceConstant.KEY_AUTH_BEARER)) { --default to Bearer token
            String idToken = authorization.substring(QueryServiceConstant.KEY_AUTH_BEARER.length()).trim(); //"Bearer"
            OpenIdUser openIdUser = openIdHelper.verifyOpenId(idToken);
            if (openIdUser != null) {
                authenUser.setLogonName(openIdUser.getLogonName());
                authenUser.setActive(AuthenUser.ACTIVE_TRUE);
                if (authenUser.isActive()) {
                    validateOAuthenUser(action, authenUser);
                }
            }
        }
        return authenUser;
    }

    private void validateBasicAuthenUser(String action, AuthenUser authenUser) {
        if (authConfig != null && !authConfig.getKeys().isEmpty()) {
            QueryServiceAuth profile = authConfig.getProfile(authenUser.getLogonName());
            if (profile == null || !passwordEncoder().matches(authenUser.getCredential(), profile.getPassword())) {
                throw new QueryServiceException(ExceptionConstants.ACCESS_TOKEN_ERROR_NOT_ACTIVE);
            }
            Set<String> roleSet = getRoles(profile);
            validateRole(action, roleSet);
            authenUser.setActive(AuthenUser.ACTIVE_TRUE);
        }
    }

    private void validateOAuthenUser(String action, AuthenUser authenUser) {
        if (authConfig.getAction() != null && !authConfig.getAction().isEmpty()) {
            if (!authConfig.getAction().containsKey(action)) {
                throw new QueryServiceException(String.format(ExceptionConstants.PERMISSION_ERROR, action));
            }
            String requiredRole = authConfig.getAction().get(action);
            if (!requiredRole.equals(ROLE_QUERY)) {
                QueryServiceAuth profile = authConfig.getProfile(authenUser.getLogonName());
                if (profile != null) {
                    Set<String> roleSet = getRoles(profile);
                    validateRole(action, roleSet);
                } else {
                    throw new QueryServiceException(String.format(ExceptionConstants.PERMISSION_ERROR, action));
                }
            }
        }
    }

    public Set<String> getRoles(QueryServiceAuth profile) {
        String[] roles = profile.getRole().trim().split(":");
        Set<String> roleSet = new HashSet<String>();
        for (String role : roles) {
            roleSet.add(role);
        }
        return roleSet;
    }

    private void validateRole(String action, Set<String> roleSet) {
        if (authConfig.getAction() != null && !authConfig.getAction().isEmpty()) {
            if (!authConfig.getAction().containsKey(action) || !roleSet.contains(authConfig.getAction().get(action))) {
                throw new QueryServiceException(String.format(ExceptionConstants.PERMISSION_ERROR, action));
            }
        }
    }

    private PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    //public String[] decodebasicAuthorization(String authorization) {
    //    String[] credentials = null;
    //    return credentials;
    //}
}



