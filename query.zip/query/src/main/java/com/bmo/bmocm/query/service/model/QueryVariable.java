package com.bmo.bmocm.query.service.model;

import java.util.List;

public class QueryVariable {
    private boolean liveUpdate;
    private boolean streaming;
    private boolean fetchCount;
    private int first;
    private int limit;
    private int pageLimit;
    private List<String> groupby;
    private String groupbyStr;
    private String having;
    private String where;
    private String order;
    private boolean distinct;
    private boolean totalCount;
    private boolean batch;

    private boolean hasAggregationColumns;
    private List<String> minFields;
    private List<String> maxFields;
    private List<String> sumFields;
    private List<String> countFields;
    private List<String> avgFields;

    private String fileName;
    private String fileType;
    private String storageType;
    private boolean appendFileNameHash;
    private boolean toZip;
    private boolean okFile;

    public boolean isLiveUpdate() {
        return liveUpdate;
    }

    public void setLiveUpdate(boolean liveUpdate) {
        this.liveUpdate = liveUpdate;
    }

    public boolean isStreaming() {
        return streaming;
    }

    public void setStreaming(boolean streaming) {
        this.streaming = streaming;
    }

    public boolean isFetchCount() {
        return fetchCount;
    }

    public void setFetchCount(boolean fetchCount) {
        this.fetchCount = fetchCount;
    }

    public int getFirst() {
        return first;
    }

    public void setFirst(int first) {
        this.first = first;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getPageLimit() {
        return pageLimit;
    }

    public void setPageLimit(int pageLimit) {
        this.pageLimit = pageLimit;
    }

    public List<String> getGroupby() {
        return groupby;
    }

    public void setGroupby(List<String> groupby) {
        this.groupby = groupby;
    }

    public String getGroupbyStr() {
        return groupbyStr;
    }

    public void setGroupbyStr(String groupByStr) {
        this.groupbyStr = groupByStr;
    }

    public String getHaving() {
        return having;
    }

    public void setHaving(String having) {
        this.having = having;
    }

    public boolean isHasAggregationColumns() {
        return hasAggregationColumns;
    }

    public void setHasAggregationColumns(boolean hasAggregationColumns) {
        this.hasAggregationColumns = hasAggregationColumns;
    }

    public List<String> getMaxFields() {
        return maxFields;
    }

    public void setMaxFields(List<String> maxFields) {
        this.maxFields = maxFields;
    }

    public List<String> getSumFields() {
        return sumFields;
    }

    public void setSumFields(List<String> sumFields) {
        this.sumFields = sumFields;
    }

    public List<String> getCountFields() {
        return countFields;
    }

    public void setCountFields(List<String> countFields) {
        this.countFields = countFields;
    }

    public List<String> getAvgFields() {
        return avgFields;
    }

    public void setAvgFields(List<String> avgFields) {
        this.avgFields = avgFields;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

    public boolean isAppendFileNameHash() {
        return appendFileNameHash;
    }

    public void setAppendFileNameHash(boolean appendFileNameHash) {
        this.appendFileNameHash = appendFileNameHash;
    }

    public boolean isToZip() {
        return toZip;
    }

    public void setToZip(boolean toZip) {
        this.toZip = toZip;
    }

    public boolean isOkFile() {
        return okFile;
    }

    public void setOkFile(boolean okFile) {
        this.okFile = okFile;
    }

    public String getWhere() {
        return where;
    }

    public void setWhere(String where) {
        this.where = where;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isTotalCount() {
        return totalCount;
    }

    public void setTotalCount(boolean totalCount) {
        this.totalCount = totalCount;
    }

    public List<String> getMinFields() {
        return minFields;
    }

    public void setMinFields(List<String> minFields) {
        this.minFields = minFields;
    }

    public boolean isBatch() {
        return batch;
    }

    public void setBatch(boolean batch) {
        this.batch = batch;
    }
}
