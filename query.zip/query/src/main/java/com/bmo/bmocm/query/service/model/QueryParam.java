package com.bmo.bmocm.query.service.model;

public class QueryParam {
    private QueryVariable variable;
    private QueryHeader header;

    public QueryVariable getVariable() {
        return variable;
    }

    public void setVariable(QueryVariable variable) {
        this.variable = variable;
    }

    public QueryHeader getHeader() {
        return header;
    }

    public void setHeader(QueryHeader header) {
        this.header = header;
    }
}
