package com.bmo.bmocm.query.service.config;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password. PasswordEncoder;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors. CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import com.google.common.collect.ImmutableList;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//import com.bmo.bmocm.query.service.model.QueryServiceAuth;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    public static final String ROLE_EXPORT = "EXPORT";
    public static final String ROLE_QUERY = "QUERY";
    public static final String ROLE_SUBSCRIBE = "SUBSCRIBE";
    public static final String ROLE_ADMIN = "ADMIN";

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.cors().and().csrf().disable().authorizeRequests();

        /*httpSecurity.authorizeRequests().antMatchers("/export").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/export").hasAnyRole(ROLE_EXPORT);
        httpSecurity.authorizeRequests().antMatchers("/query").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/query").hasAnyRole(ROLE_QUERY);
        httpSecurity.authorizeRequests().antMatchers("/refresh").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/refresh").hasAnyRole(ROLE_ADMIN);
        httpSecurity.authorizeRequests().antMatchers("/restart").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/restart").hasAnyRole(ROLE_ADMIN);
        httpSecurity.authorizeRequests().antMatchers("/graphqlSchema").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/graphqlSchema").hasAnyRole(ROLE_ADMIN);
        httpSecurity.authorizeRequests().antMatchers("/subscribe").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/subscribe").hasAnyRole(ROLE_SUBSCRIBE);
        httpSecurity.authorizeRequests().antMatchers("/unsubscribe").authenticated().and().httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/unsubscribe").hasAnyRole(ROLE_SUBSCRIBE);*/

        httpSecurity.authorizeRequests().antMatchers("/").permitAll();
        /*httpSecurity.addFilterBefore(
                jwtTokenFilter,
                UsernamePasswordAuthenticationFilter.class
        );*/
    }

    /*
    @Autowired
    public void configureGlobal (AuthenticationManagerBuilder auth) throws Exception {
        if (authConfig != null && !authConfig.getKeys().isEmpty()) {
            for (String userName : authConfig.getKeys()) {
                QueryServiceAuth profile = authConfig.getProfile(userName);
                auth.inMemoryAuthentication().withUser(userName).password(profile.getPassword().trim()).roles(profile.getRole().trim().split(":"));
            }
        }
    }*/


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // To enable CORS
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        final CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(ImmutableList.of("*")); //set access from all domains
        configuration.setAllowedMethods(ImmutableList.of("GET", "POST", "PUT", "DELETE"));
        configuration.setAllowCredentials(true);
        //configuration.setAllowedHeaders ("Content-Type", "X-Requested-With", "accept", "Origin", "Access-Control-Request-Method", "Access-Control-Request-Headers"); //Access-Control-Allow-Headers: X-Custom-Header, Upgrade-Insecure-Requests
        //configuration.setAllowedHeaders (ImmutableList.of ("Authorization", "Cache-Control", "Content-Type"));
        configuration.setAllowedHeaders(ImmutableList.of("*"));
        configuration.setExposedHeaders(ImmutableList.of("Access-Control-Allow-Origin", "Access-Control-Allow-Credentials"));
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

}







